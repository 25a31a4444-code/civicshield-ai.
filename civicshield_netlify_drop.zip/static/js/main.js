// Global CivicShield AI Main Script

document.addEventListener('DOMContentLoaded', () => {
  initNotificationDrawer();
  initNetworkStatusListener();
  initLanguageDropdown();
});

// Notifications Dropdown Handler
function initNotificationDrawer() {
  const bellBtn = document.getElementById('notificationBellBtn');
  const panel = document.getElementById('notificationsPanel');
  const listContainer = document.getElementById('notificationsList');
  const markReadBtn = document.getElementById('markAllReadBtn');
  const badge = document.getElementById('notificationBadge');

  if (!bellBtn || !panel) return;

  bellBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    panel.classList.toggle('active');
    if (panel.classList.contains('active')) {
      fetchNotifications();
    }
  });

  document.addEventListener('click', (e) => {
    if (!panel.contains(e.target) && !bellBtn.contains(e.target)) {
      panel.classList.remove('active');
    }
  });

  if (markReadBtn) {
    markReadBtn.addEventListener('click', () => {
      fetch('/api/notifications/mark_read', { method: 'POST' })
        .then(res => res.json())
        .then(() => {
          if (badge) badge.style.display = 'none';
          document.querySelectorAll('.notification-item.unread').forEach(el => el.classList.remove('unread'));
        });
    });
  }

  function fetchNotifications() {
    fetch('/api/notifications')
      .then(res => res.json())
      .then(data => {
        if (!listContainer) return;
        if (data.notifications.length === 0) {
          listContainer.innerHTML = '<div style="padding: 24px; text-align: center; color: var(--color-secondary-text);">No notifications at this time.</div>';
          return;
        }

        listContainer.innerHTML = data.notifications.map(n => `
          <div class="notification-item ${n.is_read ? '' : 'unread'}">
            <a href="${n.link || '#'}" style="text-decoration: none; color: inherit;">
              <div style="font-weight: 700; font-size: 0.9rem; color: var(--color-deep-burgundy); margin-bottom: 3px;">${n.title}</div>
              <div style="font-size: 0.82rem; color: var(--color-primary-text); line-height: 1.4;">${n.message}</div>
              <div style="font-size: 0.72rem; color: var(--color-secondary-text); margin-top: 6px;">${n.created_at}</div>
            </a>
          </div>
        `).join('');
      });
  }
}

// Network Status Listener for Offline Reporting
function initNetworkStatusListener() {
  const offlineBanner = document.getElementById('offlineNoticeBanner');
  
  function updateOnlineStatus() {
    if (navigator.onLine) {
      if (offlineBanner) offlineBanner.style.display = 'none';
    } else {
      if (offlineBanner) {
        offlineBanner.style.display = 'block';
      } else {
        const banner = document.createElement('div');
        banner.id = 'offlineNoticeBanner';
        banner.style.cssText = 'background: #B45309; color: #FFF; padding: 10px 20px; text-align: center; font-size: 0.9rem; font-weight: 600; position: sticky; top: 0; z-index: 1200;';
        banner.innerHTML = '⚠️ Offline Mode Active — Reports will be safely cached locally and uploaded once connection restores.';
        document.body.prepend(banner);
      }
    }
  }

  window.addEventListener('online', updateOnlineStatus);
  window.addEventListener('offline', updateOnlineStatus);
  if (!navigator.onLine) updateOnlineStatus();
}

// Community Support (+1) Button Trigger
function supportComplaint(complaintId, btnElement) {
  fetch(`/api/support_complaint/${complaintId}`, { method: 'POST' })
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        const countSpan = btnElement.querySelector('.support-count');
        if (countSpan) countSpan.textContent = data.count;
        btnElement.classList.toggle('supported', !data.removed);
      } else if (data.message) {
        alert(data.message);
      }
    })
    .catch(err => console.error('Support error:', err));
}

// Multilingual dropdown toggling
function initLanguageDropdown() {
  const langBtn = document.getElementById('langDropdownBtn');
  const langMenu = document.getElementById('langDropdownMenu');
  if (!langBtn || !langMenu) return;

  langBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    const isOpen = langMenu.classList.toggle('show');
    langBtn.setAttribute('aria-expanded', isOpen);
  });

  document.addEventListener('click', (e) => {
    if (!langMenu.contains(e.target) && !langBtn.contains(e.target)) {
      langMenu.classList.remove('show');
      langBtn.setAttribute('aria-expanded', 'false');
    }
  });
}

// Global Issue Deletion Modal & Action Handler
function openDeleteModal(target, title) {
  let issueId = '';
  let issueTitle = '';

  if (typeof target === 'string') {
    issueId = target;
    issueTitle = title || issueId;
  } else if (target && (target.getAttribute || target.dataset)) {
    issueId = target.getAttribute('data-id') || target.dataset.id || '';
    issueTitle = target.getAttribute('data-title') || target.dataset.title || issueId;
  }

  if (!issueId) {
    console.error('No issue ID found for openDeleteModal');
    return;
  }

  const modal = document.getElementById('deleteConfirmModal') || document.getElementById('deleteIssueModal');
  const idElem = document.getElementById('modalDeleteIssueId');
  const titleElem = document.getElementById('modalDeleteIssueTitle');
  const formElem = document.getElementById('deleteIssueForm');

  if (idElem) idElem.textContent = 'Ticket ID: ' + issueId;
  if (titleElem) titleElem.textContent = issueTitle || issueId;

  const isAuthority = window.location.pathname.startsWith('/authority');
  const deleteEndpoint = isAuthority
    ? '/authority/complaint/' + encodeURIComponent(issueId) + '/delete'
    : '/citizen/complaint/' + encodeURIComponent(issueId) + '/delete';

  if (formElem) {
    formElem.action = deleteEndpoint;
  }

  if (modal) {
    modal.style.display = 'flex';
  } else {
    // Robust fallback if modal container is absent on the page
    const confirmMsg = `Are you sure you want to permanently delete civic issue "${issueTitle}" (${issueId})?\n\nThis will remove all photos, AI triage data, and status history. This cannot be undone.`;
    if (window.confirm(confirmMsg)) {
      const tempForm = document.createElement('form');
      tempForm.method = 'POST';
      tempForm.action = deleteEndpoint;
      document.body.appendChild(tempForm);
      tempForm.submit();
    }
  }
}

function closeDeleteModal() {
  const m1 = document.getElementById('deleteConfirmModal');
  if (m1) m1.style.display = 'none';
  const m2 = document.getElementById('deleteIssueModal');
  if (m2) m2.style.display = 'none';
}

// Global event delegation for any button with class delete-issue-btn or data-action="delete-issue"
document.addEventListener('click', function(e) {
  const btn = e.target.closest('.delete-issue-btn, [data-action="delete-issue"]');
  if (btn) {
    e.preventDefault();
    e.stopPropagation();
    openDeleteModal(btn);
  }

  const backdrop = e.target;
  if (backdrop && (backdrop.id === 'deleteConfirmModal' || backdrop.id === 'deleteIssueModal')) {
    closeDeleteModal();
  }
});


