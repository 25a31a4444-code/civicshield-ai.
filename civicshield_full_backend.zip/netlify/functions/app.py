import os
import sys

# Add root directory to sys.path
root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

from app import app

try:
    import serverless_wsgi
    def handler(event, context):
        return serverless_wsgi.handle_request(app, event, context)
except ImportError:
    def handler(event, context):
        return {
            'statusCode': 200,
            'body': 'CivicShield AI Serverless Backend initialized.'
        }
