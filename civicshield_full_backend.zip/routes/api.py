import os
import time
from flask import Blueprint, request, jsonify, session
from werkzeug.utils import secure_filename
from database import get_db
from services.ai_service import classify_complaint, assess_image_authenticity
from services.duplicate_service import find_potential_duplicates
from services.analytics_service import estimate_civic_resources
from services.notification_service import get_user_notifications, get_unread_count, mark_all_notifications_read
from services.auth_service import get_current_user
from config import Config

api_bp = Blueprint('api', __name__)

@api_bp.route('/api/map_markers')
def map_markers():
    """Returns JSON complaints for Leaflet interactive map and civic heatmap."""
    category = request.args.get('category')
    status = request.args.get('status')
    priority = request.args.get('priority')
    department_id = request.args.get('department_id')
    
    user = get_current_user()
    is_authorized_officer = bool(user and user['role'] in ['officer', 'admin'])
    
    db = get_db()
    cursor = db.cursor()
    
    sql = '''
        SELECT c.id, c.category, c.title, c.location_address, c.latitude, c.longitude,
               c.ward, c.status, c.priority, c.is_overdue, c.created_at,
               d.name as department_name,
               (SELECT filename FROM complaint_images WHERE complaint_id = c.id LIMIT 1) as thumbnail,
               (SELECT COUNT(*) FROM community_supports WHERE complaint_id = c.id) as support_count
        FROM complaints c
        LEFT JOIN departments d ON c.department_id = d.id
        WHERE 1=1
    '''
    params = []
    
    if category:
        sql += " AND c.category = ?"
        params.append(category)
    if status:
        sql += " AND c.status = ?"
        params.append(status)
    if priority:
        sql += " AND c.priority = ?"
        params.append(priority)
    if department_id:
        sql += " AND c.department_id = ?"
        params.append(department_id)
        
    cursor.execute(sql, params)
    rows = cursor.fetchall()
    db.close()
    
    features = []
    for r in rows:
        # Determine pin color
        if r['status'] == 'Resolved':
            marker_color = '#15803D' # Green
            priority_code = 'resolved'
        elif r['priority'] in ['Critical', 'High'] or r['is_overdue'] == 1:
            marker_color = '#DC2626' # Red
            priority_code = 'critical'
        elif r['priority'] == 'Medium':
            marker_color = '#EA580C' # Orange
            priority_code = 'medium'
        else:
            marker_color = '#FACC15' # Yellow
            priority_code = 'low'
            
        # Privacy preservation for public map
        lat = r['latitude'] if is_authorized_officer else round(r['latitude'], 3)
        lon = r['longitude'] if is_authorized_officer else round(r['longitude'], 3)
        
        features.append({
            "id": r['id'],
            "title": r['title'],
            "category": r['category'],
            "status": r['status'],
            "priority": r['priority'],
            "latitude": lat,
            "longitude": lon,
            "address": r['location_address'] if is_authorized_officer else f"{r['ward']}, Hyderabad Area",
            "ward": r['ward'],
            "department": r['department_name'] or "General Public Works",
            "marker_color": marker_color,
            "priority_code": priority_code,
            "thumbnail": r['thumbnail'],
            "support_count": r['support_count'],
            "created_at": r['created_at']
        })
        
    return jsonify({"success": True, "count": len(features), "markers": features})

@api_bp.route('/api/ai_triage', methods=['POST'])
def ai_triage_preview():
    """Live AI pre-triage endpoint for the reporting form."""
    title = request.form.get('title', '')
    description = request.form.get('description', '')
    
    temp_image_path = None
    file = request.files.get('image')
    if file and file.filename != '':
        filename = secure_filename(file.filename)
        unique_name = f"temp_{int(time.time())}_{filename}"
        temp_image_path = os.path.join(Config.UPLOAD_FOLDER, unique_name)
        file.save(temp_image_path)
        
    result = classify_complaint(
        image_path=temp_image_path,
        title=title,
        description=description
    )
    
    authenticity = None
    if temp_image_path:
        authenticity = assess_image_authenticity(temp_image_path)
        
    return jsonify({
        "success": True,
        "triage": result,
        "authenticity": authenticity
    })

@api_bp.route('/api/check_duplicates', methods=['POST'])
def check_duplicates():
    """Checks for nearby similar complaints before final submission."""
    data = request.get_json() or {}
    category = data.get('category', '')
    description = data.get('description', '')
    try:
        lat = float(data.get('latitude', 0))
        lon = float(data.get('longitude', 0))
    except (ValueError, TypeError):
        return jsonify({"success": True, "duplicates": []})
        
    if not lat or not lon:
        return jsonify({"success": True, "duplicates": []})
        
    matches = find_potential_duplicates(
        category=category,
        latitude=lat,
        longitude=lon,
        description=description,
        radius_meters=200
    )
    
    return jsonify({
        "success": True,
        "found": len(matches) > 0,
        "duplicates": matches[:4]
    })

@api_bp.route('/api/support_complaint/<id>', methods=['POST'])
def support_complaint(id):
    """Citizen upvotes an existing complaint ('I am also affected')."""
    user = get_current_user()
    if not user:
        return jsonify({"success": False, "message": "Login required to support an issue."}), 401
        
    db = get_db()
    cursor = db.cursor()
    try:
        try:
            cursor.execute('INSERT INTO community_supports (complaint_id, user_id) VALUES (?, ?)', (id, user['id']))
            db.commit()
            cursor.execute('SELECT COUNT(*) FROM community_supports WHERE complaint_id = ?', (id,))
            count = cursor.fetchone()[0]
            return jsonify({"success": True, "count": count, "message": "Your support was recorded!"})
        except Exception:
            # Already supported, remove support
            cursor.execute('DELETE FROM community_supports WHERE complaint_id = ? AND user_id = ?', (id, user['id']))
            db.commit()
            cursor.execute('SELECT COUNT(*) FROM community_supports WHERE complaint_id = ?', (id,))
            count = cursor.fetchone()[0]
            return jsonify({"success": True, "count": count, "removed": True, "message": "Support withdrawn."})
    finally:
        db.close()


@api_bp.route('/api/notifications')
def notifications():
    user = get_current_user()
    if not user:
        return jsonify({"notifications": [], "unread_count": 0})
    notes = get_user_notifications(user['id'], limit=10)
    unread = get_unread_count(user['id'])
    return jsonify({
        "notifications": [dict(n) for n in notes],
        "unread_count": unread
    })

@api_bp.route('/api/notifications/mark_read', methods=['POST'])
def mark_notifications_read():
    user = get_current_user()
    if user:
        mark_all_notifications_read(user['id'])
    return jsonify({"success": True})

@api_bp.route('/api/resource_estimate', methods=['POST'])
def resource_estimate():
    data = request.get_json() or {}
    complaint_ids = data.get('complaint_ids', [])
    est = estimate_civic_resources(complaint_ids)
    return jsonify({"success": True, "estimate": est})

@api_bp.route('/api/analyze-evidence', methods=['POST'])
def analyze_evidence():
    """
    Real-time AI Photo & Video Authenticity Verification API.
    Accepts photo or video payload, validates size and format, extracts keyframes if video,
    computes blur/sharpness, EXIF tags, perceptual hash, and returns calibrated forensic assessment.
    """
    if 'file' not in request.files and 'media' not in request.files and 'images' not in request.files:
        return jsonify({"success": False, "message": "No evidence file provided in request."}), 400

    file = request.files.get('file') or request.files.get('media') or request.files.get('images')
    if not file or file.filename == '':
        return jsonify({"success": False, "message": "No file selected."}), 400

    filename = secure_filename(file.filename)
    ext = filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''

    if ext not in Config.ALLOWED_EXTENSIONS:
        allowed = ", ".join(sorted(Config.ALLOWED_EXTENSIONS))
        return jsonify({
            "success": False,
            "message": f"Unsupported media format '.{ext}'. Supported formats: {allowed}"
        }), 400

    # Create storage directories
    os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
    os.makedirs(Config.KEYFRAME_FOLDER, exist_ok=True)

    unique_name = f"verify_{int(time.time())}_{filename}"
    save_path = os.path.join(Config.UPLOAD_FOLDER, unique_name)
    file.save(save_path)

    # Check file size limit
    file_size = os.path.getsize(save_path)
    is_video = ext in Config.ALLOWED_VIDEO_EXTENSIONS
    if is_video and file_size > Config.MAX_VIDEO_CONTENT_LENGTH:
        max_mb = Config.MAX_VIDEO_CONTENT_LENGTH // (1024 * 1024)
        if os.path.exists(save_path):
            os.remove(save_path)
        return jsonify({
            "success": False,
            "message": f"Video file size exceeds maximum permitted municipal limit ({max_mb} MB)."
        }), 400

    from services.authenticity_service import assess_media_authenticity
    result = assess_media_authenticity(save_path, filename)
    result["success"] = True
    result["file_url"] = f"/static/uploads/{unique_name}"
    result["filename"] = unique_name

    return jsonify(result)

