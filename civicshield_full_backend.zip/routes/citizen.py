import os
import time
import hashlib
from datetime import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify, current_app
from werkzeug.utils import secure_filename
from database import get_db
from services.auth_service import login_required, role_required, get_current_user, log_audit
from services.ai_service import classify_complaint, assess_image_authenticity, normalize_telugu_text
from services.duplicate_service import find_potential_duplicates
from services.sla_service import calculate_sla_deadlines
from services.notification_service import create_notification
from config import Config

citizen_bp = Blueprint('citizen', __name__)

def generate_complaint_id():
    """Generates a unique, server-side complaint ID: CIVIC-2026-XXXXX"""
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT COUNT(*) FROM complaints")
    count = cursor.fetchone()[0] + 1
    db.close()
    return f"CIVIC-2026-{count:05d}"

@citizen_bp.route('/citizen/dashboard')
@login_required
def dashboard():
    user = get_current_user()
    db = get_db()
    cursor = db.cursor()
    
    # User's complaints statistics
    cursor.execute('''
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'Submitted' THEN 1 ELSE 0 END) as submitted,
            SUM(CASE WHEN status = 'Under Review' THEN 1 ELSE 0 END) as under_review,
            SUM(CASE WHEN status IN ('Assigned', 'In Progress') THEN 1 ELSE 0 END) as in_progress,
            SUM(CASE WHEN status = 'Resolved' THEN 1 ELSE 0 END) as resolved,
            SUM(CASE WHEN is_overdue = 1 THEN 1 ELSE 0 END) as overdue,
            SUM(CASE WHEN status = 'Reopened' THEN 1 ELSE 0 END) as reopened
        FROM complaints
        WHERE citizen_id = ?
    ''', (user['id'],))
    stats = dict(cursor.fetchone())
    
    # User's recent complaints
    cursor.execute('''
        SELECT c.*, d.name as department_name,
               (SELECT filename FROM complaint_images WHERE complaint_id = c.id LIMIT 1) as thumbnail
        FROM complaints c
        LEFT JOIN departments d ON c.department_id = d.id
        WHERE c.citizen_id = ?
        ORDER BY c.created_at DESC
        LIMIT 5
    ''', (user['id'],))
    recent_complaints = [dict(row) for row in cursor.fetchall()]
    
    # Nearby civic problems in the same ward
    ward = recent_complaints[0]['ward'] if recent_complaints else 'Ward 12 - Central'
    cursor.execute('''
        SELECT c.*, d.name as department_name,
               (SELECT filename FROM complaint_images WHERE complaint_id = c.id LIMIT 1) as thumbnail,
               (SELECT COUNT(*) FROM community_supports WHERE complaint_id = c.id) as support_count,
               (SELECT COUNT(*) FROM community_supports WHERE complaint_id = c.id AND user_id = ?) as user_supported
        FROM complaints c
        LEFT JOIN departments d ON c.department_id = d.id
        WHERE c.ward = ? AND c.citizen_id != ? AND c.status != 'Resolved'
        ORDER BY c.created_at DESC
        LIMIT 4
    ''', (user['id'], ward, user['id']))
    nearby_issues = [dict(row) for row in cursor.fetchall()]
    
    # Active disaster incidents if any
    cursor.execute("SELECT * FROM disaster_incidents WHERE status = 'Active' ORDER BY created_at DESC LIMIT 1")
    active_incident_row = cursor.fetchone()
    active_incident = dict(active_incident_row) if active_incident_row else None
    
    db.close()
    
    return render_template(
        'citizen/dashboard.html',
        user=user,
        stats=stats,
        recent_complaints=recent_complaints,
        nearby_issues=nearby_issues,
        active_incident=active_incident
    )

@citizen_bp.route('/citizen/report', methods=['GET', 'POST'])
@login_required
def report_issue():
    user = get_current_user()
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT id, name FROM departments WHERE active = 1")
    departments = [dict(row) for row in cursor.fetchall()]
    db.close()
    
    if request.method == 'POST':
        category = request.form.get('category', '').strip()
        title = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        location_address = request.form.get('location_address', '').strip()
        ward = request.form.get('ward', 'Ward 12 - Central')
        
        try:
            latitude = float(request.form.get('latitude', 17.3850))
            longitude = float(request.form.get('longitude', 78.4867))
        except (ValueError, TypeError):
            latitude, longitude = 17.3850, 78.4867
            
        if not category or not title or not description or not location_address:
            flash('Please complete all required fields.', 'danger')
            return render_template('citizen/report.html', categories=Config.CATEGORIES, departments=departments)
            
        # Telugu text normalization
        normalized_desc, has_telugu = normalize_telugu_text(description)
        raw_desc_te = description if has_telugu else None
        
        # Handle file uploads (both photo and video)
        uploaded_files = request.files.getlist('images') + request.files.getlist('media')
        saved_images = []
        primary_image_path = None
        
        from services.authenticity_service import assess_media_authenticity
        import json

        for file in uploaded_files:
            if file and file.filename != '':
                filename = secure_filename(file.filename)
                ext = filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''
                if ext in Config.ALLOWED_EXTENSIONS:
                    unique_name = f"{int(time.time())}_{filename}"
                    save_path = os.path.join(Config.UPLOAD_FOLDER, unique_name)
                    file.save(save_path)
                    
                    # Compute SHA-256 hash for evidence integrity
                    with open(save_path, 'rb') as f:
                        file_hash = hashlib.sha256(f.read()).hexdigest()
                        
                    # Comprehensive forensic analysis
                    auth_result = assess_media_authenticity(save_path, filename)
                    
                    keyframes = auth_result.get('extracted_keyframes', [])
                    inconsistencies = auth_result.get('inconsistencies', [])
                    dup_info = auth_result.get('duplicate_check', {})

                    saved_images.append({
                        'filename': unique_name,
                        'path': save_path,
                        'hash': file_hash,
                        'authenticity_flag': auth_result.get('verdict', 'Inconclusive'),
                        'authenticity_confidence': auth_result.get('confidence', 0.50),
                        'media_type': auth_result.get('media_type', 'photo'),
                        'video_duration': auth_result.get('duration_seconds'),
                        'video_fps': auth_result.get('fps'),
                        'frame_count': auth_result.get('total_frames'),
                        'blur_score': auth_result.get('blur_score'),
                        'inconsistencies_detected': json.dumps(inconsistencies),
                        'extracted_keyframes': json.dumps(keyframes),
                        'model_name': auth_result.get('model_name', Config.AUTHENTICITY_MODEL_NAME),
                        'perceptual_hash': auth_result.get('perceptual_hash'),
                        'is_duplicate_flag': 1 if dup_info.get('is_duplicate') else 0,
                        'duplicate_matched_id': dup_info.get('matched_complaint_id')
                    })
                    if not primary_image_path:
                        # If video, prefer first keyframe for image categorization if available
                        if keyframes and os.path.exists(os.path.join(Config.BASE_DIR, keyframes[0].lstrip('/'))):
                            primary_image_path = os.path.join(Config.BASE_DIR, keyframes[0].lstrip('/'))
                        else:
                            primary_image_path = save_path

        # Generate unique server-side ID
        complaint_id = generate_complaint_id()
        
        # Run AI classification & risk prioritization
        ai_result = classify_complaint(
            image_path=primary_image_path,
            title=title,
            description=normalized_desc
        )
        
        if ai_result.get('available'):
            priority = ai_result['severity_level']
            risk_score = ai_result['risk_score']
            hazard_flags_str = ", ".join(ai_result['hazard_flags']) if ai_result['hazard_flags'] else "Standard municipal hazard"
            reasoning = ai_result['reasoning']
            ai_category = ai_result['predicted_category']
            ai_confidence = ai_result['confidence_score']
        else:
            priority = "Medium"
            risk_score = 45
            hazard_flags_str = "AI service offline - manual triage required"
            reasoning = "AI analysis unavailable. Standard medium priority assigned for manual review."
            ai_category = category
            ai_confidence = 0.50

        # Hierarchical Jurisdiction & Department Routing Resolution
        from services.hierarchy_service import resolve_jurisdiction_and_routing
        from services.government_integration import dispatch_notification_with_tracking
        
        routing = resolve_jurisdiction_and_routing(
            category=category,
            latitude=latitude,
            longitude=longitude,
            address=location_address,
            ward=ward
        )
        
        assigned_dept_id = routing['department_id']
        jurisdiction_id = routing['jurisdiction_id']
        is_external = routing['is_external_authority']
        external_name = routing['external_authority_name']
        initial_tier = routing['initial_hierarchy_tier']
        assigned_officer_id = routing['assigned_officer_id']
            
        # Calculate SLA Due Dates
        sla_ack_due, sla_resolve_due = calculate_sla_deadlines(priority)
        
        db = get_db()
        cursor = db.cursor()
        
        # Insert Complaint with Jurisdiction and Hierarchy Routing Data
        cursor.execute('''
            INSERT INTO complaints (
                id, citizen_id, category, title, description, raw_description_te,
                location_address, latitude, longitude, ward, jurisdiction_id, status, priority,
                department_id, assigned_officer_id, current_hierarchy_level,
                is_external_authority, external_authority_name,
                sla_ack_due, sla_resolve_due
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Submitted', ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            complaint_id, user['id'], category, title, normalized_desc, raw_desc_te,
            location_address, latitude, longitude, ward, jurisdiction_id, priority,
            assigned_dept_id, assigned_officer_id, initial_tier,
            is_external, external_name,
            sla_ack_due, sla_resolve_due
        ))
        
        # Insert Evidence Images & Videos
        for img in saved_images:
            cursor.execute('''
                INSERT INTO complaint_images (
                    complaint_id, filename, file_path, file_hash, image_type,
                    is_authentic_flag, authenticity_confidence, uploaded_by,
                    media_type, video_duration, video_fps, frame_count, blur_score,
                    inconsistencies_detected, extracted_keyframes, model_name,
                    perceptual_hash, is_duplicate_flag, duplicate_matched_id
                ) VALUES (?, ?, ?, ?, 'evidence', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                complaint_id, img['filename'], img['path'], img['hash'],
                img['authenticity_flag'], img['authenticity_confidence'], user['id'],
                img['media_type'], img['video_duration'], img['video_fps'], img['frame_count'],
                img['blur_score'], img['inconsistencies_detected'], img['extracted_keyframes'],
                img['model_name'], img['perceptual_hash'], img['is_duplicate_flag'], img['duplicate_matched_id']
            ))
            
        # Insert AI Assessment Record
        cursor.execute('''
            INSERT INTO ai_assessments (
                complaint_id, predicted_category, confidence_score, risk_score,
                severity_level, recommended_dept_id, hazard_flags, reasoning
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            complaint_id, ai_category, ai_confidence, risk_score,
            priority, assigned_dept_id, hazard_flags_str, reasoning
        ))
        
        # Insert Initial Status History
        cursor.execute('''
            INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes)
            VALUES (?, NULL, 'Submitted', ?, 'Complaint filed by citizen. AI automated triage completed.')
        ''', (complaint_id, user['id']))
        
        # Check for potential duplicates
        duplicates = find_potential_duplicates(category, latitude, longitude, description, exclude_id=complaint_id)
        for dup in duplicates:
            cursor.execute('''
                INSERT INTO duplicate_relations (primary_complaint_id, duplicate_complaint_id, similarity_score)
                VALUES (?, ?, ?)
            ''', (dup['id'], complaint_id, dup['similarity_score']))
            
        db.commit()
        
        # Audit log & Notification
        log_audit(user['id'], "COMPLAINT_CREATED", "complaints", complaint_id, f"Risk: {risk_score}, Priority: {priority}")
        dispatch_notification_with_tracking(
            user['id'],
            f"Complaint Registered: {complaint_id}",
            f"Your issue '{title}' has been registered with priority {priority}. Routed to {routing['jurisdiction_name']}.",
            f"/citizen/complaint/{complaint_id}",
            channel='in_app',
            notification_type='status_change'
        )
        
        # Notify assigned field officer if routed
        if assigned_officer_id:
            dispatch_notification_with_tracking(
                assigned_officer_id,
                f"New Complaint Assigned: {complaint_id}",
                f"New grievance '{title}' in {ward} assigned to your queue ({priority} priority). Targeted acknowledgment deadline: {sla_ack_due}.",
                f"/authority/complaint/{complaint_id}",
                channel='in_app',
                notification_type='status_change'
            )
            
        db.close()
        
        flash(f"Complaint {complaint_id} successfully submitted! Routed to {routing['jurisdiction_name']}. AI Risk Score: {risk_score}/100.", 'success')
        return redirect(url_for('citizen.complaint_detail', id=complaint_id))
        
    return render_template(
        'citizen/report.html',
        categories=Config.CATEGORIES,
        departments=departments
    )

@citizen_bp.route('/citizen/my_complaints')
@login_required
def my_complaints():
    user = get_current_user()
    db = get_db()
    cursor = db.cursor()
    
    status_filter = request.args.get('status', '')
    category_filter = request.args.get('category', '')
    query_search = request.args.get('q', '').strip()
    
    sql = '''
        SELECT c.*, d.name as department_name, aj.name as jurisdiction_name,
               (SELECT filename FROM complaint_images WHERE complaint_id = c.id LIMIT 1) as thumbnail,
               (SELECT COUNT(*) FROM community_supports WHERE complaint_id = c.id) as support_count
        FROM complaints c
        LEFT JOIN departments d ON c.department_id = d.id
        LEFT JOIN administrative_jurisdictions aj ON c.jurisdiction_id = aj.id
        WHERE c.citizen_id = ?
    '''
    params = [user['id']]
    
    if status_filter:
        sql += " AND c.status = ?"
        params.append(status_filter)
    if category_filter:
        sql += " AND c.category = ?"
        params.append(category_filter)
    if query_search:
        sql += " AND (c.id LIKE ? OR c.title LIKE ? OR c.description LIKE ? OR c.location_address LIKE ?)"
        term = f"%{query_search}%"
        params.extend([term, term, term, term])
        
    sql += " ORDER BY c.created_at DESC"
    
    cursor.execute(sql, params)
    complaints = [dict(row) for row in cursor.fetchall()]
    db.close()
    
    return render_template(
        'citizen/my_complaints.html',
        complaints=complaints,
        categories=Config.CATEGORIES,
        status_filter=status_filter,
        category_filter=category_filter,
        query_search=query_search
    )

@citizen_bp.route('/citizen/complaint/<id>')
@login_required
def complaint_detail(id):
    user = get_current_user()
    db = get_db()
    cursor = db.cursor()
    
    # Fetch complaint with jurisdiction & hierarchy data
    cursor.execute('''
        SELECT c.*, u.name as citizen_name, u.phone as citizen_phone,
               d.name as department_name, off.name as officer_name,
               aj.name as jurisdiction_name, aj.type as jurisdiction_type, aj.code as jurisdiction_code,
               (SELECT COUNT(*) FROM community_supports WHERE complaint_id = c.id) as support_count,
               (SELECT COUNT(*) FROM community_supports WHERE complaint_id = c.id AND user_id = ?) as user_supported
        FROM complaints c
        JOIN users u ON c.citizen_id = u.id
        LEFT JOIN departments d ON c.department_id = d.id
        LEFT JOIN administrative_jurisdictions aj ON c.jurisdiction_id = aj.id
        LEFT JOIN users off ON c.assigned_officer_id = off.id
        WHERE c.id = ?
    ''', (user['id'], id))
    complaint_row = cursor.fetchone()
    
    if not complaint_row:
        db.close()
        flash('Complaint not found.', 'danger')
        return redirect(url_for('citizen.dashboard'))
        
    complaint = dict(complaint_row)
    
    # Permission check: citizen can only view their own or public overview
    if user['role'] == 'citizen' and complaint['citizen_id'] != user['id']:
        is_owner = False
    else:
        is_owner = True
        
    # Images (Evidence and Resolution)
    cursor.execute('SELECT * FROM complaint_images WHERE complaint_id = ? ORDER BY created_at ASC', (id,))
    images = [dict(row) for row in cursor.fetchall()]
    import json
    for img in images:
        if img.get('extracted_keyframes'):
            try:
                img['keyframes_list'] = json.loads(img['extracted_keyframes'])
            except Exception:
                img['keyframes_list'] = []
        else:
            img['keyframes_list'] = []

        if img.get('inconsistencies_detected'):
            try:
                img['inconsistencies_list'] = json.loads(img['inconsistencies_detected'])
            except Exception:
                img['inconsistencies_list'] = []
        else:
            img['inconsistencies_list'] = []
    
    evidence_images = [img for img in images if img['image_type'] == 'evidence']
    resolution_images = [img for img in images if img['image_type'] == 'resolution']
    
    # AI Assessment
    cursor.execute('SELECT * FROM ai_assessments WHERE complaint_id = ?', (id,))
    ai_assessment_row = cursor.fetchone()
    ai_assessment = dict(ai_assessment_row) if ai_assessment_row else None
    
    # Supervisory Directives
    cursor.execute('''
        SELECT si.*, u.name as supervisor_name, ap.designation as supervisor_designation
        FROM supervisory_instructions si
        JOIN users u ON si.supervisor_id = u.id
        LEFT JOIN authority_profiles ap ON u.id = ap.user_id
        WHERE si.complaint_id = ?
        ORDER BY si.created_at DESC
    ''', (id,))
    instructions = [dict(row) for row in cursor.fetchall()]
    
    # Department Transfers
    cursor.execute('''
        SELECT ct.*, d_from.name as from_dept_name, d_to.name as to_dept_name
        FROM complaint_transfers ct
        LEFT JOIN departments d_from ON ct.from_dept_id = d_from.id
        JOIN departments d_to ON ct.to_dept_id = d_to.id
        WHERE ct.complaint_id = ?
        ORDER BY ct.created_at DESC
    ''', (id,))
    transfers = [dict(row) for row in cursor.fetchall()]
    
    # Status Timeline History
    cursor.execute('''
        SELECT sh.*, u.name as actor_name, u.role as actor_role
        FROM status_history sh
        LEFT JOIN users u ON sh.changed_by = u.id
        WHERE sh.complaint_id = ?
        ORDER BY sh.created_at ASC
    ''', (id,))
    timeline = [dict(row) for row in cursor.fetchall()]
    
    # Active Appeals
    cursor.execute('SELECT * FROM appeals WHERE complaint_id = ? ORDER BY created_at DESC', (id,))
    appeals = [dict(row) for row in cursor.fetchall()]
    
    # Potential duplicate links
    cursor.execute('''
        SELECT dr.*, c.title as dup_title, c.status as dup_status
        FROM duplicate_relations dr
        JOIN complaints c ON (dr.primary_complaint_id = c.id OR dr.duplicate_complaint_id = c.id)
        WHERE (dr.primary_complaint_id = ? OR dr.duplicate_complaint_id = ?)
          AND c.id != ?
    ''', (id, id, id))
    duplicates = [dict(row) for row in cursor.fetchall()]
    
    # Administrative Jurisdiction
    jurisdiction = None
    if complaint.get('jurisdiction_id'):
        cursor.execute('SELECT * FROM administrative_jurisdictions WHERE id = ?', (complaint['jurisdiction_id'],))
        j_row = cursor.fetchone()
        if j_row:
            jurisdiction = dict(j_row)
            
    db.close()
    
    return render_template(
        'citizen/complaint_detail.html',
        complaint=complaint,
        jurisdiction=jurisdiction,
        evidence_images=evidence_images,
        resolution_images=resolution_images,
        ai_assessment=ai_assessment,
        timeline=timeline,
        appeals=appeals,
        duplicates=duplicates,
        instructions=instructions,
        supervisory_instructions=instructions,
        transfers=transfers,
        is_owner=is_owner,
        user=user
    )

@citizen_bp.route('/citizen/confirm_resolution/<id>', methods=['POST'])
@login_required
def confirm_resolution(id):
    user = get_current_user()
    rating = int(request.form.get('rating', 5))
    feedback = request.form.get('feedback', '').strip()
    
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT * FROM complaints WHERE id = ? AND citizen_id = ?', (id, user['id']))
    comp = cursor.fetchone()
    if not comp:
        db.close()
        flash('Unauthorized or complaint not found.', 'danger')
        return redirect(url_for('citizen.dashboard'))
        
    cursor.execute('''
        UPDATE complaints
        SET citizen_confirmed = 1,
            citizen_rating = ?,
            citizen_feedback = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    ''', (rating, feedback, id))
    
    cursor.execute('''
        INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes)
        VALUES (?, 'Resolved', 'Resolved', ?, ?)
    ''', (id, user['id'], f"Citizen verified repair with {rating}/5 stars. Feedback: '{feedback}'"))
    
    db.commit()
    log_audit(user['id'], "CITIZEN_CONFIRMED_RESOLUTION", "complaints", id, f"Rating: {rating}")
    db.close()
    
    flash('Thank you! Your verification and feedback have been officially recorded.', 'success')
    return redirect(url_for('citizen.complaint_detail', id=id))

@citizen_bp.route('/citizen/reopen/<id>', methods=['POST'])
@login_required
def reopen_complaint(id):
    user = get_current_user()
    reopen_reason = request.form.get('reopen_reason', '').strip()
    
    if not reopen_reason:
        flash('Please provide a reason for reopening this complaint.', 'warning')
        return redirect(url_for('citizen.complaint_detail', id=id))
        
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT * FROM complaints WHERE id = ? AND citizen_id = ?', (id, user['id']))
    comp = cursor.fetchone()
    if not comp:
        db.close()
        flash('Unauthorized action.', 'danger')
        return redirect(url_for('citizen.dashboard'))
        
    cursor.execute('''
        UPDATE complaints
        SET status = 'Reopened',
            citizen_confirmed = 0,
            escalation_level = MAX(escalation_level, 1),
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    ''', (id,))
    
    cursor.execute('''
        INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes)
        VALUES (?, 'Resolved', 'Reopened', ?, ?)
    ''', (id, user['id'], f"Citizen disputed resolution and reopened case: {reopen_reason}"))
    
    # Notify officer if assigned
    if comp['assigned_officer_id']:
        create_notification(
            comp['assigned_officer_id'],
            f"Case Reopened: {id}",
            f"Citizen disputed the resolution for {id}. Reason: {reopen_reason}",
            f"/authority/complaint/{id}",
            "status_change"
        )
        
    db.commit()
    log_audit(user['id'], "COMPLAINT_REOPENED", "complaints", id, reopen_reason)
    db.close()
    
    flash('Complaint reopened successfully. It has been escalated for senior authority re-inspection.', 'info')
    return redirect(url_for('citizen.complaint_detail', id=id))

@citizen_bp.route('/citizen/appeal/<id>', methods=['POST'])
@login_required
def submit_appeal(id):
    user = get_current_user()
    appeal_reason = request.form.get('appeal_reason', '').strip()
    
    if not appeal_reason:
        flash('Please state the grounds for your grievance appeal.', 'warning')
        return redirect(url_for('citizen.complaint_detail', id=id))
        
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT * FROM complaints WHERE id = ? AND citizen_id = ?', (id, user['id']))
    comp = cursor.fetchone()
    if not comp:
        db.close()
        flash('Unauthorized action.', 'danger')
        return redirect(url_for('citizen.dashboard'))
        
    cursor.execute('''
        INSERT INTO appeals (complaint_id, citizen_id, appeal_reason, status)
        VALUES (?, ?, ?, 'Pending Review')
    ''', (id, user['id'], appeal_reason))
    
    cursor.execute('''
        INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes)
        VALUES (?, ?, ?, ?, ?)
    ''', (id, comp['status'], comp['status'], user['id'], f"Official citizen appeal lodged: {appeal_reason}"))
    
    db.commit()
    log_audit(user['id'], "APPEAL_SUBMITTED", "appeals", id, appeal_reason)
    db.close()
    
    flash('Your formal appeal has been submitted to the Independent Grievance Redressal Officer.', 'success')
    return redirect(url_for('citizen.complaint_detail', id=id))

@citizen_bp.route('/citizen/complaint/<id>/add-evidence', methods=['POST'])
@login_required
def add_evidence(id):
    """Citizen uploads supplementary photo or video evidence to support their grievance."""
    user = get_current_user()
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT id, citizen_id, status, assigned_officer_id FROM complaints WHERE id = ?', (id,))
    comp = cursor.fetchone()
    if not comp:
        db.close()
        flash('Complaint not found.', 'danger')
        return redirect(url_for('citizen.dashboard'))
        
    if user['role'] == 'citizen' and comp['citizen_id'] != user['id']:
        db.close()
        flash('Unauthorized: You can only add evidence to your own reports.', 'danger')
        return redirect(url_for('citizen.complaint_detail', id=id))

    files = request.files.getlist('evidence') or request.files.getlist('images') or request.files.getlist('media')
    if not files or files[0].filename == '':
        db.close()
        flash('Please select a photo or video to upload.', 'warning')
        return redirect(url_for('citizen.complaint_detail', id=id))

    from services.authenticity_service import assess_media_authenticity
    import json
    
    uploaded_count = 0
    for file in files:
        if file and file.filename != '':
            filename = secure_filename(file.filename)
            ext = filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''
            if ext in Config.ALLOWED_EXTENSIONS:
                unique_name = f"supp_{int(time.time())}_{filename}"
                save_path = os.path.join(Config.UPLOAD_FOLDER, unique_name)
                file.save(save_path)
                
                with open(save_path, 'rb') as f:
                    f_hash = hashlib.sha256(f.read()).hexdigest()
                    
                auth_result = assess_media_authenticity(save_path, filename)
                keyframes = auth_result.get('extracted_keyframes', [])
                inconsistencies = auth_result.get('inconsistencies', [])
                dup_info = auth_result.get('duplicate_check', {})

                cursor.execute('''
                    INSERT INTO complaint_images (
                        complaint_id, filename, file_path, file_hash, image_type,
                        is_authentic_flag, authenticity_confidence, uploaded_by,
                        media_type, video_duration, video_fps, frame_count, blur_score,
                        inconsistencies_detected, extracted_keyframes, model_name,
                        perceptual_hash, is_duplicate_flag, duplicate_matched_id
                    ) VALUES (?, ?, ?, ?, 'evidence', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    id, unique_name, save_path, f_hash,
                    auth_result.get('verdict', 'Inconclusive'),
                    auth_result.get('confidence', 0.50),
                    user['id'],
                    auth_result.get('media_type', 'photo'),
                    auth_result.get('duration_seconds'),
                    auth_result.get('fps'),
                    auth_result.get('total_frames'),
                    auth_result.get('blur_score'),
                    json.dumps(inconsistencies),
                    json.dumps(keyframes),
                    auth_result.get('model_name', Config.AUTHENTICITY_MODEL_NAME),
                    auth_result.get('perceptual_hash'),
                    1 if dup_info.get('is_duplicate') else 0,
                    dup_info.get('matched_complaint_id')
                ))
                uploaded_count += 1

    if uploaded_count > 0:
        cursor.execute('''
            INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes)
            VALUES (?, ?, ?, ?, ?)
        ''', (id, comp['status'], comp['status'], user['id'], f"Supplementary evidence ({uploaded_count} item(s)) submitted by citizen with AI forensic verification."))
        
        db.commit()
        assigned_officer_id = comp['assigned_officer_id']
        db.close()

        # Notify officer
        if assigned_officer_id:
            from services.government_integration import dispatch_notification_with_tracking
            try:
                dispatch_notification_with_tracking(
                    assigned_officer_id,
                    f"Supplementary Evidence Added: {id}",
                    f"Citizen uploaded {uploaded_count} supplementary evidence file(s) for complaint {id}.",
                    f"/authority/complaint/{id}",
                    channel='in_app',
                    notification_type='status_change'
                )
            except Exception:
                pass
                
        flash(f'Successfully added {uploaded_count} new evidence file(s) with AI authenticity analysis.', 'success')
    else:
        db.close()
        flash('No valid media files were uploaded.', 'warning')

    return redirect(url_for('citizen.complaint_detail', id=id))

@citizen_bp.route('/citizen/drafts')
@login_required
def draft_reports():
    return render_template('citizen/draft_reports.html')
