from flask import Blueprint, render_template, request, redirect, url_for, flash
from database import get_db
from services.auth_service import role_required, get_current_user, log_audit
from services.notification_service import create_notification

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/admin/approvals')
@role_required(['admin'])
def officer_approvals():
    db = get_db()
    cursor = db.cursor()
    cursor.execute('''
        SELECT u.id, u.name, u.phone, u.email, u.created_at,
               ap.employee_id, ap.designation, ap.approval_status,
               d.name as department_name
        FROM users u
        JOIN authority_profiles ap ON u.id = ap.user_id
        LEFT JOIN departments d ON ap.department_id = d.id
        ORDER BY ap.approval_status DESC, u.created_at DESC
    ''')
    officers = [dict(row) for row in cursor.fetchall()]
    db.close()
    return render_template('admin/approvals.html', officers=officers)

@admin_bp.route('/admin/approve_officer/<int:user_id>', methods=['POST'])
@role_required(['admin'])
def approve_officer(user_id):
    current = get_current_user()
    db = get_db()
    cursor = db.cursor()
    cursor.execute('''
        UPDATE users SET is_approved = 1 WHERE id = ?
    ''', (user_id,))
    cursor.execute('''
        UPDATE authority_profiles 
        SET approval_status = 'approved', approved_by = ?, approved_at = CURRENT_TIMESTAMP
        WHERE user_id = ?
    ''', (current['id'], user_id))
    db.commit()
    log_audit(current['id'], "OFFICER_APPROVED", "users", user_id)
    
    create_notification(
        user_id,
        "Municipal Account Approved!",
        "Your municipal authority credentials have been approved by the Administrator. You now have full dashboard access.",
        "/authority/dashboard",
        "system"
    )
    db.close()
    flash(f"Officer account (ID #{user_id}) has been approved.", 'success')
    return redirect(url_for('admin.officer_approvals'))

@admin_bp.route('/admin/reject_officer/<int:user_id>', methods=['POST'])
@role_required(['admin'])
def reject_officer(user_id):
    current = get_current_user()
    reason = request.form.get('rejection_reason', 'Qualifications could not be verified by administration.')
    db = get_db()
    cursor = db.cursor()
    cursor.execute('''
        UPDATE users SET is_approved = 0 WHERE id = ?
    ''', (user_id,))
    cursor.execute('''
        UPDATE authority_profiles 
        SET approval_status = 'rejected', approved_by = ?, rejection_reason = ?, approved_at = CURRENT_TIMESTAMP
        WHERE user_id = ?
    ''', (current['id'], reason, user_id))
    db.commit()
    log_audit(current['id'], "OFFICER_REJECTED", "users", user_id, reason)
    db.close()
    flash(f"Officer account (ID #{user_id}) was rejected.", 'info')
    return redirect(url_for('admin.officer_approvals'))

@admin_bp.route('/admin/departments', methods=['GET', 'POST'])
@role_required(['admin'])
def departments_manager():
    db = get_db()
    cursor = db.cursor()
    if request.method == 'POST':
        dept_id = request.form.get('dept_id')
        name = request.form.get('name')
        email = request.form.get('contact_email')
        phone = request.form.get('contact_phone')
        
        cursor.execute('''
            UPDATE departments
            SET name = ?, contact_email = ?, contact_phone = ?
            WHERE id = ?
        ''', (name, email, phone, dept_id))
        db.commit()
        flash('Department information updated.', 'success')
        
    cursor.execute('''
        SELECT d.*, 
               (SELECT COUNT(*) FROM complaints WHERE department_id = d.id) as complaint_count,
               (SELECT COUNT(*) FROM users u JOIN authority_profiles ap ON u.id = ap.user_id WHERE ap.department_id = d.id) as staff_count
        FROM departments d
    ''')
    departments = [dict(row) for row in cursor.fetchall()]
    db.close()
    return render_template('admin/departments.html', departments=departments)

@admin_bp.route('/admin/toggle_disaster', methods=['POST'])
@role_required(['admin', 'officer'])
def toggle_disaster():
    user = get_current_user()
    enabled = request.form.get('disaster_mode') == 'true'
    incident_name = request.form.get('incident_name', 'Cyclone & Heavy Rainfall Alert')
    incident_type = request.form.get('incident_type', 'Flood')
    affected_wards = request.form.get('affected_wards', 'Wards 4, 7, 8, 12, 14')
    
    val_str = 'true' if enabled else 'false'
    db = get_db()
    cursor = db.cursor()
    cursor.execute("UPDATE system_settings SET value = ? WHERE key = 'disaster_mode'", (val_str,))
    
    if enabled:
        cursor.execute('''
            INSERT INTO disaster_incidents (incident_name, incident_type, description, affected_wards, status, created_by)
            VALUES (?, ?, 'High-intensity precipitation and localized inundation emergency active.', ?, 'Active', ?)
        ''', (incident_name, incident_type, affected_wards, user['id']))
        log_audit(user['id'], "DISASTER_MODE_ACTIVATED", "system_settings", None, incident_name)
        flash('Disaster Response Mode has been ACTIVATED across the city.', 'danger')
    else:
        cursor.execute("UPDATE disaster_incidents SET status = 'Resolved' WHERE status = 'Active'")
        log_audit(user['id'], "DISASTER_MODE_DEACTIVATED", "system_settings", None)
        flash('Disaster Response Mode has been standing down to normal operations.', 'info')
        
    db.commit()
    db.close()
    return redirect(request.referrer or url_for('authority.dashboard'))
