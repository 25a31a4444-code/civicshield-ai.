import os
import time
import hashlib
from datetime import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from werkzeug.utils import secure_filename
from database import get_db
from services.auth_service import login_required, role_required, get_current_user, log_audit
from services.sla_service import check_and_escalate_overdue
from services.analytics_service import get_department_analytics, run_predictive_analysis, estimate_civic_resources
from services.ai_service import compare_before_after
from services.notification_service import create_notification
from services.hierarchy_service import (
    acknowledge_complaint,
    create_supervisory_instruction,
    respond_to_supervisory_instruction,
    initiate_complaint_transfer,
    respond_to_department_transfer,
    check_and_escalate_hierarchical
)
from services.government_integration import export_complaint_gov_package
from config import Config

authority_bp = Blueprint('authority', __name__)

@authority_bp.route('/authority/dashboard')
@role_required(['officer', 'admin'])
def dashboard():
    user = get_current_user()
    db = get_db()
    cursor = db.cursor()
    
    # Department filter if officer is locked to a department
    dept_id = user['department_id'] if user['role'] == 'officer' and user['department_id'] else None
    
    where_clause = "WHERE department_id = ?" if dept_id else ""
    params = [dept_id] if dept_id else []
    
    cursor.execute(f'''
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN status = 'Submitted' THEN 1 ELSE 0 END) as unassigned,
            SUM(CASE WHEN priority IN ('Critical', 'High') AND status NOT IN ('Resolved', 'Rejected') THEN 1 ELSE 0 END) as urgent,
            SUM(CASE WHEN status IN ('Assigned', 'In Progress') THEN 1 ELSE 0 END) as in_progress,
            SUM(CASE WHEN status = 'Resolved' THEN 1 ELSE 0 END) as resolved,
            SUM(CASE WHEN is_overdue = 1 AND status NOT IN ('Resolved', 'Rejected') THEN 1 ELSE 0 END) as overdue,
            SUM(CASE WHEN status = 'Reopened' THEN 1 ELSE 0 END) as reopened
        FROM complaints
        {where_clause}
    ''', params)
    stats = dict(cursor.fetchone())
    
    # Urgent and Overdue Complaints list
    cursor.execute(f'''
        SELECT c.*, d.name as department_name, u.name as citizen_name
        FROM complaints c
        LEFT JOIN departments d ON c.department_id = d.id
        JOIN users u ON c.citizen_id = u.id
        WHERE c.status NOT IN ('Resolved', 'Rejected') 
          AND (c.priority IN ('Critical', 'High') OR c.is_overdue = 1)
          {"AND c.department_id = ?" if dept_id else ""}
        ORDER BY c.is_overdue DESC, c.escalation_level DESC, c.created_at ASC
        LIMIT 8
    ''', params)
    urgent_complaints = [dict(row) for row in cursor.fetchall()]
    
    # Active Work Orders
    cursor.execute('''
        SELECT wo.*, d.name as department_name,
               (SELECT COUNT(*) FROM work_order_complaints WHERE work_order_id = wo.id) as complaint_count
        FROM work_orders wo
        JOIN departments d ON wo.department_id = d.id
        ORDER BY wo.created_at DESC
        LIMIT 5
    ''')
    active_work_orders = [dict(row) for row in cursor.fetchall()]
    
    # Department list
    cursor.execute("SELECT * FROM departments WHERE active = 1")
    departments = [dict(row) for row in cursor.fetchall()]
    
    db.close()
    
    return render_template(
        'authority/dashboard.html',
        user=user,
        stats=stats,
        urgent_complaints=urgent_complaints,
        active_work_orders=active_work_orders,
        departments=departments
    )

@authority_bp.route('/authority/complaints')
@role_required(['officer', 'admin'])
def complaints_list():
    user = get_current_user()
    db = get_db()
    cursor = db.cursor()
    
    status_filter = request.args.get('status', '')
    priority_filter = request.args.get('priority', '')
    dept_filter = request.args.get('department_id', '')
    overdue_only = request.args.get('overdue', '') == '1'
    query_search = request.args.get('q', '').strip()
    
    sql = '''
        SELECT c.*, d.name as department_name, u.name as citizen_name, off.name as officer_name,
               ai.risk_score, ai.severity_level as ai_severity
        FROM complaints c
        LEFT JOIN departments d ON c.department_id = d.id
        JOIN users u ON c.citizen_id = u.id
        LEFT JOIN users off ON c.assigned_officer_id = off.id
        LEFT JOIN ai_assessments ai ON c.id = ai.complaint_id
        WHERE 1=1
    '''
    params = []
    
    if status_filter:
        sql += " AND c.status = ?"
        params.append(status_filter)
    if priority_filter:
        sql += " AND c.priority = ?"
        params.append(priority_filter)
    if dept_filter:
        sql += " AND c.department_id = ?"
        params.append(dept_filter)
    if overdue_only:
        sql += " AND c.is_overdue = 1"
    if query_search:
        sql += " AND (c.id LIKE ? OR c.title LIKE ? OR c.description LIKE ? OR c.location_address LIKE ?)"
        term = f"%{query_search}%"
        params.extend([term, term, term, term])
        
    sql += " ORDER BY c.is_overdue DESC, c.escalation_level DESC, c.created_at DESC"
    
    cursor.execute(sql, params)
    complaints = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute("SELECT id, name FROM departments WHERE active = 1")
    departments = [dict(row) for row in cursor.fetchall()]
    db.close()
    
    return render_template(
        'authority/complaint_review.html',
        complaints=complaints,
        departments=departments,
        categories=Config.CATEGORIES,
        status_filter=status_filter,
        priority_filter=priority_filter,
        dept_filter=dept_filter,
        overdue_only=overdue_only,
        query_search=query_search
    )

@authority_bp.route('/authority/complaint/<id>', methods=['GET', 'POST'])
@role_required(['officer', 'admin'])
def complaint_review_detail(id):
    user = get_current_user()
    db = get_db()
    cursor = db.cursor()
    
    if request.method == 'POST':
        action = request.form.get('action')
        new_status = request.form.get('status')
        new_priority = request.form.get('priority')
        dept_id = request.form.get('department_id')
        officer_id = request.form.get('assigned_officer_id') or user['id']
        notes = request.form.get('notes', '').strip()
        rejection_reason = request.form.get('rejection_reason', '').strip()
        
        cursor.execute("SELECT * FROM complaints WHERE id = ?", (id,))
        comp = cursor.fetchone()
        if not comp:
            db.close()
            flash('Complaint not found.', 'danger')
            return redirect(url_for('authority.complaints_list'))
            
        old_status = comp['status']
        
        # Check if resolution photo or video is uploaded
        resolution_file = request.files.get('resolution_image') or request.files.get('resolution_media')
        resolution_hash = None
        if resolution_file and resolution_file.filename != '':
            filename = secure_filename(resolution_file.filename)
            ext = filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''
            if ext in Config.ALLOWED_EXTENSIONS:
                unique_name = f"res_{int(time.time())}_{filename}"
                save_path = os.path.join(Config.UPLOAD_FOLDER, unique_name)
                resolution_file.save(save_path)
                with open(save_path, 'rb') as f:
                    resolution_hash = hashlib.sha256(f.read()).hexdigest()
                    
                from services.authenticity_service import assess_media_authenticity
                res_auth = assess_media_authenticity(save_path, filename)
                res_keyframes = res_auth.get('extracted_keyframes', [])
                res_inconsistencies = res_auth.get('inconsistencies', [])
                
                cursor.execute('''
                    INSERT INTO complaint_images (
                        complaint_id, filename, file_path, file_hash, image_type,
                        is_authentic_flag, authenticity_confidence, uploaded_by,
                        media_type, video_duration, video_fps, frame_count, blur_score,
                        inconsistencies_detected, extracted_keyframes, model_name,
                        perceptual_hash, manual_review_status
                    ) VALUES (?, ?, ?, ?, 'resolution', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Verified by Officer')
                ''', (
                    id, unique_name, save_path, resolution_hash,
                    res_auth.get('verdict', 'Likely Authentic'),
                    res_auth.get('confidence', 0.90),
                    user['id'],
                    res_auth.get('media_type', 'photo'),
                    res_auth.get('duration_seconds'),
                    res_auth.get('fps'),
                    res_auth.get('total_frames'),
                    res_auth.get('blur_score'),
                    json.dumps(res_inconsistencies),
                    json.dumps(res_keyframes),
                    res_auth.get('model_name', Config.AUTHENTICITY_MODEL_NAME),
                    res_auth.get('perceptual_hash')
                ))
                
        # Handle rejection
        if new_status == 'Rejected' and not rejection_reason:
            flash('A clear rejection reason must be provided when rejecting a complaint.', 'warning')
            return redirect(url_for('authority.complaint_review_detail', id=id))
            
        # Update complaint record
        cursor.execute('''
            UPDATE complaints
            SET status = ?,
                priority = COALESCE(?, priority),
                department_id = COALESCE(?, department_id),
                assigned_officer_id = ?,
                resolution_notes = CASE WHEN ? = 'Resolved' THEN ? ELSE resolution_notes END,
                resolution_photo_hash = COALESCE(?, resolution_photo_hash),
                rejection_reason = CASE WHEN ? = 'Rejected' THEN ? ELSE rejection_reason END,
                is_overdue = CASE WHEN ? = 'Resolved' THEN 0 ELSE is_overdue END,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (
            new_status, new_priority, dept_id, officer_id,
            new_status, notes, resolution_hash,
            new_status, rejection_reason,
            new_status, id
        ))
        
        # Log to status history
        history_note = notes if notes else f"Status changed to {new_status}"
        if rejection_reason:
            history_note += f" [Reason: {rejection_reason}]"
            
        cursor.execute('''
            INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes)
            VALUES (?, ?, ?, ?, ?)
        ''', (id, old_status, new_status, user['id'], history_note))
        
        db.commit()
        log_audit(user['id'], "STATUS_UPDATED", "complaints", id, f"{old_status} -> {new_status}")
        
        # Notify citizen
        create_notification(
            comp['citizen_id'],
            f"Update on Complaint {id}: {new_status}",
            f"Your complaint status was updated to '{new_status}'. {history_note}",
            f"/citizen/complaint/{id}",
            "status_change"
        )
        db.close()
        
        flash(f"Complaint {id} successfully updated to '{new_status}'.", 'success')
        return redirect(url_for('authority.complaint_review_detail', id=id))
        
    # GET request - load all details
    cursor.execute('''
        SELECT c.*, u.name as citizen_name, u.phone as citizen_phone, u.email as citizen_email,
               d.name as department_name, off.name as officer_name
        FROM complaints c
        JOIN users u ON c.citizen_id = u.id
        LEFT JOIN departments d ON c.department_id = d.id
        LEFT JOIN users off ON c.assigned_officer_id = off.id
        WHERE c.id = ?
    ''', (id,))
    comp_row = cursor.fetchone()
    if not comp_row:
        db.close()
        flash('Complaint not found.', 'danger')
        return redirect(url_for('authority.complaints_list'))
        
    # Enforce Jurisdictional and Departmental RBAC
    if user['role'] == 'officer':
        tier = user.get('hierarchy_tier') or 1
        # Tier 3 (Department Head) and Tier 4 (Commissioner) have broad oversight.
        # Tier 1 and 2 are restricted to their department / assigned complaints.
        if tier < 3 and user.get('department_id'):
            if comp_row['department_id'] and comp_row['department_id'] != user['department_id']:
                if comp_row['assigned_officer_id'] != user['id']:
                    db.close()
                    flash('Access Denied: You do not have jurisdictional clearance to inspect grievances belonging to other departments.', 'danger')
                    return redirect(url_for('authority.complaints_list'))
                    
    complaint = dict(comp_row)
    
    # Administrative Jurisdiction
    jurisdiction = None
    if comp_row['jurisdiction_id']:
        cursor.execute('SELECT * FROM administrative_jurisdictions WHERE id = ?', (comp_row['jurisdiction_id'],))
        j_row = cursor.fetchone()
        if j_row:
            jurisdiction = dict(j_row)
            
    # Supervisory Instructions
    cursor.execute('''
        SELECT si.*, u.name as issued_by_name, u.role as issued_by_role
        FROM supervisory_instructions si
        JOIN users u ON si.supervisor_id = u.id
        WHERE si.complaint_id = ?
        ORDER BY si.created_at DESC
    ''', (id,))
    supervisory_instructions = [dict(row) for row in cursor.fetchall()]
    
    # Complaint Transfers
    cursor.execute('''
        SELECT ct.*, fd.name as from_dept_name, td.name as to_dept_name,
               u.name as initiated_by_name
        FROM complaint_transfers ct
        JOIN departments fd ON ct.from_dept_id = fd.id
        JOIN departments td ON ct.to_dept_id = td.id
        JOIN users u ON ct.transferred_by = u.id
        WHERE ct.complaint_id = ?
        ORDER BY ct.created_at DESC
    ''', (id,))
    transfers = [dict(row) for row in cursor.fetchall()]
    
    # Notification logs
    cursor.execute('''
        SELECT nl.*, u.name as recipient_name, u.role as recipient_role
        FROM notification_delivery_logs nl
        LEFT JOIN users u ON nl.recipient_id = u.id
        WHERE nl.complaint_id = ?
        ORDER BY nl.created_at DESC
    ''', (id,))
    notification_logs = [dict(row) for row in cursor.fetchall()]
    
    # Evidence images
    cursor.execute('SELECT * FROM complaint_images WHERE complaint_id = ? ORDER BY created_at ASC', (id,))
    images = [dict(row) for row in cursor.fetchall()]
    import json
    for img in images:
        if img.get('extracted_keyframes'):
            try:
                img['keyframes_list'] = json.loads(img['extracted_keyframes'])
            except Exception:
                img['keyframes_list'] = []
        else:
            img['keyframes_list'] = []

        if img.get('inconsistencies_detected'):
            try:
                img['inconsistencies_list'] = json.loads(img['inconsistencies_detected'])
            except Exception:
                img['inconsistencies_list'] = []
        else:
            img['inconsistencies_list'] = []

    evidence_images = [img for img in images if img['image_type'] == 'evidence']
    resolution_images = [img for img in images if img['image_type'] == 'resolution']
    
    # AI Assessment
    cursor.execute('SELECT * FROM ai_assessments WHERE complaint_id = ?', (id,))
    ai_assessment_row = cursor.fetchone()
    ai_assessment = dict(ai_assessment_row) if ai_assessment_row else None
    
    # Status Timeline
    cursor.execute('''
        SELECT sh.*, u.name as actor_name, u.role as actor_role
        FROM status_history sh
        LEFT JOIN users u ON sh.changed_by = u.id
        WHERE sh.complaint_id = ?
        ORDER BY sh.created_at ASC
    ''', (id,))
    timeline = [dict(row) for row in cursor.fetchall()]
    
    # Officers list for assignment
    cursor.execute("SELECT id, name, email FROM users WHERE role IN ('officer', 'admin') AND is_approved = 1")
    officers = [dict(row) for row in cursor.fetchall()]
    
    # Departments list
    cursor.execute("SELECT id, name FROM departments WHERE active = 1")
    departments = [dict(row) for row in cursor.fetchall()]
    
    # Active Work Orders for fast linking
    cursor.execute("SELECT id, title, assigned_team FROM work_orders WHERE status != 'Completed'")
    work_orders = [dict(row) for row in cursor.fetchall()]
    
    db.close()
    
    return render_template(
        'authority/complaint_detail_review.html',
        complaint=complaint,
        jurisdiction=jurisdiction,
        supervisory_instructions=supervisory_instructions,
        transfers=transfers,
        notification_logs=notification_logs,
        evidence_images=evidence_images,
        resolution_images=resolution_images,
        ai_assessment=ai_assessment,
        timeline=timeline,
        officers=officers,
        departments=departments,
        work_orders=work_orders,
        user=user
    )

@authority_bp.route('/authority/work_orders', methods=['GET', 'POST'])
@role_required(['officer', 'admin'])
def work_orders():
    user = get_current_user()
    db = get_db()
    cursor = db.cursor()
    
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        department_id = request.form.get('department_id')
        assigned_team = request.form.get('assigned_team', '').strip()
        planned_date = request.form.get('planned_date')
        description = request.form.get('description', '').strip()
        selected_complaint_ids = request.form.getlist('complaint_ids')
        tasks_text = request.form.get('tasks', '').strip()
        
        cursor.execute("SELECT COUNT(*) FROM work_orders")
        count = cursor.fetchone()[0] + 1
        work_order_id = f"WO-2026-{count:04d}"
        
        # Calculate resource estimation
        res_est = estimate_civic_resources(selected_complaint_ids)
        
        cursor.execute('''
            INSERT INTO work_orders (
                id, department_id, title, description, assigned_team, planned_date,
                status, estimated_cost, estimated_manpower, materials_required, created_by
            ) VALUES (?, ?, ?, ?, ?, ?, 'Scheduled', ?, ?, ?, ?)
        ''', (
            work_order_id, department_id, title, description, assigned_team, planned_date,
            res_est['cost_max'], res_est['manpower'], res_est['materials'], user['id']
        ))
        
        # Link complaints and update their status to 'In Progress'
        for cid in selected_complaint_ids:
            cursor.execute('INSERT OR IGNORE INTO work_order_complaints (work_order_id, complaint_id) VALUES (?, ?)', (work_order_id, cid))
            cursor.execute('UPDATE complaints SET work_order_id = ?, status = "In Progress", updated_at = CURRENT_TIMESTAMP WHERE id = ?', (work_order_id, cid))
            cursor.execute('''
                INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes)
                VALUES (?, 'Assigned', 'In Progress', ?, ?)
            ''', (cid, user['id'], f"Assigned to Smart Work Order {work_order_id} ({assigned_team})"))
            
        # Insert tasks
        if tasks_text:
            for task_line in tasks_text.split('\n'):
                t_clean = task_line.strip()
                if t_clean:
                    cursor.execute('INSERT INTO work_order_tasks (work_order_id, task_description) VALUES (?, ?)', (work_order_id, t_clean))
        else:
            default_tasks = ["Site safety barrier setup", "Surface clearing & debris removal", "Repair execution", "Post-repair compaction & cleanup", "Before-and-after photo capture"]
            for dt in default_tasks:
                cursor.execute('INSERT INTO work_order_tasks (work_order_id, task_description) VALUES (?, ?)', (work_order_id, dt))
                
        db.commit()
        log_audit(user['id'], "WORK_ORDER_CREATED", "work_orders", work_order_id, f"Linked complaints: {len(selected_complaint_ids)}")
        db.close()
        
        flash(f"Smart Work Order {work_order_id} created successfully with {len(selected_complaint_ids)} linked complaints.", 'success')
        return redirect(url_for('authority.work_orders'))
        
    # GET - view work orders
    cursor.execute('''
        SELECT wo.*, d.name as department_name, u.name as creator_name,
               (SELECT COUNT(*) FROM work_order_complaints WHERE work_order_id = wo.id) as complaint_count,
               (SELECT COUNT(*) FROM work_order_tasks WHERE work_order_id = wo.id) as task_count,
               (SELECT COUNT(*) FROM work_order_tasks WHERE work_order_id = wo.id AND is_completed = 1) as completed_tasks
        FROM work_orders wo
        JOIN departments d ON wo.department_id = d.id
        LEFT JOIN users u ON wo.created_by = u.id
        ORDER BY wo.created_at DESC
    ''')
    work_orders_list = [dict(row) for row in cursor.fetchall()]
    
    # Fetch active unassigned/assigned complaints ready for bundling
    cursor.execute('''
        SELECT c.id, c.title, c.category, c.priority, c.ward, c.location_address
        FROM complaints c
        WHERE c.status IN ('Submitted', 'Under Review', 'Assigned') AND c.work_order_id IS NULL
        ORDER BY c.ward ASC, c.priority DESC
    ''')
    available_complaints = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute("SELECT id, name FROM departments WHERE active = 1")
    departments = [dict(row) for row in cursor.fetchall()]
    
    db.close()
    
    return render_template(
        'authority/work_orders.html',
        work_orders=work_orders_list,
        available_complaints=available_complaints,
        departments=departments
    )

@authority_bp.route('/authority/work_order/<id>')
@role_required(['officer', 'admin'])
def work_order_detail(id):
    user = get_current_user()
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute('''
        SELECT wo.*, d.name as department_name, u.name as creator_name
        FROM work_orders wo
        JOIN departments d ON wo.department_id = d.id
        LEFT JOIN users u ON wo.created_by = u.id
        WHERE wo.id = ?
    ''', (id,))
    wo_row = cursor.fetchone()
    if not wo_row:
        db.close()
        flash('Work order not found.', 'danger')
        return redirect(url_for('authority.work_orders'))
    work_order = dict(wo_row)
    
    # Linked complaints
    cursor.execute('''
        SELECT c.*, u.name as citizen_name
        FROM complaints c
        JOIN work_order_complaints woc ON c.id = woc.complaint_id
        JOIN users u ON c.citizen_id = u.id
        WHERE woc.work_order_id = ?
    ''', (id,))
    linked_complaints = [dict(row) for row in cursor.fetchall()]
    
    # Tasks
    cursor.execute('SELECT * FROM work_order_tasks WHERE work_order_id = ?', (id,))
    tasks = [dict(row) for row in cursor.fetchall()]
    
    db.close()
    return render_template('authority/work_order_detail.html', work_order=work_order, linked_complaints=linked_complaints, tasks=tasks)

@authority_bp.route('/authority/predictive')
@role_required(['officer', 'admin'])
def predictive():
    # Trigger predictive scan
    run_predictive_analysis()
    
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT * FROM predictive_alerts ORDER BY recurrence_count DESC, created_at DESC')
    alerts = [dict(row) for row in cursor.fetchall()]
    
    # Historical recurring patterns by ward & category
    cursor.execute('''
        SELECT ward, category, COUNT(*) as complaint_count,
               SUM(CASE WHEN is_overdue = 1 THEN 1 ELSE 0 END) as overdue_count
        FROM complaints
        GROUP BY ward, category
        ORDER BY complaint_count DESC
        LIMIT 10
    ''')
    recurring_patterns = [dict(row) for row in cursor.fetchall()]
    db.close()
    
    return render_template('authority/predictive.html', alerts=alerts, recurring_patterns=recurring_patterns)

@authority_bp.route('/authority/analytics')
@role_required(['officer', 'admin'])
def analytics():
    dept_stats = get_department_analytics()
    return render_template('authority/analytics.html', dept_stats=dept_stats)

@authority_bp.route('/authority/escalations')
@role_required(['officer', 'admin'])
def escalations():
    # Run SLA check
    escalated_count = check_and_escalate_overdue()
    
    db = get_db()
    cursor = db.cursor()
    cursor.execute('''
        SELECT c.*, d.name as department_name, u.name as citizen_name, off.name as officer_name
        FROM complaints c
        LEFT JOIN departments d ON c.department_id = d.id
        JOIN users u ON c.citizen_id = u.id
        LEFT JOIN users off ON c.assigned_officer_id = off.id
        WHERE c.is_overdue = 1 AND c.status NOT IN ('Resolved', 'Rejected')
        ORDER BY c.escalation_level DESC, c.sla_resolve_due ASC
    ''')
    overdue_complaints = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute('''
        SELECT sel.*, c.title, c.ward
        FROM sla_escalation_logs sel
        JOIN complaints c ON sel.complaint_id = c.id
        ORDER BY sel.created_at DESC
        LIMIT 15
    ''')
    escalation_logs = [dict(row) for row in cursor.fetchall()]
    db.close()
    
    return render_template(
        'authority/escalations.html',
        overdue_complaints=overdue_complaints,
        escalation_logs=escalation_logs,
        escalated_count=escalated_count
    )

@authority_bp.route('/authority/appeals')
@role_required(['officer', 'admin'])
def appeals_queue():
    db = get_db()
    cursor = db.cursor()
    cursor.execute('''
        SELECT a.*, c.title as complaint_title, c.category, c.status as complaint_status,
               u.name as citizen_name, u.phone as citizen_phone
        FROM appeals a
        JOIN complaints c ON a.complaint_id = c.id
        JOIN users u ON a.citizen_id = u.id
        ORDER BY a.created_at DESC
    ''')
    appeals = [dict(row) for row in cursor.fetchall()]
    db.close()
    return render_template('authority/appeals.html', appeals=appeals)

@authority_bp.route('/authority/appeal/<int:id>/action', methods=['POST'])
@role_required(['officer', 'admin'])
def handle_appeal(id):
    user = get_current_user()
    decision = request.form.get('decision') # 'Approved' (reinvestigate) or 'Rejected' (uphold original)
    decision_notes = request.form.get('decision_notes', '').strip()
    
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT * FROM appeals WHERE id = ?', (id,))
    appeal = cursor.fetchone()
    if not appeal:
        db.close()
        flash('Appeal record not found.', 'danger')
        return redirect(url_for('authority.appeals_queue'))
        
    cursor.execute('''
        UPDATE appeals
        SET status = ?,
            reviewed_by = ?,
            reviewer_decision_notes = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    ''', (decision, user['id'], decision_notes, id))
    
    # If approved for reinvestigation, set complaint to Under Review
    if decision == 'Approved':
        cursor.execute('''
            UPDATE complaints
            SET status = 'Under Review',
                escalation_level = 2,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (appeal['complaint_id'],))
        
        cursor.execute('''
            INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes)
            VALUES (?, 'Reopened', 'Under Review', ?, ?)
        ''', (appeal['complaint_id'], user['id'], f"Grievance Ombudsman upheld appeal: {decision_notes}"))
        
    db.commit()
    log_audit(user['id'], "APPEAL_DECISION", "appeals", id, f"Decision: {decision}")
    
    # Notify citizen
    create_notification(
        appeal['citizen_id'],
        f"Grievance Appeal Determination: {decision}",
        f"Your appeal regarding complaint {appeal['complaint_id']} was reviewed: {decision_notes}",
        f"/citizen/complaint/{appeal['complaint_id']}",
        "status_change"
    )
    db.close()
    
    flash(f"Appeal determination recorded: {decision}.", 'success')
    return redirect(url_for('authority.appeals_queue'))

@authority_bp.route('/authority/disaster')
@role_required(['officer', 'admin'])
def disaster_command():
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT * FROM disaster_incidents ORDER BY created_at DESC')
    incidents = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute('''
        SELECT c.*, d.name as department_name
        FROM complaints c
        LEFT JOIN departments d ON c.department_id = d.id
        WHERE c.category IN ('Waterlogging and Flooding', 'Exposed Electrical Wires', 'Public Property Damage')
          AND c.status NOT IN ('Resolved', 'Rejected')
        ORDER BY c.priority DESC, c.created_at DESC
        LIMIT 10
    ''')
    emergency_complaints = [dict(row) for row in cursor.fetchall()]
    db.close()
    
    return render_template('authority/disaster_mode.html', incidents=incidents, emergency_complaints=emergency_complaints)

# ==============================================================================
# HIERARCHICAL ROUTING & HIGHER OFFICIALS SUPERVISORY ROUTES (Section 33)
# ==============================================================================

@authority_bp.route('/authority/supervisory')
@role_required(['officer', 'admin'])
def supervisory_dashboard():
    """Higher Officials' Executive Command Dashboard (Tier 3 SE / Dept Head, Tier 4 Commissioner, Admin)."""
    user = get_current_user()
    tier = user.get('hierarchy_tier') or (4 if user['role'] == 'admin' else 1)
    
    # Run automatic escalation scan
    check_and_escalate_hierarchical()
    
    db = get_db()
    cursor = db.cursor()
    
    # 1. Complaints escalated to Tier 3 or Tier 4
    cursor.execute('''
        SELECT c.*, d.name as department_name, u.name as citizen_name, off.name as officer_name,
               j.name as jurisdiction_name
        FROM complaints c
        LEFT JOIN departments d ON c.department_id = d.id
        JOIN users u ON c.citizen_id = u.id
        LEFT JOIN users off ON c.assigned_officer_id = off.id
        LEFT JOIN administrative_jurisdictions j ON c.jurisdiction_id = j.id
        WHERE (c.current_hierarchy_level >= 3 OR c.escalation_level >= 2 OR c.supervisory_flag = 1)
          AND c.status NOT IN ('Resolved', 'Rejected')
        ORDER BY c.current_hierarchy_level DESC, c.is_overdue DESC, c.created_at ASC
    ''')
    escalated_complaints = [dict(row) for row in cursor.fetchall()]
    
    # 2. Critical Safety Hazards Unresolved
    cursor.execute('''
        SELECT c.*, d.name as department_name, u.name as citizen_name, off.name as officer_name
        FROM complaints c
        LEFT JOIN departments d ON c.department_id = d.id
        JOIN users u ON c.citizen_id = u.id
        LEFT JOIN users off ON c.assigned_officer_id = off.id
        WHERE c.priority = 'Critical' AND c.status NOT IN ('Resolved', 'Rejected')
        ORDER BY c.created_at ASC
        LIMIT 10
    ''')
    critical_issues = [dict(row) for row in cursor.fetchall()]
    
    # 3. Overdue Complaints
    cursor.execute('''
        SELECT c.*, d.name as department_name, off.name as officer_name
        FROM complaints c
        LEFT JOIN departments d ON c.department_id = d.id
        LEFT JOIN users off ON c.assigned_officer_id = off.id
        WHERE c.is_overdue = 1 AND c.status NOT IN ('Resolved', 'Rejected')
        ORDER BY c.escalation_level DESC, c.created_at ASC
        LIMIT 10
    ''')
    overdue_complaints = [dict(row) for row in cursor.fetchall()]
    
    # 4. Complaints awaiting field officer acknowledgment
    cursor.execute('''
        SELECT c.*, d.name as department_name, off.name as officer_name
        FROM complaints c
        LEFT JOIN departments d ON c.department_id = d.id
        LEFT JOIN users off ON c.assigned_officer_id = off.id
        WHERE c.acknowledged_at IS NULL AND c.status NOT IN ('Resolved', 'Rejected')
        ORDER BY c.created_at ASC
        LIMIT 10
    ''')
    unacknowledged_complaints = [dict(row) for row in cursor.fetchall()]
    
    # 5. Inter-Department Transfer Disputes
    cursor.execute('''
        SELECT ct.*, c.title as complaint_title, fd.name as from_dept_name, td.name as to_dept_name,
               u.name as initiated_by_name
        FROM complaint_transfers ct
        JOIN complaints c ON ct.complaint_id = c.id
        JOIN departments fd ON ct.from_dept_id = fd.id
        JOIN departments td ON ct.to_dept_id = td.id
        JOIN users u ON ct.transferred_by = u.id
        WHERE ct.status = 'Disputed'
        ORDER BY ct.created_at DESC
    ''')
    disputed_transfers = [dict(row) for row in cursor.fetchall()]
    
    # 6. Department Workload & Escalation Metrics
    cursor.execute('''
        SELECT d.id, d.name, d.code,
               COUNT(c.id) as total_active,
               SUM(CASE WHEN c.priority = 'Critical' THEN 1 ELSE 0 END) as critical_count,
               SUM(CASE WHEN c.is_overdue = 1 THEN 1 ELSE 0 END) as overdue_count,
               SUM(CASE WHEN c.current_hierarchy_level >= 3 THEN 1 ELSE 0 END) as escalated_count
        FROM departments d
        LEFT JOIN complaints c ON d.id = c.department_id AND c.status NOT IN ('Resolved', 'Rejected')
        WHERE d.active = 1
        GROUP BY d.id
        ORDER BY total_active DESC
    ''')
    department_workloads = [dict(row) for row in cursor.fetchall()]
    
    # 7. Recent Supervisory Directives
    cursor.execute('''
        SELECT si.*, c.title as complaint_title, u.name as issued_by_name
        FROM supervisory_instructions si
        JOIN complaints c ON si.complaint_id = c.id
        JOIN users u ON si.supervisor_id = u.id
        ORDER BY si.created_at DESC
        LIMIT 8
    ''')
    recent_instructions = [dict(row) for row in cursor.fetchall()]
    
    # 8. Geographic Hotspot Clusters
    cursor.execute('''
        SELECT location_address, ward, COUNT(*) as count,
               GROUP_CONCAT(id) as complaint_ids,
               MAX(priority) as top_priority
        FROM complaints
        WHERE status NOT IN ('Resolved', 'Rejected') AND location_address IS NOT NULL AND location_address != ''
        GROUP BY location_address
        HAVING count > 1
        ORDER BY count DESC
        LIMIT 5
    ''')
    hotspot_clusters = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute("SELECT id, name FROM departments WHERE active = 1")
    departments = [dict(row) for row in cursor.fetchall()]
    
    db.close()
    
    return render_template(
        'authority/supervisory.html',
        user=user,
        tier=tier,
        escalated_complaints=escalated_complaints,
        critical_issues=critical_issues,
        overdue_complaints=overdue_complaints,
        unacknowledged_complaints=unacknowledged_complaints,
        disputed_transfers=disputed_transfers,
        department_workloads=department_workloads,
        recent_instructions=recent_instructions,
        hotspot_clusters=hotspot_clusters,
        departments=departments
    )

@authority_bp.route('/authority/complaint/<id>/acknowledge', methods=['POST'])
@role_required(['officer', 'admin'])
def acknowledge_complaint_endpoint(id):
    """Allows an assigned field officer or authority to formally acknowledge a complaint."""
    user = get_current_user()
    notes = request.form.get('notes', '').strip()
    
    success, msg = acknowledge_complaint(id, user['id'], notes)
    if success:
        flash(msg, 'success')
    else:
        flash(msg, 'danger')
        
    return redirect(url_for('authority.complaint_review_detail', id=id))

@authority_bp.route('/authority/complaint/<id>/transfer', methods=['POST'])
@role_required(['officer', 'admin'])
def transfer_complaint_endpoint(id):
    """Initiates an inter-department transfer when the grievance is incorrectly classified."""
    user = get_current_user()
    to_dept_id = request.form.get('to_department_id')
    transfer_reason = request.form.get('transfer_reason', '').strip()
    
    if not to_dept_id or not transfer_reason:
        flash('Target department and transfer justification reason are mandatory.', 'warning')
        return redirect(url_for('authority.complaint_review_detail', id=id))
        
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT department_id FROM complaints WHERE id = ?', (id,))
    comp = cursor.fetchone()
    db.close()
    
    if not comp:
        flash('Complaint not found.', 'danger')
        return redirect(url_for('authority.complaints_list'))
        
    from_dept_id = comp['department_id'] or user.get('department_id') or 1
    
    success, msg = initiate_complaint_transfer(
        complaint_id=id,
        from_dept_id=int(from_dept_id),
        to_dept_id=int(to_dept_id),
        initiated_by_user_id=user['id'],
        reason=transfer_reason
    )
    
    if success:
        flash(msg, 'success')
    else:
        flash(msg, 'danger')
        
    return redirect(url_for('authority.complaint_review_detail', id=id))

@authority_bp.route('/authority/transfers')
@role_required(['officer', 'admin'])
def transfers_queue():
    """Displays inter-department transfer requests (incoming, outgoing, disputed, resolved)."""
    user = get_current_user()
    db = get_db()
    cursor = db.cursor()
    
    dept_id = user['department_id'] if user['role'] == 'officer' and user.get('hierarchy_tier', 1) < 3 else None
    
    where_filter = ""
    params = []
    if dept_id:
        where_filter = "WHERE ct.from_dept_id = ? OR ct.to_dept_id = ?"
        params = [dept_id, dept_id]
        
    cursor.execute(f'''
        SELECT ct.*, c.title as complaint_title, c.category, c.status as complaint_status,
               c.priority as complaint_priority,
               fd.name as from_dept_name, td.name as to_dept_name,
               u.name as initiated_by_name
        FROM complaint_transfers ct
        JOIN complaints c ON ct.complaint_id = c.id
        JOIN departments fd ON ct.from_dept_id = fd.id
        JOIN departments td ON ct.to_dept_id = td.id
        JOIN users u ON ct.transferred_by = u.id
        {where_filter}
        ORDER BY 
            CASE ct.status 
                WHEN 'Pending' THEN 1 
                WHEN 'Disputed' THEN 2 
                ELSE 3 
            END,
            ct.created_at DESC
    ''', params)
    transfers = [dict(row) for row in cursor.fetchall()]
    
    cursor.execute("SELECT id, name FROM departments WHERE active = 1")
    departments = [dict(row) for row in cursor.fetchall()]
    
    db.close()
    
    return render_template(
        'authority/transfers.html',
        user=user,
        transfers=transfers,
        departments=departments
    )

@authority_bp.route('/authority/transfer/<int:transfer_id>/respond', methods=['POST'])
@role_required(['officer', 'admin'])
def respond_transfer_endpoint(transfer_id):
    """Receiving department accepts or disputes a proposed transfer."""
    user = get_current_user()
    action = request.form.get('action') # 'Accept' or 'Dispute'
    notes = request.form.get('notes', '').strip()
    
    if action not in ['Accept', 'Dispute']:
        flash('Invalid transfer response action.', 'danger')
        return redirect(url_for('authority.transfers_queue'))
        
    success, msg = respond_to_department_transfer(
        transfer_id=transfer_id,
        user_id=user['id'],
        action=action,
        notes=notes
    )
    
    if success:
        flash(msg, 'success')
    else:
        flash(msg, 'danger')
        
    return redirect(url_for('authority.transfers_queue'))

@authority_bp.route('/authority/transfer/<int:transfer_id>/resolve_dispute', methods=['POST'])
@role_required(['officer', 'admin'])
def resolve_transfer_dispute_endpoint(transfer_id):
    """Supervisory / Ombudsman binding resolution on a disputed department transfer."""
    user = get_current_user()
    tier = user.get('hierarchy_tier') or (4 if user['role'] == 'admin' else 1)
    
    if tier < 3 and user['role'] != 'admin':
        flash('Binding dispute resolution requires Tier 3 (Department Head) or Tier 4 (Ombudsman/Commissioner) clearance.', 'danger')
        return redirect(url_for('authority.transfers_queue'))
        
    final_dept_id = request.form.get('final_department_id')
    binding_notes = request.form.get('binding_notes', '').strip()
    
    if not final_dept_id or not binding_notes:
        flash('Final assigned department and binding decision notes are required.', 'warning')
        return redirect(url_for('authority.transfers_queue'))
        
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT * FROM complaint_transfers WHERE id = ?', (transfer_id,))
    t_row = cursor.fetchone()
    if not t_row:
        db.close()
        flash('Transfer record not found.', 'danger')
        return redirect(url_for('authority.transfers_queue'))
        
    complaint_id = t_row['complaint_id']
    cursor.execute('SELECT name FROM departments WHERE id = ?', (final_dept_id,))
    dept_row = cursor.fetchone()
    dept_name = dept_row['name'] if dept_row else "Assigned Department"
    
    cursor.execute('''
        UPDATE complaint_transfers
        SET status = 'Resolved',
            binding_resolution_notes = ?,
            resolved_by = ?,
            resolved_at = CURRENT_TIMESTAMP
        WHERE id = ?
    ''', (binding_notes, user['id'], transfer_id))
    
    cursor.execute('''
        UPDATE complaints
        SET department_id = ?,
            status = 'Assigned',
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    ''', (final_dept_id, complaint_id))
    
    cursor.execute('''
        INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes)
        VALUES (?, 'Transferred', 'Assigned', ?, ?)
    ''', (complaint_id, user['id'], f"Ombudsman/Supervisory Binding Dispute Resolution: Allocated to {dept_name}. Notes: {binding_notes}"))
    
    db.commit()
    log_audit(user['id'], "TRANSFER_DISPUTE_RESOLVED", "complaint_transfers", transfer_id, f"Resolved to {dept_name}")
    db.close()
    
    flash(f"Ownership dispute resolved. Complaint {complaint_id} definitively assigned to {dept_name}.", 'success')
    return redirect(url_for('authority.transfers_queue'))

@authority_bp.route('/authority/complaint/<id>/instruction', methods=['POST'])
@role_required(['officer', 'admin'])
def issue_supervisory_instruction_endpoint(id):
    """Senior Official (Tier 3/4/Admin) issues an authoritative instruction, show-cause, or field inspection directive."""
    user = get_current_user()
    tier = user.get('hierarchy_tier') or (4 if user['role'] == 'admin' else 1)
    
    if tier < 3 and user['role'] != 'admin':
        flash('Issuing supervisory instructions requires Tier 3 (Superintending Engineer) or Tier 4 (Commissioner) rank.', 'danger')
        return redirect(url_for('authority.complaint_review_detail', id=id))
        
    instruction_type = request.form.get('instruction_type', 'Directive')
    instruction_text = request.form.get('instruction_text', '').strip()
    deadline_hours_str = request.form.get('deadline_hours', '').strip()
    deadline_hours = int(deadline_hours_str) if deadline_hours_str and deadline_hours_str.isdigit() else None
    is_public = 1 if request.form.get('is_public_to_citizen') == '1' else 0
    
    if not instruction_text:
        flash('Instruction text cannot be empty.', 'warning')
        return redirect(url_for('authority.complaint_review_detail', id=id))
        
    success, msg = create_supervisory_instruction(
        complaint_id=id,
        issued_by_user_id=user['id'],
        instruction_type=instruction_type,
        instruction_text=instruction_text,
        deadline_hours=deadline_hours,
        is_public_to_citizen=is_public
    )
    
    if success:
        flash(msg, 'success')
    else:
        flash(msg, 'danger')
        
    return redirect(url_for('authority.complaint_review_detail', id=id))

@authority_bp.route('/authority/instruction/<int:instruction_id>/respond', methods=['POST'])
@role_required(['officer', 'admin'])
def respond_supervisory_instruction_endpoint(instruction_id):
    """Field officer submits formal compliance explanation or completion report to a supervisory directive."""
    user = get_current_user()
    compliance_notes = request.form.get('compliance_notes', '').strip()
    
    if not compliance_notes:
        flash('Compliance report / explanation notes are required.', 'warning')
        return redirect(request.referrer or url_for('authority.dashboard'))
        
    success, msg = respond_to_supervisory_instruction(instruction_id, user['id'], compliance_notes)
    
    if success:
        flash(msg, 'success')
    else:
        flash(msg, 'danger')
        
    return redirect(request.referrer or url_for('authority.dashboard'))

@authority_bp.route('/authority/complaint/<id>/evidence/<int:evidence_id>/review', methods=['POST'])
@role_required(['officer', 'admin'])
def review_evidence_endpoint(id, evidence_id):
    """
    Officer or Admin records formal forensic review on photographic or video evidence.
    Allows manual verification, flagging as synthetic/manipulated, or ordering on-site physical re-inspection.
    """
    user = get_current_user()
    manual_status = request.form.get('manual_status', 'Verified by Officer')
    review_notes = request.form.get('review_notes', '').strip()
    
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT * FROM complaint_images WHERE id = ? AND complaint_id = ?', (evidence_id, id))
    img = cursor.fetchone()
    if not img:
        db.close()
        flash('Evidence record not found.', 'danger')
        return redirect(url_for('authority.complaint_review_detail', id=id))

    cursor.execute('''
        UPDATE complaint_images
        SET manual_review_status = ?,
            manual_review_notes = ?,
            manual_reviewed_by = ?,
            manual_reviewed_at = CURRENT_TIMESTAMP
        WHERE id = ?
    ''', (manual_status, review_notes, user['id'], evidence_id))
    
    cursor.execute('''
        INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes)
        VALUES (?, (SELECT status FROM complaints WHERE id = ?), (SELECT status FROM complaints WHERE id = ?), ?, ?)
    ''', (id, id, id, user['id'], f"OFFICER FORENSIC REVIEW: Evidence #{evidence_id} marked as '{manual_status}'. Officer Notes: {review_notes or 'Standard forensic validation completed.'}"))
    
    db.commit()
    db.close()
    
    flash(f"Forensic review recorded for Evidence #{evidence_id}: {manual_status}.", 'success')
    return redirect(url_for('authority.complaint_review_detail', id=id))

@authority_bp.route('/authority/complaint/<id>/export_gov_package')
@role_required(['officer', 'admin'])
def export_complaint_gov_package_endpoint(id):
    """Exports standardized CPGRAMS / NIC format data exchange package for governmental interoperability."""
    package = export_complaint_gov_package(id)
    if not package:
        flash('Unable to compile government data package for this grievance.', 'danger')
        return redirect(url_for('authority.complaint_review_detail', id=id))
        
    return jsonify(package)
