from flask import Blueprint, render_template, request, session, redirect, url_for
from database import get_db
from services.analytics_service import get_public_kpis
from services.i18n import get_text, SUPPORTED_LANGUAGES
from config import Config

public_bp = Blueprint('public', __name__)

@public_bp.route('/')
def index():
    kpis = get_public_kpis()
    
    db = get_db()
    cursor = db.cursor()
    
    # Fetch recent reported complaints (non-sensitive fields)
    cursor.execute('''
        SELECT id, category, title, description, location_address, ward, status, priority, created_at,
               (SELECT filename FROM complaint_images WHERE complaint_id = complaints.id LIMIT 1) as image_filename
        FROM complaints
        ORDER BY created_at DESC
        LIMIT 6
    ''')
    recent_complaints = [dict(row) for row in cursor.fetchall()]
    
    # Fetch verified resolved cases with before and after photos
    cursor.execute('''
        SELECT c.id, c.category, c.title, c.location_address, c.ward, c.resolution_notes, c.citizen_rating, c.updated_at,
               (SELECT filename FROM complaint_images WHERE complaint_id = c.id AND image_type = 'evidence' LIMIT 1) as before_image,
               (SELECT filename FROM complaint_images WHERE complaint_id = c.id AND image_type = 'resolution' LIMIT 1) as after_image
        FROM complaints c
        WHERE c.status = 'Resolved' AND c.resolution_notes IS NOT NULL
        ORDER BY c.updated_at DESC
        LIMIT 3
    ''')
    resolved_cases = [dict(row) for row in cursor.fetchall()]
    
    # Check disaster mode setting
    cursor.execute("SELECT value FROM system_settings WHERE key = 'disaster_mode'")
    row = cursor.fetchone()
    disaster_mode = (row['value'].lower() == 'true') if row else False
    
    db.close()
    
    lang = session.get('lang', 'en')
    return render_template(
        'public/index.html',
        kpis=kpis,
        recent_complaints=recent_complaints,
        resolved_cases=resolved_cases,
        disaster_mode=disaster_mode,
        categories=Config.CATEGORIES,
        lang=lang
    )

@public_bp.route('/map')
def public_map():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT id, name FROM departments WHERE active = 1")
    departments = [dict(row) for row in cursor.fetchall()]
    db.close()
    
    return render_template(
        'public/public_map.html',
        categories=Config.CATEGORIES,
        departments=departments
    )

@public_bp.route('/transparency')
def transparency():
    kpis = get_public_kpis()
    db = get_db()
    cursor = db.cursor()
    
    # Department performance
    cursor.execute('''
        SELECT d.name, COUNT(c.id) as total,
               SUM(CASE WHEN c.status = 'Resolved' THEN 1 ELSE 0 END) as resolved,
               SUM(CASE WHEN c.citizen_confirmed = 1 THEN 1 ELSE 0 END) as confirmed,
               AVG(c.citizen_rating) as rating
        FROM departments d
        LEFT JOIN complaints c ON d.id = c.department_id
        GROUP BY d.id
    ''')
    dept_breakdown = [dict(row) for row in cursor.fetchall()]
    db.close()
    
    return render_template('public/transparency.html', kpis=kpis, dept_breakdown=dept_breakdown)

@public_bp.route('/help')
def help_page():
    return render_template('public/help.html')

@public_bp.route('/set_lang/<lang>')
def set_lang(lang):
    if lang in SUPPORTED_LANGUAGES:
        session['lang'] = lang
    return redirect(request.referrer or url_for('public.index'))

