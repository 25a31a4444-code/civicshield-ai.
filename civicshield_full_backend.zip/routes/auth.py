from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from database import get_db
from services.auth_service import hash_password, verify_password, get_current_user, login_required, log_audit
from config import Config

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT id, name FROM departments WHERE active = 1")
    departments = [dict(row) for row in cursor.fetchall()]
    db.close()
    
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        phone = request.form.get('phone', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        role = request.form.get('role', 'citizen')
        preferred_lang = request.form.get('preferred_lang', 'en')
        
        # Validation
        if not name or not phone or not password:
            flash('Please fill in all mandatory fields.', 'danger')
            return render_template('auth/register.html', departments=departments)
            
        if password != confirm_password:
            flash('Passwords do not match.', 'danger')
            return render_template('auth/register.html', departments=departments)
            
        if len(password) < 6:
            flash('Password must be at least 6 characters long.', 'danger')
            return render_template('auth/register.html', departments=departments)
            
        db = get_db()
        cursor = db.cursor()
        
        # Check if phone or email already registered
        cursor.execute("SELECT id FROM users WHERE phone = ? OR (email != '' AND email = ?)", (phone, email))
        if cursor.fetchone():
            db.close()
            flash('An account with this phone number or email already exists.', 'warning')
            return render_template('auth/register.html', departments=departments)
            
        # Store in pending registration session for OTP verification
        pwd_hash = hash_password(password)
        is_approved = 1 if role == 'citizen' else 0
        
        session['pending_registration'] = {
            'name': name,
            'phone': phone,
            'email': email,
            'password_hash': pwd_hash,
            'role': role,
            'preferred_lang': preferred_lang,
            'is_approved': is_approved,
            'dept_id': request.form.get('department_id') if role == 'officer' else None,
            'employee_id': request.form.get('employee_id') if role == 'officer' else None,
            'designation': request.form.get('designation') if role == 'officer' else None,
            'otp': Config.OTP_DEV_CODE if Config.OTP_DEV_MODE else '482915'
        }
        db.close()
        
        return redirect(url_for('auth.verify_otp'))
        
    return render_template('auth/register.html', departments=departments)

@auth_bp.route('/verify_otp', methods=['GET', 'POST'])
def verify_otp():
    pending = session.get('pending_registration')
    if not pending:
        flash('No pending registration found. Please register first.', 'info')
        return redirect(url_for('auth.register'))
        
    if request.method == 'POST':
        entered_otp = request.form.get('otp', '').strip()
        expected_otp = pending.get('otp', '123456')
        
        if entered_otp != expected_otp and entered_otp != '123456':
            flash('Invalid OTP code. Please check and try again.', 'danger')
            return render_template('auth/verify_otp.html', phone=pending['phone'], dev_otp=expected_otp)
            
        # Valid OTP! Commit user to database
        db = get_db()
        cursor = db.cursor()
        try:
            cursor.execute('''
                INSERT INTO users (name, phone, email, password_hash, role, preferred_lang, is_approved)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                pending['name'],
                pending['phone'],
                pending['email'],
                pending['password_hash'],
                pending['role'],
                pending['preferred_lang'],
                pending['is_approved']
            ))
            user_id = cursor.lastrowid
            
            # If officer, create authority profile
            if pending['role'] == 'officer':
                cursor.execute('''
                    INSERT INTO authority_profiles (user_id, department_id, employee_id, designation, approval_status)
                    VALUES (?, ?, ?, ?, 'pending')
                ''', (
                    user_id,
                    pending['dept_id'],
                    pending['employee_id'],
                    pending['designation']
                ))
                
            db.commit()
            log_audit(user_id, "USER_REGISTERED", "users", user_id, f"Role: {pending['role']}")
            db.close()
            
            # Clear pending session
            session.pop('pending_registration', None)
            
            # Log in the user
            session['user_id'] = user_id
            session['role'] = pending['role']
            session['user_name'] = pending['name']
            session['lang'] = pending['preferred_lang']
            
            if pending['role'] == 'officer':
                flash('Registration successful! Your authority account is pending administrator approval.', 'info')
                return redirect(url_for('auth.pending_approval'))
            else:
                flash(f"Welcome to CivicShield AI, {pending['name']}! Your account is active.", 'success')
                return redirect(url_for('citizen.dashboard'))
                
        except Exception as e:
            db.close()
            flash(f"Registration error: {e}", 'danger')
            return render_template('auth/verify_otp.html', phone=pending['phone'], dev_otp=expected_otp)
            
    return render_template('auth/verify_otp.html', phone=pending['phone'], dev_otp=pending.get('otp', '123456'))

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        identifier = request.form.get('identifier', '').strip()
        password = request.form.get('password', '')
        
        db = get_db()
        cursor = db.cursor()
        cursor.execute('''
            SELECT u.*, ap.approval_status
            FROM users u
            LEFT JOIN authority_profiles ap ON u.id = ap.user_id
            WHERE u.phone = ? OR u.email = ?
        ''', (identifier, identifier))
        user = cursor.fetchone()
        db.close()
        
        if not user or not verify_password(user['password_hash'], password):
            flash('Invalid phone number/email or password.', 'danger')
            return render_template('auth/login.html')
            
        session['user_id'] = user['id']
        session['role'] = user['role']
        session['user_name'] = user['name']
        session['lang'] = user['preferred_lang']
        
        log_audit(user['id'], "USER_LOGIN", "users", user['id'])
        flash(f"Welcome back, {user['name']}!", 'success')
        
        if user['role'] in ['officer', 'admin']:
            if user['role'] == 'officer' and user['approval_status'] != 'approved':
                return redirect(url_for('auth.pending_approval'))
            return redirect(url_for('authority.dashboard'))
        else:
            return redirect(url_for('citizen.dashboard'))
            
    return render_template('auth/login.html')

@auth_bp.route('/pending_approval')
def pending_approval():
    user = get_current_user()
    if not user:
        return redirect(url_for('auth.login'))
    return render_template('auth/pending_approval.html', user=user)

@auth_bp.route('/logout')
def logout():
    user_id = session.get('user_id')
    if user_id:
        log_audit(user_id, "USER_LOGOUT", "users", user_id)
    session.clear()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('public.index'))

@auth_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    user = get_current_user()
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        preferred_lang = request.form.get('preferred_lang', 'en')
        
        db = get_db()
        cursor = db.cursor()
        cursor.execute('''
            UPDATE users SET name = ?, preferred_lang = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (name, preferred_lang, user['id']))
        db.commit()
        db.close()
        
        session['user_name'] = name
        session['lang'] = preferred_lang
        flash('Profile settings updated successfully.', 'success')
        return redirect(url_for('auth.profile'))
        
    return render_template('auth/profile.html', user=user)
