import pytest
import os
import sys

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, BASE_DIR)

from app import create_app
from database import get_db, init_db
from services.auth_service import hash_password, verify_password

@pytest.fixture
def client():
    app = create_app()
    app.config['TESTING'] = True
    app.config['SECRET_KEY'] = 'test-key'
    with app.test_client() as client:
        yield client

def test_password_hashing():
    pwd = "SecurePassword123"
    hashed = hash_password(pwd)
    assert hashed != pwd
    assert verify_password(hashed, pwd) is True
    assert verify_password(hashed, "WrongPassword") is False

def test_public_homepage(client):
    response = client.get('/')
    assert response.status_code == 200
    assert b"CivicShield" in response.data
    assert b"Your City. Your Voice." in response.data

def test_user_login_citizen(client):
    # Seed user Rahul Sharma (9876543210 / demo123)
    response = client.post('/login', data={
        'identifier': '9876543210',
        'password': 'demo123'
    }, follow_redirects=True)
    assert response.status_code == 200
    assert b"Rahul" in response.data or b"Dashboard" in response.data

def test_user_login_invalid(client):
    response = client.post('/login', data={
        'identifier': '9876543210',
        'password': 'invalid_password'
    }, follow_redirects=True)
    assert b"Invalid phone number/email or password." in response.data

def test_role_protected_endpoint_without_login(client):
    response = client.get('/citizen/dashboard', follow_redirects=True)
    assert b"Please log in to access this page." in response.data or response.status_code == 200
