import pytest
import os
import sys

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, BASE_DIR)

from services.ai_service import classify_complaint, normalize_telugu_text, assess_image_authenticity
from config import Config

def test_classify_pothole():
    result = classify_complaint(
        title="Deep dangerous pothole on highway",
        description="Two-wheelers are skidding into a 15cm road crater at night."
    )
    assert result['available'] is True
    assert result['predicted_category'] == "Potholes and Damaged Roads"
    assert result['severity_level'] in ["High", "Critical"]
    assert result['risk_score'] >= 50
    assert any("Two-Wheeler" in h for h in result['hazard_flags'])
    assert result['recommended_dept_name'] == "Roads and Engineering"

def test_classify_live_wire_critical():
    result = classify_complaint(
        title="Dangling live wire sparking",
        description="High voltage cable fell on bus stop shelter creating shock hazard."
    )
    assert result['available'] is True
    assert result['predicted_category'] == "Exposed Electrical Wires"
    assert result['severity_level'] == "Critical"
    assert result['risk_score'] >= 80
    assert any("Electrocution" in h for h in result['hazard_flags'])

def test_telugu_text_normalization():
    text_te = "రోడ్డు మీద పెద్ద గుంతలు ఉన్నాయి మరియు చెత్త కుప్పగా ఉంది"
    normalized, has_te = normalize_telugu_text(text_te)
    assert has_te is True
    assert "pothole" in normalized or "garbage" in normalized

def test_image_authenticity_service():
    test_img = os.path.join(Config.UPLOAD_FOLDER, 'demo_pothole_before.jpg')
    result = assess_image_authenticity(test_img)
    assert 'status' in result
    assert result['confidence'] >= 0.50
