import pytest
import os
import sys
import json
import numpy as np
import cv2

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, BASE_DIR)

from app import create_app
from config import Config
from database import get_db
from services.authenticity_service import (
    calculate_dhash,
    hamming_distance,
    check_duplicate_evidence,
    extract_exif_metadata,
    analyze_photo_authenticity,
    analyze_video_authenticity,
    assess_media_authenticity
)

@pytest.fixture
def app():
    app = create_app()
    app.config['TESTING'] = True
    yield app

@pytest.fixture
def client(app):
    return app.test_client()

# ------------------------------------------------------------------------------
# 1. Perceptual Difference Hashing (dHash) and Duplicate Evidence Detection
# ------------------------------------------------------------------------------
def test_dhash_calculation_and_hamming_distance():
    # Create two nearly identical images
    img1 = np.zeros((100, 100, 3), dtype=np.uint8)
    cv2.circle(img1, (50, 50), 20, (255, 255, 255), -1)

    img2 = np.zeros((100, 100, 3), dtype=np.uint8)
    cv2.circle(img2, (50, 50), 22, (255, 255, 255), -1) # tiny variation

    # Create completely different image
    img3 = np.zeros((100, 100, 3), dtype=np.uint8)
    cv2.line(img3, (0, 0), (99, 99), (255, 255, 255), 5)

    h1 = calculate_dhash(img1)
    h2 = calculate_dhash(img2)
    h3 = calculate_dhash(img3)

    assert h1 is not None and len(h1) == 16
    assert h2 is not None and len(h2) == 16
    assert h3 is not None and len(h3) == 16

    # h1 and h2 should have low Hamming distance (near duplicates)
    dist_near = hamming_distance(h1, h2)
    dist_diff = hamming_distance(h1, h3)

    assert dist_near <= 6
    assert dist_diff > dist_near

# ------------------------------------------------------------------------------
# 2. Photo Forensic Authenticity Analysis (Sharpness, Artifacts, Civic Issue)
# ------------------------------------------------------------------------------
def test_photo_authenticity_analysis():
    demo_path = os.path.join(Config.UPLOAD_FOLDER, 'demo_pothole_before.jpg')
    result = analyze_photo_authenticity(demo_path)

    assert result['media_type'] == 'photo'
    assert result['verdict'] in ['Likely Authentic', 'Potentially AI-Generated or Manipulated', 'Inconclusive']
    assert 0.50 <= result['confidence'] <= 0.98
    assert result['blur_score'] > 0
    assert result['quality_rating'] in ['Crisp Optical Focus', 'Normal Focus', 'Moderate Sharpness', 'High-Frequency Edge Contrast', 'Blurry / Low Focus']
    assert 'SHA-256' in str(result) or len(result['file_hash']) == 64
    assert result['detected_issue']['category'] in Config.CATEGORIES
    assert 'CivicShield Forensic' in result['model_name']

# ------------------------------------------------------------------------------
# 3. Video Forensic Analysis: Duration, Frame Extraction, and Temporal Coherence
# ------------------------------------------------------------------------------
def test_video_authenticity_and_keyframe_extraction():
    # Synthesize a realistic 2-second civic test video
    test_video_path = os.path.join(Config.UPLOAD_FOLDER, 'test_synthetic_pothole.mp4')
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(test_video_path, fourcc, 15.0, (320, 240))
    
    for i in range(30):
        frame = np.full((240, 320, 3), (60 + i, 55, 50), dtype=np.uint8)
        # Draw a road pothole cavity
        cv2.circle(frame, (160, 120), 40, (30, 25, 20), -1)
        cv2.putText(frame, f"Road Frame {i}", (20, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)
        out.write(frame)
    out.release()

    res = analyze_video_authenticity(test_video_path)

    # Clean up test video
    if os.path.exists(test_video_path):
        os.remove(test_video_path)

    assert res['media_type'] == 'video'
    assert res['verdict'] in ['Likely Authentic', 'Potentially AI-Generated or Manipulated', 'Inconclusive']
    assert res['duration_seconds'] >= 1.5
    assert len(res['extracted_keyframes']) >= 3
    assert res['temporal_coherence'] >= 0.50
    assert res['detected_issue']['category'] in Config.CATEGORIES

    # Verify extracted keyframe files exist on disk
    for kf_url in res['extracted_keyframes']:
        disk_path = os.path.join(Config.BASE_DIR, kf_url.lstrip('/'))
        assert os.path.exists(disk_path)
        # Clean up keyframe
        if os.path.exists(disk_path):
            os.remove(disk_path)

# ------------------------------------------------------------------------------
# 4. Real-time API Endpoint: /api/analyze-evidence (Photo and Video)
# ------------------------------------------------------------------------------
def test_api_analyze_evidence_endpoint(client):
    demo_path = os.path.join(Config.UPLOAD_FOLDER, 'demo_garbage_before.jpg')
    with open(demo_path, 'rb') as f:
        response = client.post(
            '/api/analyze-evidence',
            data={'file': (f, 'test_garbage.jpg')},
            content_type='multipart/form-data'
        )

    assert response.status_code == 200
    data = response.get_json()
    assert data['success'] is True
    assert data['media_type'] == 'photo'
    assert data['verdict'] in ['Likely Authentic', 'Potentially AI-Generated or Manipulated', 'Inconclusive']
    assert 'blur_score' in data
    assert 'detected_issue' in data
    assert 'duplicate_check' in data

# ------------------------------------------------------------------------------
# 5. Unsupported Media Format Handling
# ------------------------------------------------------------------------------
def test_api_unsupported_format_rejection(client):
    import io
    response = client.post(
        '/api/analyze-evidence',
        data={'file': (io.BytesIO(b"fake executable payload"), 'malicious.exe')},
        content_type='multipart/form-data'
    )
    assert response.status_code == 400
    data = response.get_json()
    assert data['success'] is False
    assert "Unsupported media format" in data['message']

# ------------------------------------------------------------------------------
# 6. Citizen Supplementary Evidence Submission (/citizen/complaint/<id>/add-evidence)
# ------------------------------------------------------------------------------
def test_citizen_add_supplementary_evidence(client):
    with client.session_transaction() as sess:
        sess['user_id'] = 1
        sess['user_role'] = 'citizen'

    complaint_id = "CIVIC-2026-00101"
    demo_path = os.path.join(Config.UPLOAD_FOLDER, 'demo_wire_before.jpg')

    with open(demo_path, 'rb') as f:
        response = client.post(
            f'/citizen/complaint/{complaint_id}/add-evidence',
            data={'evidence': (f, 'supplementary_wire.jpg')},
            content_type='multipart/form-data',
            follow_redirects=True
        )

    assert response.status_code == 200
    assert b"new evidence" in response.data or b"authenticity" in response.data

    # Verify database has supplementary evidence logged
    db = get_db()
    cursor = db.cursor()
    cursor.execute('''
        SELECT * FROM complaint_images
        WHERE complaint_id = ? AND filename LIKE 'supp_%'
        ORDER BY id DESC LIMIT 1
    ''', (complaint_id,))
    img_row = cursor.fetchone()
    db.close()

    assert img_row is not None
    assert img_row['is_authentic_flag'] in ['Likely Authentic', 'Potentially AI-Generated or Manipulated', 'Inconclusive']
    assert img_row['blur_score'] is not None

# ------------------------------------------------------------------------------
# 7. Officer Manual Authenticity Verification Review (/authority/complaint/<id>/evidence/<id>/review)
# ------------------------------------------------------------------------------
def test_officer_manual_authenticity_review(client):
    with client.session_transaction() as sess:
        sess['user_id'] = 3
        sess['user_role'] = 'officer'

    complaint_id = "CIVIC-2026-00101"

    # Get an evidence image id
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT id FROM complaint_images WHERE complaint_id = ? LIMIT 1", (complaint_id,))
    evidence_id = cursor.fetchone()['id']
    db.close()

    response = client.post(
        f'/authority/complaint/{complaint_id}/evidence/{evidence_id}/review',
        data={
            'manual_status': 'Verified by Officer',
            'review_notes': 'Physical site inspection confirmed road crater dimensions match photographic evidence.'
        },
        follow_redirects=True
    )

    assert response.status_code == 200
    assert b"Forensic review recorded" in response.data

    # Verify updated in database
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT manual_review_status, manual_review_notes FROM complaint_images WHERE id = ?", (evidence_id,))
    updated_evidence = cursor.fetchone()
    db.close()

    assert updated_evidence['manual_review_status'] == 'Verified by Officer'
    assert 'Physical site inspection' in updated_evidence['manual_review_notes']
