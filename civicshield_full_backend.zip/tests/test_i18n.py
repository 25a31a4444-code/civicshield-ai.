import pytest
from services.i18n import get_text, SUPPORTED_LANGUAGES, TRANSLATIONS

def test_supported_languages_list():
    expected_langs = ['en', 'hi', 'te', 'ta', 'kn', 'ml', 'mr', 'bn', 'gu', 'pa', 'ur', 'or']
    for lang in expected_langs:
        assert lang in SUPPORTED_LANGUAGES
        assert 'name' in SUPPORTED_LANGUAGES[lang]
        assert 'native' in SUPPORTED_LANGUAGES[lang]
        assert 'flag' in SUPPORTED_LANGUAGES[lang]

def test_translations_coverage():
    core_keys = [
        'nav_home', 'nav_report', 'nav_map', 'nav_my_complaints', 'nav_dashboard',
        'status_submitted', 'status_resolved', 'priority_critical',
        'cat_potholes', 'cat_garbage', 'cat_water', 'btn_submit'
    ]
    for lang_code in SUPPORTED_LANGUAGES:
        assert lang_code in TRANSLATIONS
        for key in core_keys:
            val = get_text(key, lang=lang_code)
            assert val is not None
            assert len(val.strip()) > 0

def test_fallback_to_english():
    # Non-existent key falls back to key or English
    assert get_text('non_existent_key_xyz', lang='hi') == 'non_existent_key_xyz'
    # Fallback to English when key missing in specific language
    assert get_text('nav_home', lang='unknown_lang') == 'Home'
