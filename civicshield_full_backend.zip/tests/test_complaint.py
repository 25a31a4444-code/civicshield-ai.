import pytest
import os
import sys
import io

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, BASE_DIR)

from app import create_app
from database import get_db

@pytest.fixture
def auth_client():
    app = create_app()
    app.config['TESTING'] = True
    app.config['SECRET_KEY'] = 'test-key'
    with app.test_client() as client:
        # Log in as Rahul Sharma (Citizen)
        with client.session_transaction() as sess:
            sess['user_id'] = 1
            sess['role'] = 'citizen'
            sess['user_name'] = 'Rahul Sharma'
            sess['lang'] = 'en'
        yield client

def test_report_issue_submission(auth_client):
    test_image = (io.BytesIO(b"fake image bytes content"), 'test_pothole.jpg')
    response = auth_client.post('/citizen/report', data={
        'category': 'Potholes and Damaged Roads',
        'ward': 'Ward 12 - Central',
        'title': 'Test Hazardous Pothole Near Metro',
        'description': 'Deep road cavity causing skid risk for motorists and cyclists.',
        'location_address': 'Jubilee Hills Road No. 36',
        'latitude': '17.4312',
        'longitude': '78.4072',
        'images': [test_image]
    }, follow_redirects=True)
    
    assert response.status_code == 200
    assert b"successfully submitted" in response.data or b"CIVIC-2026-" in response.data

def test_view_complaint_detail(auth_client):
    response = auth_client.get('/citizen/complaint/CIVIC-2026-00101')
    assert response.status_code == 200
    assert b"CIVIC-2026-00101" in response.data
    assert b"Potholes and Damaged Roads" in response.data
    assert b"Resolution Progress Tracker" in response.data

def test_community_support_api(auth_client):
    response = auth_client.post('/api/support_complaint/CIVIC-2026-00101')
    assert response.status_code == 200
    json_data = response.get_json()
    assert json_data['success'] is True

def test_citizen_submit_appeal(auth_client):
    response = auth_client.post('/citizen/appeal/CIVIC-2026-00101', data={
        'appeal_reason': 'The pavement repair requires full foundation resurfacing.'
    }, follow_redirects=True)
    assert response.status_code == 200
    assert b"appeal has been submitted" in response.data
