import pytest
import os
import sys

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, BASE_DIR)

from services.duplicate_service import haversine_distance, text_similarity, find_potential_duplicates

def test_haversine_distance_calculation():
    # Hyderabad Checkpost: (17.4312, 78.4072)
    # Approx 100 meters away: (17.4315, 78.4075)
    dist = haversine_distance(17.4312, 78.4072, 17.4315, 78.4075)
    assert 30 <= dist <= 120

def test_text_similarity():
    t1 = "deep pothole causing vehicle accidents on main road"
    t2 = "large pothole road crater near transit corridor"
    sim = text_similarity(t1, t2)
    assert sim > 0.15

def test_find_potential_duplicates():
    # Search near seeded Road 36 pothole (17.4312, 78.4072)
    matches = find_potential_duplicates(
        category="Potholes and Damaged Roads",
        latitude=17.4314,
        longitude=78.4073,
        description="Pothole near metro pillar 1420",
        radius_meters=200
    )
    assert len(matches) > 0
    assert matches[0]['id'] == 'CIVIC-2026-00101'
