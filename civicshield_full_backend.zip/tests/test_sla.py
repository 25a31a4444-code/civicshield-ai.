import pytest
import os
import sys

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, BASE_DIR)

from services.sla_service import calculate_sla_deadlines, check_and_escalate_overdue
from database import get_db

def test_sla_deadline_calculation():
    ack_crit, res_crit = calculate_sla_deadlines("Critical")
    ack_low, res_low = calculate_sla_deadlines("Low")
    
    assert ack_crit < res_crit
    assert ack_crit < ack_low
    assert res_crit < res_low

def test_overdue_escalation_detection():
    # Run SLA overdue check against seeded database
    escalated = check_and_escalate_overdue()
    
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT id, is_overdue, escalation_level FROM complaints WHERE id = 'CIVIC-2026-00102'")
    comp = cursor.fetchone()
    db.close()
    
    assert comp['is_overdue'] == 1
    assert comp['escalation_level'] >= 1
