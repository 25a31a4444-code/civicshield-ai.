import pytest
import os
import sys
from datetime import datetime, timedelta

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, BASE_DIR)

from app import app
from database import get_db
from services.hierarchy_service import (
    resolve_jurisdiction_and_routing,
    acknowledge_complaint,
    create_supervisory_instruction,
    respond_to_supervisory_instruction,
    initiate_complaint_transfer,
    respond_to_department_transfer,
    check_and_escalate_hierarchical
)
from services.government_integration import export_complaint_gov_package

@pytest.fixture
def client():
    app.config['TESTING'] = True
    app.config['WTF_CSRF_ENABLED'] = False
    with app.test_client() as client:
        yield client

# ------------------------------------------------------------------------------
# 1. New complaint reaches correct configured department
# ------------------------------------------------------------------------------
def test_scenario_1_department_identification():
    # Test Pothole routing -> Department 1 (Roads and Engineering)
    pothole_routing = resolve_jurisdiction_and_routing(
        category="Potholes and Damaged Roads",
        description="Deep asphalt crater on main transit road",
        location_address="Road No. 36 Jubilee Hills",
        ward="Ward 12 - Central"
    )
    assert pothole_routing['department_id'] == 1
    assert pothole_routing['is_external_authority'] == 0

    # Test Garbage routing -> Department 2 (Sanitation Department)
    garbage_routing = resolve_jurisdiction_and_routing(
        category="Garbage Accumulation",
        description="Overflowing municipal waste bin",
        location_address="Begumpet Railway Colony",
        ward="Ward 4 - North"
    )
    assert garbage_routing['department_id'] == 2

    # Test Water Leakage -> Department 3 (Water Supply Department)
    water_routing = resolve_jurisdiction_and_routing(
        category="Water Leakage",
        description="Burst water main gushing on street",
        location_address="Banjara Hills",
        ward="Ward 12 - Central"
    )
    assert water_routing['department_id'] == 3

# ------------------------------------------------------------------------------
# 2. Complaint routed to correct jurisdiction using its location (Internal vs External)
# ------------------------------------------------------------------------------
def test_scenario_2_jurisdiction_resolution_and_external_authority():
    # Regular Ward 7 location
    ward_routing = resolve_jurisdiction_and_routing(
        category="Potholes and Damaged Roads",
        description="Pothole in IT corridor",
        location_address="Hitec City Cyber Towers Road",
        ward="Ward 7 - West"
    )
    assert ward_routing['jurisdiction_code'] == 'WARD_7'
    assert ward_routing['is_external_authority'] == 0

    # National Highway location -> External Authority NHAI
    nhai_routing = resolve_jurisdiction_and_routing(
        category="Potholes and Damaged Roads",
        description="Massive structural potholes along National Highway 65",
        location_address="National Highway 65 (NH-65), Miyapur Outer Ring Road Junction",
        ward="Ward 7 - West"
    )
    assert nhai_routing['is_external_authority'] == 1
    assert "NHAI" in nhai_routing['external_authority_name']
    assert nhai_routing['jurisdiction_code'] == 'EXT_NHAI'

# ------------------------------------------------------------------------------
# 3. Officer receives assignment notification and delivery tracking
# ------------------------------------------------------------------------------
def test_scenario_3_officer_assignment_notification():
    db = get_db()
    cursor = db.cursor()
    # Check that seeded officer (user 7 or user 3) received assignment notification
    cursor.execute('''
        SELECT * FROM notifications 
        WHERE user_id = 7 AND notification_type = 'status_change'
    ''')
    notif = cursor.fetchone()
    
    cursor.execute('''
        SELECT * FROM notification_delivery_logs 
        WHERE recipient_id = 7 AND channel = 'in_app'
    ''')
    delivery = cursor.fetchone()
    db.close()

    assert notif is not None or delivery is not None
    if delivery:
        assert delivery['status'] == 'delivered'

# ------------------------------------------------------------------------------
# 4. Overdue complaint escalates automatically according to configured rules
# ------------------------------------------------------------------------------
def test_scenario_4_automatic_overdue_escalation():
    db = get_db()
    cursor = db.cursor()
    # Find or prepare an overdue complaint
    cursor.execute("SELECT id, current_hierarchy_level FROM complaints WHERE is_overdue = 1 LIMIT 1")
    comp = cursor.fetchone()
    db.close()

    assert comp is not None
    # Trigger hierarchical check engine
    escalations = check_and_escalate_hierarchical()
    
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT current_hierarchy_level, citizen_escalation_reason FROM complaints WHERE id = ?", (comp['id'],))
    updated_comp = cursor.fetchone()
    db.close()

    assert updated_comp['current_hierarchy_level'] >= 2
    assert updated_comp['citizen_escalation_reason'] is not None

# ------------------------------------------------------------------------------
# 5. Critical hazard triggers configured urgent-review workflow
# ------------------------------------------------------------------------------
def test_scenario_5_critical_hazard_immediate_review():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT id, priority, current_hierarchy_level FROM complaints WHERE priority = 'Critical' LIMIT 1")
    crit_comp = cursor.fetchone()
    db.close()

    assert crit_comp is not None
    assert crit_comp['priority'] == 'Critical'

    # Run escalation scanner
    check_and_escalate_hierarchical()

    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT current_hierarchy_level, supervisory_flag FROM complaints WHERE id = ?", (crit_comp['id'],))
    escalated = cursor.fetchone()
    db.close()

    # Critical hazards are flagged for higher-tier review
    assert escalated['current_hierarchy_level'] >= 2 or escalated['supervisory_flag'] == 1

# ------------------------------------------------------------------------------
# 6. Complaint transferred between departments without losing ID or history
# ------------------------------------------------------------------------------
def test_scenario_6_complaint_transfer_preserves_id_and_history():
    complaint_id = "CIVIC-2026-00101"
    
    # Initiate transfer from Department 1 (Roads) to Department 2 (Sanitation)
    success, msg = initiate_complaint_transfer(
        complaint_id=complaint_id,
        from_dept_id=1,
        to_dept_id=2,
        transfer_reason="Found solid waste covering the road surface",
        user_id=3
    )
    assert success is True

    db = get_db()
    cursor = db.cursor()
    # Verify transfer record created
    cursor.execute("SELECT * FROM complaint_transfers WHERE complaint_id = ? ORDER BY id DESC LIMIT 1", (complaint_id,))
    transfer = cursor.fetchone()
    assert transfer is not None
    assert transfer['to_dept_id'] == 2
    assert transfer['status'] == 'Pending'
    transfer_id = transfer['id']

    # Verify original complaint ID is untouched
    cursor.execute("SELECT id FROM complaints WHERE id = ?", (complaint_id,))
    assert cursor.fetchone() is not None

    # Verify status history audit logged
    cursor.execute("SELECT * FROM status_history WHERE complaint_id = ? ORDER BY id DESC LIMIT 1", (complaint_id,))
    history = cursor.fetchone()
    assert "Department Transfer Initiated" in history['notes']
    db.close()
    
    # Accept the transfer
    accept_success, accept_msg = respond_to_department_transfer(
        transfer_id=transfer_id,
        action='accept',
        user_id=4
    )
    assert accept_success is True

    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT department_id FROM complaints WHERE id = ?", (complaint_id,))
    reassigned = cursor.fetchone()
    assert reassigned['department_id'] == 2

    # Reset back to dept 1 and officer 3 for subsequent test consistency
    cursor.execute("UPDATE complaints SET department_id = 1, assigned_officer_id = 3 WHERE id = ?", (complaint_id,))
    db.commit()
    db.close()

# ------------------------------------------------------------------------------
# 7. Higher official can review and direct action on escalated complaint
# ------------------------------------------------------------------------------
def test_scenario_7_supervisory_directive_issuance_and_compliance():
    complaint_id = "CIVIC-2026-00101"
    
    # Senior official (user 6 - Commissioner / user 3 - SE) issues a Directive
    success, msg = create_supervisory_instruction(
        complaint_id=complaint_id,
        supervisor_id=6,
        instruction_type="Field Inspection",
        instruction_text="Conduct ground penetrative acoustic testing within 24 hours.",
        deadline_hours=24,
        is_public_to_citizen=1
    )
    assert success is True

    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM supervisory_instructions WHERE complaint_id = ? ORDER BY id DESC LIMIT 1", (complaint_id,))
    instruction = cursor.fetchone()
    db.close()

    assert instruction is not None
    assert instruction['instruction_type'] == 'Field Inspection'
    assert instruction['officer_acknowledged'] == 0

    # Assigned officer responds to directive
    resp_success, resp_msg = respond_to_supervisory_instruction(
        instruction_id=instruction['id'],
        officer_id=7,
        compliance_notes="Inspection completed: Surface base layer integrity confirmed."
    )
    assert resp_success is True

    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT officer_acknowledged, officer_response FROM supervisory_instructions WHERE id = ?", (instruction['id'],))
    updated_inst = cursor.fetchone()
    db.close()

    assert updated_inst['officer_acknowledged'] == 1
    assert "Surface base layer" in updated_inst['officer_response']

# ------------------------------------------------------------------------------
# 8. Citizen can see the escalation status in citizen-friendly language
# ------------------------------------------------------------------------------
def test_scenario_8_citizen_visibility_of_escalation():
    db = get_db()
    cursor = db.cursor()
    # Check complaint with supervisory escalation
    cursor.execute("SELECT id, current_hierarchy_level, citizen_escalation_reason FROM complaints WHERE supervisory_flag = 1 LIMIT 1")
    comp = cursor.fetchone()
    db.close()

    assert comp is not None
    assert comp['current_hierarchy_level'] >= 2
    assert comp['citizen_escalation_reason'] is not None
    # Ensure reason is clear citizen language, not raw stack or confidential internal notes
    assert len(comp['citizen_escalation_reason']) > 5

# ------------------------------------------------------------------------------
# 9. Failed external notifications are recorded accurately with channel & status
# ------------------------------------------------------------------------------
def test_scenario_9_notification_delivery_logging():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM notification_delivery_logs WHERE channel = 'sms'")
    sms_log = cursor.fetchone()
    
    cursor.execute("SELECT * FROM notification_delivery_logs WHERE channel = 'gov_adapter'")
    gov_log = cursor.fetchone()
    db.close()

    assert sms_log is not None
    assert sms_log['status'] in ['simulated', 'delivered', 'failed']

    assert gov_log is not None
    assert gov_log['status'] in ['simulated', 'delivered', 'failed']
    assert "CPGRAMS" in gov_log['subject']

# ------------------------------------------------------------------------------
# 10. Unauthorized officers cannot access complaints outside permitted scope
# ------------------------------------------------------------------------------
def test_scenario_10_jurisdictional_access_control(client):
    # Log in as Sanitation Officer Ananya Rao (User 4, Dept 2, Tier 2)
    with client.session_transaction() as sess:
        sess['user_id'] = 4
        sess['user_role'] = 'officer'

    # Try to access Road & Engineering grievance CIVIC-2026-00101 (Dept 1)
    response = client.get('/authority/complaint/CIVIC-2026-00101', follow_redirects=True)
    
    # Should be redirected with Access Denied message
    assert b"Access Denied" in response.data or b"clearance" in response.data

    # Log in as Tier 3 Superintending Engineer Suresh Varma (User 3, Tier 3)
    with client.session_transaction() as sess:
        sess['user_id'] = 3
        sess['user_role'] = 'officer'

    # Tier 3 SE should have oversight clearance
    response_se = client.get('/authority/complaint/CIVIC-2026-00101', follow_redirects=True)
    assert response_se.status_code == 200
    assert b"CIVIC-2026-00101" in response_se.data

# ------------------------------------------------------------------------------
# Extra: Standardized CPGRAMS / NIC Government Data Exchange Package Export
# ------------------------------------------------------------------------------
def test_gov_package_export():
    package = export_complaint_gov_package("CIVIC-2026-00101")
    assert package is not None
    assert package['metadata']['standard_version'] == "MoHUA-CPGRAMS-2.4"
    assert package['complaint_identity']['complaint_id'] == "CIVIC-2026-00101"
    assert "spatial_jurisdiction" in package
    assert "assigned_authority" in package
    assert "status_audit_trail" in package
