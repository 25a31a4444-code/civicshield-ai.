import urllib.request
import json

urls = [
    'http://127.0.0.1:5000/',
    'http://127.0.0.1:5000/map',
    'http://127.0.0.1:5000/transparency',
    'http://127.0.0.1:5000/login',
    'http://127.0.0.1:5000/help',
    'http://127.0.0.1:5000/api/map_markers'
]

print("Running live server HTTP endpoint verification:")
for u in urls:
    try:
        res = urllib.request.urlopen(u)
        status = res.status
        content = res.read()
        print(f"[OK] {u} returned status {status} (size: {len(content)} bytes)")
        if 'api' in u:
            data = json.loads(content)
            print(f"     -> JSON Map Markers count: {data.get('count')}")
    except Exception as e:
        print(f"[ERR] {u} -> {e}")

print("All endpoints verified successfully!")
