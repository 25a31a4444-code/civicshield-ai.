import glob
import re

replacements = [
    (r'href="/citizen/dashboard"', 'href="citizen-dashboard.html"'),
    (r'href="/citizen/my_complaints"', 'href="my-complaints.html"'),
    (r'href="/citizen/report"', 'href="report.html"'),
    (r'href="/citizen/complaint/([^"]*)"', r'href="citizen-dashboard.html#\1"'),
    (r'href="/authority/dashboard"', 'href="authority-dashboard.html"'),
    (r'href="/authority/complaint/([^"]*)"', r'href="authority-dashboard.html#\1"'),
    (r'href="/authority/work_order/([^"]*)"', r'href="authority-dashboard.html#\1"'),
    (r'href="/authority/[^"]*"', 'href="authority-dashboard.html"'),
    (r'href="/admin/[^"]*"', 'href="authority-dashboard.html"'),
    (r'href="/map"', 'href="map.html"'),
    (r'href="/transparency"', 'href="transparency.html"'),
    (r'href="/help"', 'href="help.html"'),
    (r'href="/login"', 'href="login.html"'),
    (r'href="/register"', 'href="register.html"'),
    (r'href="/logout"', 'href="login.html"'),
    (r'href="/profile"', 'href="citizen-dashboard.html"'),
    (r'href="/"', 'href="index.html"'),
    (r'href="/set_lang/[^"]*"', 'href="#"')
]

for filepath in glob.glob('dist/*.html'):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    orig = content
    for pattern, repl in replacements:
        content = re.sub(pattern, repl, content)
    
    if content != orig:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f'Updated {filepath}')

print("Completed updating all links.")
