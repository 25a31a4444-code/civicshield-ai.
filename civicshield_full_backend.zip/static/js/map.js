// CivicShield AI Interactive Map & Civic Heatmap

let mapInstance = null;
let markersLayer = null;
let currentMarkers = [];

function initCivicMap(containerId = 'map', options = {}) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const defaultLat = options.lat || 17.3850;
  const defaultLng = options.lng || 78.4867;
  const defaultZoom = options.zoom || 12;

  // Initialize Leaflet map
  mapInstance = L.map(containerId).setView([defaultLat, defaultLng], defaultZoom);

  // OpenStreetMap tile layer
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors | CivicShield AI'
  }).addTo(mapInstance);

  markersLayer = L.layerGroup().addTo(mapInstance);

  // Load complaints markers
  loadMapMarkers();

  // Attach filter event listeners if available
  const filterCat = document.getElementById('mapFilterCategory');
  const filterStatus = document.getElementById('mapFilterStatus');
  const filterPriority = document.getElementById('mapFilterPriority');
  const filterDept = document.getElementById('mapFilterDepartment');

  [filterCat, filterStatus, filterPriority, filterDept].forEach(el => {
    if (el) el.addEventListener('change', () => loadMapMarkers());
  });
}

function createCustomPin(color) {
  return L.divIcon({
    className: 'custom-civic-pin',
    html: `
      <div style="
        width: 24px;
        height: 24px;
        background-color: ${color};
        border: 2.5px solid #FFFFFF;
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        box-shadow: 0 3px 8px rgba(0,0,0,0.35);
      ">
        <div style="
          width: 8px;
          height: 8px;
          background: #FFFFFF;
          border-radius: 50%;
          position: absolute;
          top: 6px;
          left: 6px;
        "></div>
      </div>
    `,
    iconSize: [24, 24],
    iconAnchor: [12, 24],
    popupAnchor: [0, -24]
  });
}

function loadMapMarkers() {
  if (!mapInstance || !markersLayer) return;

  markersLayer.clearLayers();

  const filterCat = document.getElementById('mapFilterCategory')?.value || '';
  const filterStatus = document.getElementById('mapFilterStatus')?.value || '';
  const filterPriority = document.getElementById('mapFilterPriority')?.value || '';
  const filterDept = document.getElementById('mapFilterDepartment')?.value || '';

  const params = new URLSearchParams();
  if (filterCat) params.append('category', filterCat);
  if (filterStatus) params.append('status', filterStatus);
  if (filterPriority) params.append('priority', filterPriority);
  if (filterDept) params.append('department_id', filterDept);

  function renderMarkers(markers) {
    currentMarkers = markers;
    markersLayer.clearLayers();
    markers.forEach(m => {
      const icon = createCustomPin(m.marker_color);
      const marker = L.marker([m.latitude, m.longitude], { icon });

      const detailUrl = window.location.pathname.endsWith('.html') ? `citizen-dashboard.html#${m.id}` : `/citizen/complaint/${m.id}`;

      const popupContent = `
        <div style="font-family: var(--font-body); max-width: 260px;">
          ${m.thumbnail ? `<img src="/static/uploads/${m.thumbnail}" style="width: 100%; height: 110px; object-fit: cover; border-radius: 6px; margin-bottom: 8px;" onerror="this.style.display='none'">` : ''}
          <div style="font-size: 0.75rem; font-weight: 700; color: #78656B;">${m.id} &bull; ${m.ward}</div>
          <h4 style="font-size: 0.95rem; font-weight: 700; color: #3F1024; margin: 4px 0 6px;">${m.title}</h4>
          <div style="display: flex; gap: 6px; margin-bottom: 8px;">
            <span class="badge badge-${m.status.toLowerCase().replace(/ /g, '-')}">${m.status}</span>
            <span class="badge priority-${m.priority.toLowerCase()}">${m.priority}</span>
          </div>
          <div style="font-size: 0.8rem; color: #78656B; margin-bottom: 10px;">${m.address}</div>
          <a href="${detailUrl}" class="btn btn-primary btn-sm" style="width: 100%; text-align: center; color: #FFF;">Track Issue &rarr;</a>
        </div>
      `;

      marker.bindPopup(popupContent);
      markersLayer.addLayer(marker);
    });

    const countEl = document.getElementById('mapCountDisplay');
    if (countEl) countEl.textContent = `${markers.length} civic complaints displayed`;
  }

  fetch(`/api/map_markers?${params.toString()}`)
    .then(res => {
      if (!res.ok) throw new Error('Backend API unavailable');
      return res.json();
    })
    .then(data => {
      if (!data.success) return;
      renderMarkers(data.markers);
    })
    .catch(() => {
      // Fallback to static data file
      const staticDataUrl = window.location.pathname.includes('/dist/') ? 'static/data/map_markers.json' : '/static/data/map_markers.json';
      fetch(staticDataUrl)
        .then(res => res.json())
        .then(data => {
          let list = data.markers || [];
          if (filterCat) list = list.filter(m => m.category === filterCat);
          if (filterStatus) list = list.filter(m => m.status === filterStatus);
          if (filterPriority) list = list.filter(m => m.priority === filterPriority);
          if (filterDept) list = list.filter(m => String(m.department_id) === String(filterDept));
          renderMarkers(list);
        })
        .catch(err => console.error('Map markers fallback error:', err));
    });
}
