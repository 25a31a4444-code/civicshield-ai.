// Telugu and English Web Speech API Voice-to-Text Integration

function initSpeechRecognition(targetInputId, triggerBtnId, langSelectId) {
  const targetInput = document.getElementById(targetInputId);
  const triggerBtn = document.getElementById(triggerBtnId);
  const langSelect = document.getElementById(langSelectId);

  if (!triggerBtn || !targetInput) return;

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!SpeechRecognition) {
    triggerBtn.title = "Speech recognition is not supported in this browser. Please use Chrome or Edge.";
    triggerBtn.addEventListener('click', () => {
      alert("Speech recognition is not supported by your current browser. You can type directly in the box.");
    });
    return;
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = false;

  let isRecording = false;

  triggerBtn.addEventListener('click', () => {
    if (isRecording) {
      recognition.stop();
      return;
    }

    // Determine language (Telugu te-IN or English en-IN)
    const selectedLang = langSelect ? langSelect.value : 'te';
    recognition.lang = selectedLang === 'te' ? 'te-IN' : 'en-IN';

    try {
      recognition.start();
      isRecording = true;
      triggerBtn.classList.add('recording');
      triggerBtn.innerHTML = '🔴 Listening... (Speak now)';
      triggerBtn.style.backgroundColor = '#DC2626';
      triggerBtn.style.color = '#FFFFFF';
    } catch (e) {
      console.error(e);
    }
  });

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    if (transcript) {
      const currentVal = targetInput.value;
      targetInput.value = currentVal ? `${currentVal} ${transcript}` : transcript;
      // Trigger AI triage update event
      const evt = new Event('input');
      targetInput.dispatchEvent(evt);
    }
  };

  recognition.onend = () => {
    isRecording = false;
    triggerBtn.classList.remove('recording');
    triggerBtn.innerHTML = '🎙️ Speak (తెలుగు / English)';
    triggerBtn.style.backgroundColor = '';
    triggerBtn.style.color = '';
  };

  recognition.onerror = (event) => {
    console.error('Speech recognition error:', event.error);
    isRecording = false;
    triggerBtn.innerHTML = '🎙️ Speak (తెలుగు / English)';
    triggerBtn.style.backgroundColor = '';
    triggerBtn.style.color = '';
  };
}
