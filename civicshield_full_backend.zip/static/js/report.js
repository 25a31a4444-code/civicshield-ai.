// CivicShield AI Issue Reporting Workflow Manager

let reportMap = null;
let reportPin = null;

document.addEventListener('DOMContentLoaded', () => {
  initReportMap();
  initGeolocationButton();
  initImageUploadAndCamera();
  initAIPreviewListener();
  initDuplicateCheckListener();
  initDraftStorage();
});

// Interactive Draggable Map for Geolocation
function initReportMap() {
  const mapEl = document.getElementById('reportMap');
  if (!mapEl) return;

  const latInput = document.getElementById('latitudeInput');
  const lngInput = document.getElementById('longitudeInput');
  const addrInput = document.getElementById('locationAddressInput');

  const defaultLat = parseFloat(latInput?.value) || 17.3850;
  const defaultLng = parseFloat(lngInput?.value) || 78.4867;

  reportMap = L.map('reportMap').setView([defaultLat, defaultLng], 14);

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap | CivicShield AI'
  }).addTo(reportMap);

  reportPin = L.marker([defaultLat, defaultLng], { draggable: true }).addTo(reportMap);

  reportPin.on('dragend', function (e) {
    const pos = reportPin.getLatLng();
    if (latInput) latInput.value = pos.lat.toFixed(6);
    if (lngInput) lngInput.value = pos.lng.toFixed(6);
    reverseGeocode(pos.lat, pos.lng);
  });

  reportMap.on('click', function (e) {
    reportPin.setLatLng(e.latlng);
    if (latInput) latInput.value = e.latlng.lat.toFixed(6);
    if (lngInput) lngInput.value = e.latlng.lng.toFixed(6);
    reverseGeocode(e.latlng.lat, e.latlng.lng);
  });
}

function reverseGeocode(lat, lng) {
  const addrInput = document.getElementById('locationAddressInput');
  if (!addrInput) return;
  fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`)
    .then(res => res.json())
    .then(data => {
      if (data && data.display_name) {
        addrInput.value = data.display_name;
      }
    })
    .catch(() => {});
}

// Geolocation ("Use Current Location")
function initGeolocationButton() {
  const geoBtn = document.getElementById('useCurrentLocationBtn');
  if (!geoBtn) return;

  geoBtn.addEventListener('click', () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return;
    }

    geoBtn.disabled = true;
    geoBtn.innerHTML = 'Detecting GPS...';

    navigator.geolocation.getCurrentPosition(
      pos => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;

        document.getElementById('latitudeInput').value = lat.toFixed(6);
        document.getElementById('longitudeInput').value = lng.toFixed(6);

        if (reportMap && reportPin) {
          reportMap.setView([lat, lng], 16);
          reportPin.setLatLng([lat, lng]);
        }

        reverseGeocode(lat, lng);
        geoBtn.disabled = false;
        geoBtn.innerHTML = '✓ GPS Coordinates Updated';
        setTimeout(() => { geoBtn.innerHTML = '📍 Use My Current Location'; }, 3000);
      },
      err => {
        geoBtn.disabled = false;
        geoBtn.innerHTML = '📍 Use My Current Location';
        alert('Could not access GPS location. Please pinpoint location on map.');
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  });
}

// Image Preview, Camera Capture & Client-Side Canvas Compression
function initImageUploadAndCamera() {
  const imageInput = document.getElementById('imagesInput');
  const previewContainer = document.getElementById('imagePreviewsContainer');
  const cameraBtn = document.getElementById('cameraCaptureBtn');
  const cameraVideo = document.getElementById('cameraVideo');
  const cameraModal = document.getElementById('cameraModal');
  const snapBtn = document.getElementById('snapPhotoBtn');
  const closeCameraBtn = document.getElementById('closeCameraBtn');

  const dropZone = document.getElementById('evidenceDropZone');
  const progressContainer = document.getElementById('analysisProgressBarContainer');
  const progressBar = document.getElementById('analysisProgressBar');
  const progressLabel = document.getElementById('analysisStatusLabel');
  const progressPct = document.getElementById('analysisProgressPct');

  if (dropZone && imageInput) {
    ['dragenter', 'dragover'].forEach(eventName => {
      dropZone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropZone.style.borderColor = 'var(--color-wine-red)';
        dropZone.style.background = '#F3E8DC';
      }, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
      dropZone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropZone.style.borderColor = 'var(--color-champagne)';
        dropZone.style.background = '#FAF5F0';
      }, false);
    });

    dropZone.addEventListener('drop', (e) => {
      const dt = e.dataTransfer;
      const files = dt.files;
      if (files && files.length > 0) {
        imageInput.files = files;
        handleFileSelection({ target: { files: files } });
      }
    });

    dropZone.addEventListener('click', (e) => {
      if (e.target.closest('button') || e.target.closest('input')) return;
      imageInput.click();
    });
  }

  if (imageInput && previewContainer) {
    imageInput.addEventListener('change', handleFileSelection);
  }

  function handleFileSelection(e) {
    const files = Array.from(e.target.files);
    previewContainer.innerHTML = '';
    if (!files.length) return;

    // Check size limit: max 50MB for video
    for (const f of files) {
      const isVid = f.type.startsWith('video/') || f.name.match(/\.(mp4|webm|mov|m4v)$/i);
      if (isVid && f.size > 50 * 1024 * 1024) {
        alert(`File "${f.name}" exceeds the maximum video limit of 50 MB. Please upload a shorter clip (under 60 seconds).`);
        imageInput.value = '';
        return;
      }
    }

    // Render local previews
    files.forEach((file) => {
      const isVideo = file.type.startsWith('video/') || file.name.match(/\.(mp4|webm|mov|m4v)$/i);
      const div = document.createElement('div');
      
      if (isVideo) {
        div.style.cssText = 'width: 260px; border-radius: 8px; overflow: hidden; border: 1.5px solid var(--color-champagne-dark); background: #000; box-shadow: var(--shadow-sm);';
        const vidUrl = URL.createObjectURL(file);
        div.innerHTML = `
          <video src="${vidUrl}" controls style="width: 100%; height: 160px; object-fit: contain; background: #000;"></video>
          <div style="padding: 6px 10px; background: #1C1917; color: #E7C9A9; font-size: 0.74rem; display: flex; justify-content: space-between; align-items: center;">
            <span>📹 Video Evidence</span>
            <span style="font-size: 0.7rem; color: #A8A29E;">${(file.size / (1024 * 1024)).toFixed(1)} MB</span>
          </div>
        `;
      } else {
        div.style.cssText = 'position: relative; width: 110px; height: 110px; border-radius: 8px; overflow: hidden; border: 1.5px solid var(--color-champagne); box-shadow: var(--shadow-sm); background: #FAF5F0;';
        const reader = new FileReader();
        reader.onload = function (event) {
          div.innerHTML = `
            <img src="${event.target.result}" style="width: 100%; height: 100%; object-fit: cover;">
            <div style="position: absolute; bottom: 0; left: 0; right: 0; background: rgba(63, 16, 36, 0.75); color: #FFF; font-size: 9px; padding: 2px 4px; text-align: center;">
              📷 Photo Evidence
            </div>
          `;
        };
        reader.readAsDataURL(file);
      }
      previewContainer.appendChild(div);
    });

    // Trigger Real-Time Forensic AI Verification on primary file
    runForensicVerification(files[0]);
  }

  // Live Forensic Analysis Caller
  async function runForensicVerification(file) {
    if (!file) return;

    const authCard = document.getElementById('authenticityPreviewCard');
    if (!authCard) return;

    // Show Progress Bar
    if (progressContainer) {
      progressContainer.style.display = 'block';
      progressBar.style.width = '30%';
      progressPct.innerText = '30%';
      progressLabel.innerText = '🔄 Extracting visual features & computing perceptual hashes...';
    }

    const formData = new FormData();
    formData.append('file', file);
    const cat = document.getElementById('categorySelect')?.value || '';
    const desc = document.getElementById('reportDescription')?.value || '';
    formData.append('category', cat);
    formData.append('description', desc);

    try {
      setTimeout(() => {
        if (progressBar) { progressBar.style.width = '65%'; progressPct.innerText = '65%'; }
        if (progressLabel) progressLabel.innerText = '🛡️ Running AI synthetic generation and manipulation detection...';
      }, 300);

      const response = await fetch('/api/analyze-evidence', {
        method: 'POST',
        body: formData
      });

      const data = await response.json();

      if (progressBar) { progressBar.style.width = '100%'; progressPct.innerText = '100%'; }
      if (progressLabel) progressLabel.innerText = '✓ AI Authenticity Analysis Complete';
      setTimeout(() => {
        if (progressContainer) progressContainer.style.display = 'none';
      }, 700);

      if (data && data.success) {
        authCard.style.display = 'block';

        // Verdict Badge
        const verdictBadge = document.getElementById('authVerdictBadge');
        if (verdictBadge) {
          verdictBadge.innerText = data.verdict;
          if (data.verdict === 'Likely Authentic') {
            verdictBadge.className = 'badge badge-resolved';
            verdictBadge.style.backgroundColor = '#15803D';
            verdictBadge.style.color = '#FFF';
          } else if (data.verdict === 'Potentially AI-Generated or Manipulated') {
            verdictBadge.className = 'badge badge-critical';
            verdictBadge.style.backgroundColor = '#DC2626';
            verdictBadge.style.color = '#FFF';
          } else {
            verdictBadge.className = 'badge badge-pending';
            verdictBadge.style.backgroundColor = '#D97706';
            verdictBadge.style.color = '#FFF';
          }
        }

        // Confidence
        const confEl = document.getElementById('authConfidencePct');
        if (confEl) confEl.innerText = `${Math.round((data.confidence || 0.85) * 100)}% Confidence`;

        // Blur / Sharpness
        const blurEl = document.getElementById('authBlurScore');
        if (blurEl) blurEl.innerText = `${data.quality_rating || 'Normal Focus'} (${data.blur_score || 0})`;

        // Camera EXIF
        const camEl = document.getElementById('authCameraModel');
        if (camEl) {
          if (data.exif_metadata && data.exif_metadata.has_exif) {
            camEl.innerText = `${data.exif_metadata.camera_make || 'Standard'} ${data.exif_metadata.camera_model || 'Camera'}`;
          } else {
            camEl.innerText = 'Web / Messaging Stream';
          }
        }

        // Noise & ELA
        const noiseEl = document.getElementById('authNoiseVariance');
        if (noiseEl) noiseEl.innerText = data.ela_score ? `ELA: ${data.ela_score}` : 'Uniform Optical Grain';

        // Duplicate
        const dupEl = document.getElementById('authDuplicateBadge');
        if (dupEl) {
          if (data.duplicate_check && data.duplicate_check.is_duplicate) {
            dupEl.innerText = `⚠️ Matched #${data.duplicate_check.matched_complaint_id}`;
            dupEl.style.color = '#DC2626';
          } else {
            dupEl.innerText = 'Unique Fingerprint';
            dupEl.style.color = '#166534';
          }
        }

        // Video Keyframes
        const kfContainer = document.getElementById('authVideoKeyframesContainer');
        const kfStrip = document.getElementById('videoKeyframesFilmstrip');
        const vidRuntime = document.getElementById('videoRuntimeDetails');

        if (data.media_type === 'video' && data.extracted_keyframes && data.extracted_keyframes.length > 0) {
          kfContainer.style.display = 'block';
          if (vidRuntime) vidRuntime.innerText = `${data.duration_seconds}s • ${data.fps} FPS • ${data.total_frames} Frames`;
          kfStrip.innerHTML = '';
          data.extracted_keyframes.forEach((kfUrl, i) => {
            const kfImg = document.createElement('img');
            kfImg.src = kfUrl;
            kfImg.style.cssText = 'width: 80px; height: 55px; object-fit: cover; border-radius: 4px; border: 1px solid var(--color-champagne);';
            kfImg.title = `Keyframe ${i+1}`;
            kfStrip.appendChild(kfImg);
          });
        } else if (kfContainer) {
          kfContainer.style.display = 'none';
        }

        // Reasoning Text
        const reasonEl = document.getElementById('authReasoningText');
        if (reasonEl) reasonEl.innerText = data.reasoning || 'Visual consistency and optical frequency profile verified.';

        // Model Tag
        const modelEl = document.getElementById('authModelName');
        if (modelEl) modelEl.innerText = data.model_name;

        // Auto-recommend category if user has not chosen one
        const catSelect = document.getElementById('categorySelect');
        if (catSelect && !catSelect.value && data.detected_issue && data.detected_issue.category) {
          for (let opt of catSelect.options) {
            if (opt.value === data.detected_issue.category) {
              catSelect.value = opt.value;
              break;
            }
          }
        }
      }
    } catch (err) {
      if (progressContainer) progressContainer.style.display = 'none';
      console.warn('Real-time authenticity check bypassed:', err);
    }
  }

  // Camera capture modal
  if (cameraBtn && cameraModal && snapBtn) {
    let stream = null;

    cameraBtn.addEventListener('click', async () => {
      try {
        cameraModal.style.display = 'flex';
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        cameraVideo.srcObject = stream;
      } catch (err) {
        alert('Camera access could not be initialized or permission was denied.');
        cameraModal.style.display = 'none';
      }
    });

    snapBtn.addEventListener('click', () => {
      const canvas = document.createElement('canvas');
      canvas.width = cameraVideo.videoWidth || 640;
      canvas.height = cameraVideo.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(cameraVideo, 0, 0, canvas.width, canvas.height);

      canvas.toBlob(blob => {
        const file = new File([blob], `camera_${Date.now()}.jpg`, { type: 'image/jpeg' });
        const dataTransfer = new DataTransfer();
        if (imageInput.files) {
          Array.from(imageInput.files).forEach(f => dataTransfer.items.add(f));
        }
        dataTransfer.items.add(file);
        imageInput.files = dataTransfer.files;

        // Trigger preview
        const changeEvent = new Event('change');
        imageInput.dispatchEvent(changeEvent);

        // Close modal
        closeCamera();
      }, 'image/jpeg', 0.88);
    });

    if (closeCameraBtn) closeCameraBtn.addEventListener('click', closeCamera);

    function closeCamera() {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      cameraModal.style.display = 'none';
    }
  }
}

// Real-time AI Triage Preview
function initAIPreviewListener() {
  const titleInput = document.getElementById('reportTitle');
  const descInput = document.getElementById('reportDescription');
  const previewCard = document.getElementById('aiTriagePreviewCard');
  if (!previewCard) return;

  let debounceTimer = null;
  const triggerAI = () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      const title = titleInput?.value || '';
      const desc = descInput?.value || '';
      if (title.length < 4 && desc.length < 10) {
        previewCard.style.display = 'none';
        return;
      }

      const formData = new FormData();
      formData.append('title', title);
      formData.append('description', desc);

      const imgInput = document.getElementById('imagesInput');
      if (imgInput?.files?.[0]) {
        formData.append('image', imgInput.files[0]);
      }

      fetch('/api/ai_triage', { method: 'POST', body: formData })
        .then(res => res.json())
        .then(data => {
          if (data.success && data.triage.available) {
            previewCard.style.display = 'block';
            document.getElementById('aiCategoryBadge').textContent = data.triage.predicted_category;
            document.getElementById('aiConfidenceScore').textContent = `${Math.round(data.triage.confidence_score * 100)}% Confidence`;
            document.getElementById('aiRiskScoreNum').textContent = `${data.triage.risk_score}/100`;
            document.getElementById('aiSeverityBadge').textContent = data.triage.severity_level;
            document.getElementById('aiDeptRecommend').textContent = data.triage.recommended_dept_name;
            document.getElementById('aiReasoningText').textContent = data.triage.reasoning;
          }
        });
    }, 600);
  };

  if (titleInput) titleInput.addEventListener('input', triggerAI);
  if (descInput) descInput.addEventListener('input', triggerAI);
}

// Real-time Duplicate Detection
function initDuplicateCheckListener() {
  const form = document.getElementById('reportIssueForm');
  const dupModal = document.getElementById('duplicateCheckModal');
  const dupList = document.getElementById('duplicateResultsList');
  const proceedBtn = document.getElementById('proceedDistinctReportBtn');
  if (!form || !dupModal) return;

  let duplicateBypassed = false;

  form.addEventListener('submit', function (e) {
    if (duplicateBypassed) return;

    e.preventDefault();

    const category = document.getElementById('categorySelect')?.value || '';
    const desc = document.getElementById('reportDescription')?.value || '';
    const lat = document.getElementById('latitudeInput')?.value || '';
    const lon = document.getElementById('longitudeInput')?.value || '';

    fetch('/api/check_duplicates', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ category, description: desc, latitude: lat, longitude: lon })
    })
      .then(res => res.json())
      .then(data => {
        if (data.found && data.duplicates.length > 0) {
          // Render duplicates in modal
          dupList.innerHTML = data.duplicates.map(d => `
            <div style="background: #FFF9F3; border: 1px solid var(--color-champagne); border-radius: 8px; padding: 14px; margin-bottom: 12px;">
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
                <span style="font-weight: 700; font-size: 0.85rem; color: #3F1024;">${d.id} (${d.category})</span>
                <span class="badge priority-${d.priority.toLowerCase()}">${d.priority}</span>
              </div>
              <div style="font-size: 0.9rem; font-weight: 600; color: #351520; margin-bottom: 4px;">${d.title}</div>
              <div style="font-size: 0.8rem; color: #78656B; margin-bottom: 8px;">Approx ${d.distance_meters}m away &bull; Status: ${d.status}</div>
              <button type="button" class="btn btn-champagne btn-sm" onclick="supportAndClose('${d.id}', this)">
                👍 Support Existing Issue (+1)
              </button>
            </div>
          `).join('');

          dupModal.style.display = 'flex';
        } else {
          // No duplicate found, proceed with form submit
          duplicateBypassed = true;
          form.submit();
        }
      })
      .catch(() => {
        duplicateBypassed = true;
        form.submit();
      });
  });

  if (proceedBtn) {
    proceedBtn.addEventListener('click', () => {
      dupModal.style.display = 'none';
      duplicateBypassed = true;
      form.submit();
    });
  }
}

function supportAndClose(id, btn) {
  fetch(`/api/support_complaint/${id}`, { method: 'POST' })
    .then(res => res.json())
    .then(data => {
      alert(`Thank you! Your support has been added to complaint ${id}. You can track it directly.`);
      window.location.href = `/citizen/complaint/${id}`;
    });
}

// Offline Draft Persistence in LocalStorage
function initDraftStorage() {
  const saveDraftBtn = document.getElementById('saveDraftBtn');
  const restoreBanner = document.getElementById('draftRestoreBanner');

  if (saveDraftBtn) {
    saveDraftBtn.addEventListener('click', () => {
      const draft = {
        title: document.getElementById('reportTitle')?.value,
        category: document.getElementById('categorySelect')?.value,
        description: document.getElementById('reportDescription')?.value,
        ward: document.getElementById('wardSelect')?.value,
        address: document.getElementById('locationAddressInput')?.value,
        lat: document.getElementById('latitudeInput')?.value,
        lng: document.getElementById('longitudeInput')?.value,
        timestamp: new Date().toLocaleString()
      };
      localStorage.setItem('civicshield_draft', JSON.stringify(draft));
      alert('Draft report saved locally in browser storage.');
    });
  }

  const existingDraft = localStorage.getItem('civicshield_draft');
  if (existingDraft && restoreBanner) {
    restoreBanner.style.display = 'block';
    document.getElementById('restoreDraftBtn')?.addEventListener('click', () => {
      try {
        const d = JSON.parse(existingDraft);
        if (d.title) document.getElementById('reportTitle').value = d.title;
        if (d.category) document.getElementById('categorySelect').value = d.category;
        if (d.description) document.getElementById('reportDescription').value = d.description;
        if (d.ward) document.getElementById('wardSelect').value = d.ward;
        if (d.address) document.getElementById('locationAddressInput').value = d.address;
        if (d.lat && d.lng) {
          document.getElementById('latitudeInput').value = d.lat;
          document.getElementById('longitudeInput').value = d.lng;
          if (reportMap && reportPin) {
            reportMap.setView([parseFloat(d.lat), parseFloat(d.lng)], 15);
            reportPin.setLatLng([parseFloat(d.lat), parseFloat(d.lng)]);
          }
        }
        restoreBanner.style.display = 'none';
      } catch (err) {}
    });

    document.getElementById('dismissDraftBtn')?.addEventListener('click', () => {
      localStorage.removeItem('civicshield_draft');
      restoreBanner.style.display = 'none';
    });
  }
}
