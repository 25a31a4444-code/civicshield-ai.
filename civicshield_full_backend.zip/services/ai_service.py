import os
import re
import json
import hashlib
from PIL import Image, ImageStat
from config import Config
from database import get_db

# Common Telugu civic keywords and translation mapping
TELUGU_CIVIC_DICTIONARY = {
    'గుంత': 'pothole',
    'గుంతలు': 'potholes',
    'రోడ్డు': 'road',
    'చెత్త': 'garbage / waste',
    'కాలువ': 'drainage canal',
    'మురుగు': 'sewage',
    'మురుగునీరు': 'stagnant sewage water',
    'నీరు': 'water',
    'లీకేజీ': 'leakage',
    'దీపం': 'lamp',
    'వీధి దీపాలు': 'streetlights',
    'వెలుగుటలేదు': 'not working / dark',
    'తీగలు': 'wires / cables',
    'కరెంట్': 'electricity',
    'వరద': 'flood / waterlogging',
    'ఫుట్‌పాత్': 'footpath',
    'చెడిపోయింది': 'damaged'
}

def analyze_image_properties(image_path):
    """Inspects physical image properties using PIL."""
    if not image_path or not os.path.exists(image_path):
        return None
    try:
        with Image.open(image_path) as img:
            stat = ImageStat.Stat(img)
            mean_brightness = sum(stat.mean[:3]) / 3.0 if len(stat.mean) >= 3 else stat.mean[0]
            width, height = img.size
            has_exif = bool(getattr(img, '_getexif', lambda: None)())
            return {
                "width": width,
                "height": height,
                "aspect_ratio": round(width / max(1, height), 2),
                "brightness": round(mean_brightness, 1),
                "has_exif": has_exif,
                "format": img.format
            }
    except Exception as e:
        return None

from services.authenticity_service import assess_media_authenticity, analyze_photo_authenticity, analyze_video_authenticity, check_duplicate_evidence, calculate_dhash

def assess_image_authenticity(image_path):
    """
    Assesses whether an uploaded photo is likely authentic, synthetic, or inconclusive.
    Leverages calibrated forensic quality, EXIF inspection, and error-level consistency.
    """
    if not Config.ENABLE_IMAGE_AUTHENTICITY:
        return {
            "status": "Inconclusive",
            "verdict": "Inconclusive",
            "confidence": 0.50,
            "reasoning": "Authenticity analysis service is currently disabled in configuration."
        }
        
    return analyze_photo_authenticity(image_path)


def normalize_telugu_text(text):
    """Translates known Telugu civic terms into normalized English phrases."""
    if not text:
        return text, False
    detected_telugu = False
    normalized = text
    for te_word, en_meaning in TELUGU_CIVIC_DICTIONARY.items():
        if te_word in normalized:
            detected_telugu = True
            normalized = normalized.replace(te_word, f"{te_word} ({en_meaning})")
    return normalized, detected_telugu

def classify_complaint(image_path=None, title="", description=""):
    """
    AI Classification, Hazard Identification, Risk Scoring (0-100), and Department Recommendation.
    Gracefully handles missing or disabled AI services.
    """
    if not Config.ENABLE_AI_CLASSIFICATION:
        return {
            "available": False,
            "reason": "AI Classification is currently disabled in configuration."
        }
        
    text_content = f"{title} {description}".lower()
    
    # Category keyword mapping & weights
    category_weights = {
        "Potholes and Damaged Roads": ["pothole", "crater", "asphalt", "road", "tar", "gutter", "craters", "pit", "accident hazard", "గుంత"],
        "Garbage Accumulation": ["garbage", "trash", "waste", "dump", "debris", "smell", "plastic", "litter", "చెత్త"],
        "Drainage Blockage": ["drain", "drainage", "sewage", "gutter", "clogged", "overflow", "stagnant", "smell", "కాలువ", "మురుగు"],
        "Water Leakage": ["leak", "pipe", "water pipe", "burst", "drinking water", "gushing", "valve", "నీరు", "లీకేజీ"],
        "Broken Streetlights": ["streetlight", "lamp", "pole", "dark", "light", "bulb", "flickering", "night", "దీపం"],
        "Exposed Electrical Wires": ["wire", "electric", "cable", "shock", "spark", "transformer", "dangling", "live wire", "తీగలు", "కరెంట్"],
        "Damaged Footpaths": ["footpath", "sidewalk", "paver", "pedestrian", "kerb", "walking", "slab", "ఫుట్‌పాత్"],
        "Overflowing Public Bins": ["bin", "dustbin", "dumper", "overflowing", "container", "waste box"],
        "Waterlogging and Flooding": ["waterlog", "waterlogging", "flood", "flooding", "submerged", "rain water", "pool", "వరద"],
        "Public Property Damage": ["bench", "railing", "bus stop", "shelter", "wall", "public toilet", "park", "vandalism"]
    }
    
    scores = {}
    for cat, keywords in category_weights.items():
        score = 0
        for kw in keywords:
            if kw in text_content:
                score += 15
        scores[cat] = score

    # Inspect image visual clues if available
    img_props = analyze_image_properties(image_path)
    if img_props:
        # Potholes / roads often have dark neutral grayscale tones
        if img_props["brightness"] < 110 and scores.get("Potholes and Damaged Roads", 0) > 0:
            scores["Potholes and Damaged Roads"] += 10
        # Broken streetlights often taken in low lighting / nighttime
        if img_props["brightness"] < 80 and scores.get("Broken Streetlights", 0) > 0:
            scores["Broken Streetlights"] += 15

    # Determine highest matching category
    best_category = max(scores, key=scores.get) if any(scores.values()) else "Other Civic Issues"
    raw_match = scores.get(best_category, 0)
    
    # Calculate confidence (0.65 to 0.94)
    confidence = min(0.94, max(0.65, 0.60 + (raw_match / 100.0)))
    
    # Identify specific visible hazards
    hazards = []
    if any(k in text_content for k in ["wire", "electric", "shock", "spark", "transformer", "live"]):
        hazards.append("High Voltage Shock / Electrocution Risk")
    if any(k in text_content for k in ["pothole", "crater", "accident", "two-wheeler", "deep", "skid"]):
        hazards.append("Two-Wheeler Skid & Collision Hazard")
    if any(k in text_content for k in ["sewage", "foul", "mosquito", "pathogen", "contamination", "stagnant"]):
        hazards.append("Vector-borne Disease / Sewage Contamination")
    if any(k in text_content for k in ["submerged", "waterlog", "flood", "impassable"]):
        hazards.append("Traffic Gridlock & Vehicle Submersion Risk")
    if any(k in text_content for k in ["dark", "light", "night", "safety"]):
        hazards.append("Nighttime Pedestrian Vulnerability & Crime Risk")
        
    # Department mapping
    dept_code = "PUBLIC_WORKS"
    for dept in Config.DEPARTMENTS:
        if best_category in dept["categories"]:
            dept_code = dept["code"]
            break
            
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT id, name FROM departments WHERE code = ?", (dept_code,))
    dept_row = cursor.fetchone()
    db.close()
    
    recommended_dept_id = dept_row["id"] if dept_row else 1
    recommended_dept_name = dept_row["name"] if dept_row else "Public Works"
    
    # Explainable Risk Score calculation (0 to 100)
    # Severity baseline
    if "High Voltage Shock" in str(hazards) or best_category in ["Exposed Electrical Wires", "Waterlogging and Flooding"]:
        base_severity = 55
        severity_label = "Critical"
    elif "Two-Wheeler Skid" in str(hazards) or best_category in ["Potholes and Damaged Roads", "Drainage Blockage"]:
        base_severity = 35
        severity_label = "High"
    elif best_category in ["Garbage Accumulation", "Broken Streetlights", "Water Leakage"]:
        base_severity = 25
        severity_label = "Medium"
    else:
        base_severity = 15
        severity_label = "Low"
        
    hazard_addition = min(35, len(hazards) * 15)
    exposure_addition = 15 # baseline urban street exposure
    
    final_risk_score = min(98, max(12, base_severity + hazard_addition + exposure_addition))
    
    reasoning = (
        f"Assigned a {severity_label} priority (Risk Score: {final_risk_score}/100). "
        f"Base category weight ({base_severity} pts) combined with {len(hazards)} identified hazard factors (+{hazard_addition} pts) "
        f"and public right-of-way exposure (+{exposure_addition} pts). Recommended assignment to {recommended_dept_name}."
    )
    
    return {
        "available": True,
        "predicted_category": best_category,
        "confidence_score": round(confidence, 2),
        "risk_score": final_risk_score,
        "severity_level": severity_label,
        "recommended_dept_id": recommended_dept_id,
        "recommended_dept_name": recommended_dept_name,
        "hazard_flags": hazards,
        "reasoning": reasoning
    }

def compare_before_after(before_path, after_path):
    """
    Compares before and after repair images.
    Provides human-review flags rather than certifying repair independently.
    """
    if not before_path or not after_path or not os.path.exists(before_path) or not os.path.exists(after_path):
        return {
            "verified": False,
            "status": "Incomplete Data",
            "notes": "Both before and after images are required for visual comparison."
        }
        
    try:
        p_before = analyze_image_properties(before_path)
        p_after = analyze_image_properties(after_path)
        
        # Check that images are distinct
        with open(before_path, 'rb') as f1, open(after_path, 'rb') as f2:
            h1 = hashlib.sha256(f1.read()).hexdigest()
            h2 = hashlib.sha256(f2.read()).hexdigest()
            
        if h1 == h2:
            return {
                "verified": False,
                "status": "Duplicate Image Detected",
                "notes": "The uploaded resolution photo is identical to the original complaint photo."
            }
            
        return {
            "verified": True,
            "status": "Ready for Human & Citizen Verification",
            "notes": "Visual variance detected between evidence photos. Ready for citizen sign-off."
        }
    except Exception as e:
        return {
            "verified": False,
            "status": "Error",
            "notes": f"Image comparison error: {str(e)}"
        }
