from database import get_db

def create_notification(user_id, title, message, link=None, notification_type='status_change'):
    """Creates a new in-app notification for a user."""
    try:
        db = get_db()
        cursor = db.cursor()
        cursor.execute('''
            INSERT INTO notifications (user_id, title, message, link, notification_type, is_read)
            VALUES (?, ?, ?, ?, ?, 0)
        ''', (user_id, title, message, link, notification_type))
        db.commit()
        db.close()
        return True
    except Exception as e:
        print(f"Failed to create notification: {e}")
        return False

def get_user_notifications(user_id, limit=20):
    """Fetches notifications for a user."""
    db = get_db()
    cursor = db.cursor()
    cursor.execute('''
        SELECT * FROM notifications
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT ?
    ''', (user_id, limit))
    notifications = cursor.fetchall()
    db.close()
    return notifications

def get_unread_count(user_id):
    """Returns unread notification count for badge."""
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0', (user_id,))
    count = cursor.fetchone()[0]
    db.close()
    return count

def mark_all_notifications_read(user_id):
    """Marks all notifications as read for user."""
    db = get_db()
    cursor = db.cursor()
    cursor.execute('UPDATE notifications SET is_read = 1 WHERE user_id = ?', (user_id,))
    db.commit()
    db.close()
