from datetime import datetime, timedelta
from config import Config
from database import get_db
from services.notification_service import create_notification

def calculate_sla_deadlines(priority):
    """
    Returns (sla_ack_due, sla_resolve_due) formatted strings based on priority SLA rules.
    """
    rules = Config.SLA_RULES.get(priority, Config.SLA_RULES["Medium"])
    now = datetime.now()
    ack_due = now + timedelta(hours=rules["ack_hours"])
    resolve_due = now + timedelta(hours=rules["resolve_hours"])
    return ack_due.strftime('%Y-%m-%d %H:%M:%S'), resolve_due.strftime('%Y-%m-%d %H:%M:%S')

def check_and_escalate_overdue():
    """
    Scans active complaints, updates overdue flags, applies multi-level escalations,
    records escalation logs, and sends alert notifications.
    """
    db = get_db()
    cursor = db.cursor()
    
    # Query unresolved complaints with SLA due dates
    cursor.execute('''
        SELECT c.*, u.id as citizen_user_id, u.name as citizen_name
        FROM complaints c
        JOIN users u ON c.citizen_id = u.id
        WHERE c.status NOT IN ('Resolved', 'Rejected')
          AND c.sla_resolve_due IS NOT NULL
    ''')
    complaints = cursor.fetchall()
    
    now = datetime.now()
    escalated_count = 0
    
    for comp in complaints:
        try:
            resolve_due = datetime.strptime(comp['sla_resolve_due'], '%Y-%m-%d %H:%M:%S')
        except Exception:
            continue
            
        if now > resolve_due:
            # Overdue! Calculate hours past due
            hours_overdue = (now - resolve_due).total_seconds() / 3600.0
            
            # Determine appropriate escalation level
            new_level = comp['escalation_level']
            escalated = False
            role_escalated = ""
            reason = ""
            
            if hours_overdue > 24 and comp['escalation_level'] < 3:
                new_level = 3
                role_escalated = "Municipal Commissioner & Grievance Ombudsman"
                reason = f"Complaint unresolved after exceeding SLA by {int(hours_overdue)} hours."
                escalated = True
            elif hours_overdue > 12 and comp['escalation_level'] < 2:
                new_level = 2
                role_escalated = "Department Head & Zonal Officer"
                reason = f"Complaint exceeded SLA deadline by {int(hours_overdue)} hours."
                escalated = True
            elif comp['escalation_level'] < 1:
                new_level = 1
                role_escalated = "Ward Supervisor"
                reason = "Resolution deadline breached."
                escalated = True
                
            if escalated or comp['is_overdue'] == 0:
                cursor.execute('''
                    UPDATE complaints
                    SET is_overdue = 1,
                        escalation_level = ?,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ''', (new_level, comp['id']))
                
                if escalated:
                    # Log escalation
                    cursor.execute('''
                        INSERT INTO sla_escalation_logs (complaint_id, escalation_level, triggered_reason, escalated_to_role, notes)
                        VALUES (?, ?, ?, ?, ?)
                    ''', (comp['id'], new_level, reason, role_escalated, f"Auto-escalated by CivicShield SLA daemon at {now.strftime('%Y-%m-%d %H:%M')}"))
                    
                    # Notify assigned officer if any
                    if comp['assigned_officer_id']:
                        create_notification(
                            comp['assigned_officer_id'],
                            f"URGENT SLA Escalation: {comp['id']}",
                            f"Complaint {comp['id']} has escalated to Level {new_level} ({role_escalated}). Immediate action required.",
                            f"/authority/complaint/{comp['id']}",
                            "sla_warning"
                        )
                        
                    # Notify citizen that their complaint has received priority escalation
                    create_notification(
                        comp['citizen_id'],
                        f"Complaint Escalated to Supervisor: {comp['id']}",
                        f"Your issue has breached standard resolution timeline and was escalated to {role_escalated} for accelerated action.",
                        f"/citizen/complaint/{comp['id']}",
                        "sla_warning"
                    )
                    escalated_count += 1
        else:
            # Not overdue
            if comp['is_overdue'] == 1:
                cursor.execute('UPDATE complaints SET is_overdue = 0 WHERE id = ?', (comp['id'],))
                
    db.commit()
    db.close()
    return escalated_count
