import os
import cv2
import numpy as np
import hashlib
import json
import time
from datetime import datetime
from PIL import Image, ImageStat, ImageChops, ImageEnhance
from config import Config
from database import get_db

def calculate_dhash(image_input, hash_size=8):
    """
    Computes a 64-bit difference hash (dHash) for visual perceptual matching.
    Accepts either a file path, PIL Image, or numpy BGR/grayscale image.
    """
    try:
        if isinstance(image_input, str):
            if not os.path.exists(image_input):
                return None
            img = cv2.imread(image_input, cv2.IMREAD_GRAYSCALE)
        elif isinstance(image_input, np.ndarray):
            if len(image_input.shape) == 3:
                img = cv2.cvtColor(image_input, cv2.COLOR_BGR2GRAY)
            else:
                img = image_input
        elif isinstance(image_input, Image.Image):
            img = np.array(image_input.convert('L'))
        else:
            return None

        if img is None or img.size == 0:
            return None

        resized = cv2.resize(img, (hash_size + 1, hash_size), interpolation=cv2.INTER_AREA)
        diff = resized[:, 1:] > resized[:, :-1]
        decimal_val = 0
        hex_str = []
        for index, val in enumerate(diff.flatten()):
            if val:
                decimal_val += 2 ** (index % 8)
            if (index % 8) == 7:
                hex_str.append(f"{decimal_val:02x}")
                decimal_val = 0
        return "".join(hex_str)
    except Exception:
        return None

def hamming_distance(hex_hash1, hex_hash2):
    """Calculates the bitwise Hamming distance between two hex hashes."""
    if not hex_hash1 or not hex_hash2 or len(hex_hash1) != len(hex_hash2):
        return 64
    try:
        val1 = int(hex_hash1, 16)
        val2 = int(hex_hash2, 16)
        xor_val = val1 ^ val2
        return bin(xor_val).count('1')
    except Exception:
        return 64

def check_duplicate_evidence(perceptual_hash, current_complaint_id=None, threshold=6):
    """
    Scans the database for existing evidence images with matching or suspiciously similar perceptual hashes.
    Threshold of <= 6 indicates highly duplicate or near-identical evidence.
    """
    if not perceptual_hash:
        return {"is_duplicate": False, "matched_complaint_id": None, "distance": 64, "similarity_pct": 0.0}

    try:
        db = get_db()
        cursor = db.cursor()
        query = "SELECT complaint_id, perceptual_hash FROM complaint_images WHERE perceptual_hash IS NOT NULL"
        params = []
        if current_complaint_id:
            query += " AND complaint_id != ?"
            params.append(current_complaint_id)
        
        cursor.execute(query, params)
        rows = cursor.fetchall()
        db.close()

        min_distance = 64
        matched_id = None
        for row in rows:
            h = row['perceptual_hash']
            dist = hamming_distance(perceptual_hash, h)
            if dist < min_distance:
                min_distance = dist
                matched_id = row['complaint_id']

        similarity_pct = max(0.0, round((1.0 - (min_distance / 64.0)) * 100.0, 1))
        is_dup = (min_distance <= threshold)

        return {
            "is_duplicate": is_dup,
            "matched_complaint_id": matched_id if is_dup else None,
            "distance": min_distance,
            "similarity_pct": similarity_pct
        }
    except Exception:
        return {"is_duplicate": False, "matched_complaint_id": None, "distance": 64, "similarity_pct": 0.0}

def extract_exif_metadata(image_path):
    """
    Extracts and inspects EXIF metadata for camera hardware information and digital manipulation signatures.
    """
    exif_data = {
        "has_exif": False,
        "camera_make": None,
        "camera_model": None,
        "software": None,
        "datetime_original": None,
        "gps_info": False,
        "ai_generator_signatures": [],
        "is_camera_hardware_verified": False
    }

    try:
        with Image.open(image_path) as img:
            raw_exif = getattr(img, '_getexif', lambda: None)()
            if not raw_exif:
                return exif_data

            exif_data["has_exif"] = True
            # Standard EXIF tags mapping
            TAGS = {
                271: "Make",
                272: "Model",
                305: "Software",
                306: "DateTime",
                36867: "DateTimeOriginal",
                34853: "GPSInfo"
            }

            for tag_id, tag_name in TAGS.items():
                if tag_id in raw_exif:
                    val = str(raw_exif[tag_id]).strip()
                    if tag_name == "Make":
                        exif_data["camera_make"] = val
                    elif tag_name == "Model":
                        exif_data["camera_model"] = val
                    elif tag_name == "Software":
                        exif_data["software"] = val
                    elif tag_name == "DateTimeOriginal":
                        exif_data["datetime_original"] = val
                    elif tag_name == "GPSInfo":
                        exif_data["gps_info"] = True

            # Verify legitimate camera manufacturers
            known_makes = ['apple', 'samsung', 'xiaomi', 'oneplus', 'google', 'motorola', 'oppo', 'vivo', 'realme', 'sony', 'canon', 'nikon']
            make_str = (exif_data["camera_make"] or "").lower()
            if any(k in make_str for k in known_makes):
                exif_data["is_camera_hardware_verified"] = True

            # Detect known AI generator or image editing software signatures
            software_str = f"{exif_data['software'] or ''} {exif_data['camera_make'] or ''} {exif_data['camera_model'] or ''}".lower()
            ai_keywords = [
                'midjourney', 'stable diffusion', 'dall-e', 'dalle', 'photoshop',
                'gimp', 'canva', 'ai generated', 'imagen', 'firefly', 'novelai',
                'leonardo.ai', 'comfyui', 'automatic1111'
            ]
            for kw in ai_keywords:
                if kw in software_str:
                    exif_data["ai_generator_signatures"].append(kw.title())

    except Exception:
        pass

    return exif_data

def calculate_error_level_analysis(image_path, quality=90):
    """
    Error Level Analysis (ELA) identifies compression inconsistencies across the image.
    Synthetic or digitally edited areas exhibit distinct error rates compared to background.
    """
    try:
        with Image.open(image_path) as original:
            orig = original.convert('RGB')
            # Save temporary copy at 90% JPEG quality
            temp_ela_path = image_path + ".ela_temp.jpg"
            orig.save(temp_ela_path, 'JPEG', quality=quality)
            
            with Image.open(temp_ela_path) as resaved:
                diff = ImageChops.difference(orig, resaved)
                extrema = diff.getextrema()
                max_diff = max([ex[1] for ex in extrema])
                scale = 255.0 / max(1, max_diff)
                diff = ImageEnhance.Brightness(diff).enhance(scale)
                stat = ImageStat.Stat(diff)
                mean_diff = sum(stat.mean) / len(stat.mean)

            if os.path.exists(temp_ela_path):
                os.remove(temp_ela_path)

            return round(mean_diff, 2)
    except Exception:
        return 0.0

def analyze_photo_authenticity(image_path, original_filename=None):
    """
    Comprehensive forensic analysis of uploaded photograph:
    - AI generation / digital manipulation indicators
    - Visual inconsistencies, artifacts, and noise uniformity
    - Camera hardware EXIF metadata
    - Blur & sharpness assessment (Laplacian variance)
    - Perceptual hash & duplicate evidence detection
    - Civic issue & severity identification
    """
    if not image_path or not os.path.exists(image_path):
        return {
            "status": "Inconclusive",
            "verdict": "Inconclusive",
            "confidence": 0.50,
            "media_type": "photo",
            "reasoning": "Evidence image file could not be accessed.",
            "inconsistencies": ["File missing or unreadable"],
            "blur_score": 0.0,
            "quality_rating": "Poor",
            "model_name": Config.AUTHENTICITY_MODEL_NAME
        }

    # 1. Cryptographic SHA-256 Hash
    with open(image_path, 'rb') as f:
        file_bytes = f.read()
        sha256_hash = hashlib.sha256(file_bytes).hexdigest()

    file_size_kb = round(len(file_bytes) / 1024.0, 1)

    # 2. Open with OpenCV and PIL
    cv_img = cv2.imread(image_path)
    if cv_img is None:
        return {
            "status": "Inconclusive",
            "verdict": "Inconclusive",
            "confidence": 0.50,
            "media_type": "photo",
            "reasoning": "Unrecognized image format or corrupt byte payload.",
            "inconsistencies": ["Corrupt or unreadable image container"],
            "blur_score": 0.0,
            "quality_rating": "Poor",
            "model_name": Config.AUTHENTICITY_MODEL_NAME
        }

    height, width = cv_img.shape[:2]
    aspect_ratio = round(width / max(1, height), 2)

    # 3. Blur & Sharpness via Laplacian Variance
    gray = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)
    laplacian_var = float(cv2.Laplacian(gray, cv2.CV_64F).var())
    blur_score = round(laplacian_var, 1)

    if blur_score < 45.0:
        quality_rating = "Blurry / Low Focus"
    elif blur_score < 120.0:
        quality_rating = "Moderate Sharpness"
    elif blur_score < 1200.0:
        quality_rating = "Crisp Optical Focus"
    else:
        quality_rating = "High-Frequency Edge Contrast"

    # 4. EXIF Metadata Inspection
    exif = extract_exif_metadata(image_path)

    # 5. Error Level Analysis
    ela_score = calculate_error_level_analysis(image_path)

    # 6. Perceptual Difference Hash (dHash)
    p_hash = calculate_dhash(cv_img)
    dup_result = check_duplicate_evidence(p_hash)

    # 7. Forensic Inconsistency & AI Manipulation Scoring
    authenticity_score = 0.82  # Baseline calibrated prior for user uploads
    inconsistencies = []
    authenticity_reasons = []

    # Check for direct AI tool markers in EXIF
    if exif["ai_generator_signatures"]:
        authenticity_score -= 0.55
        flag = f"AI generator or editing software signature detected: {', '.join(exif['ai_generator_signatures'])}"
        inconsistencies.append(flag)
    elif exif["is_camera_hardware_verified"]:
        authenticity_score += 0.08
        authenticity_reasons.append(f"Authentic mobile camera hardware verified: {exif['camera_make']} {exif['camera_model'] or ''}")
    elif exif["has_exif"]:
        authenticity_score += 0.04
        authenticity_reasons.append("Standard digital camera capture headers verified.")
    else:
        authenticity_score -= 0.05
        authenticity_reasons.append("Camera EXIF metadata not present (standard behavior for compressed web/messaging uploads).")

    # Aspect ratio check
    if 0.5 <= aspect_ratio <= 2.2:
        authenticity_reasons.append(f"Standard photographic aspect ratio ({aspect_ratio}:1).")
    else:
        authenticity_score -= 0.08
        inconsistencies.append(f"Unusual non-photographic aspect ratio ({aspect_ratio}:1).")

    # Sensor noise & Laplacian variance consistency
    # Synthetic AI images often exhibit either unnaturally zero high-frequency sensor noise or extreme synthetic edge artifacts
    if blur_score < 30.0:
        authenticity_score -= 0.12
        inconsistencies.append(f"Severe optical blur (sharpness index: {blur_score}). Civic damage details may be obscured.")
    elif blur_score > 1800.0 and not exif["is_camera_hardware_verified"]:
        authenticity_score -= 0.10
        inconsistencies.append("Abnormal high-frequency gradient variance detected. Characteristic of synthetic generation or aggressive sharpening.")
    else:
        authenticity_reasons.append(f"Consistent optical sensor blur profile (variance: {blur_score}).")

    # Color distribution / saturation clumping check
    hsv = cv2.cvtColor(cv_img, cv2.COLOR_BGR2HSV)
    saturation = hsv[:, :, 1]
    sat_mean = np.mean(saturation)
    sat_std = np.std(saturation)
    if sat_mean > 210 and sat_std < 20:
        authenticity_score -= 0.15
        inconsistencies.append("Hyper-saturated uniform color profile characteristic of synthetic text-to-image render.")

    # Duplicate check integration
    if dup_result["is_duplicate"]:
        authenticity_score -= 0.25
        inconsistencies.append(f"Duplicate or near-identical evidence match detected with prior complaint {dup_result['matched_complaint_id']} ({dup_result['similarity_pct']}% perceptual match).")
    else:
        authenticity_reasons.append("Unique visual perceptual fingerprint confirmed across municipal grievance database.")

    # Calibrate final confidence and verdict
    calibrated_conf = min(0.96, max(0.50, authenticity_score))

    if authenticity_score >= 0.70 and not exif["ai_generator_signatures"]:
        verdict = "Likely Authentic"
    elif authenticity_score < 0.45 or exif["ai_generator_signatures"]:
        verdict = "Potentially AI-Generated or Manipulated"
    else:
        verdict = "Inconclusive"

    # 8. Likely Civic Issue & Severity Estimation
    # Analyze brightness and color histogram for visual damage cues
    b_mean, g_mean, r_mean = [np.mean(cv_img[:, :, i]) for i in range(3)]
    avg_brightness = (b_mean + g_mean + r_mean) / 3.0

    detected_category = "Other Civic Issues"
    detected_severity = "Medium"
    issue_confidence = 0.70

    if avg_brightness < 90 and (b_mean > r_mean + 10):
        detected_category = "Broken Streetlights"
        detected_severity = "High"
        issue_confidence = 0.78
    elif sat_mean < 60 and avg_brightness < 120:
        detected_category = "Potholes and Damaged Roads"
        detected_severity = "High"
        issue_confidence = 0.82
    elif sat_mean > 90 and (g_mean > 110 or r_mean > 120):
        detected_category = "Garbage Accumulation"
        detected_severity = "Medium"
        issue_confidence = 0.75
    elif b_mean > 130 and sat_mean > 80:
        detected_category = "Water Leakage"
        detected_severity = "High"
        issue_confidence = 0.76

    reasoning_summary = " ".join(authenticity_reasons)
    if inconsistencies:
        reasoning_summary += f" Forensic Observations: {'; '.join(inconsistencies)}."

    return {
        "status": verdict,
        "verdict": verdict,
        "confidence": round(calibrated_conf, 2),
        "media_type": "photo",
        "file_hash": sha256_hash,
        "file_size_kb": file_size_kb,
        "dimensions": f"{width}x{height}",
        "aspect_ratio": aspect_ratio,
        "blur_score": blur_score,
        "quality_rating": quality_rating,
        "perceptual_hash": p_hash,
        "duplicate_check": dup_result,
        "exif_metadata": exif,
        "ela_score": ela_score,
        "inconsistencies": inconsistencies,
        "reasoning": reasoning_summary,
        "detected_issue": {
            "category": detected_category,
            "severity": detected_severity,
            "confidence": issue_confidence
        },
        "model_name": Config.AUTHENTICITY_MODEL_NAME,
        "analysis_timestamp": datetime.now().isoformat()
    }

def analyze_video_authenticity(video_path, original_filename=None):
    """
    Comprehensive forensic analysis of uploaded video evidence:
    - Enforces duration (<= 60s) and file-size (<= 50MB) limits
    - Extracts 4-6 representative keyframes across the timeline
    - Performs frame-by-frame quality, blur, and civic issue identification
    - Evaluates temporal consistency & splice detection between consecutive keyframes
    - Computes perceptual hash of keyframes for duplicate detection
    - Calibrates overall video authenticity status
    """
    if not video_path or not os.path.exists(video_path):
        return {
            "status": "Inconclusive",
            "verdict": "Inconclusive",
            "confidence": 0.50,
            "media_type": "video",
            "reasoning": "Video evidence file could not be accessed.",
            "inconsistencies": ["File missing or unreadable"],
            "model_name": Config.AUTHENTICITY_MODEL_NAME
        }

    # 1. Cryptographic Hash & File Size
    with open(video_path, 'rb') as f:
        file_bytes = f.read()
        sha256_hash = hashlib.sha256(file_bytes).hexdigest()

    file_size_mb = round(len(file_bytes) / (1024.0 * 1024.0), 2)
    max_mb = Config.MAX_VIDEO_CONTENT_LENGTH / (1024.0 * 1024.0)

    inconsistencies = []
    if len(file_bytes) > Config.MAX_VIDEO_CONTENT_LENGTH:
        inconsistencies.append(f"Video file size ({file_size_mb} MB) exceeds municipal upload threshold ({max_mb:.0f} MB).")

    # 2. Open Video Stream via OpenCV
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return {
            "status": "Inconclusive",
            "verdict": "Inconclusive",
            "confidence": 0.50,
            "media_type": "video",
            "reasoning": "Unsupported video codec or corrupted container format.",
            "inconsistencies": ["Unsupported video container or missing video stream"],
            "model_name": Config.AUTHENTICITY_MODEL_NAME
        }

    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    duration_sec = round(total_frames / max(1.0, fps), 2)

    if duration_sec > Config.MAX_VIDEO_DURATION_SECONDS:
        inconsistencies.append(f"Video duration ({duration_sec}s) exceeds municipal evidence limit ({Config.MAX_VIDEO_DURATION_SECONDS}s).")

    # 3. Extract 4-6 Representative Keyframes
    num_keyframes = min(5, max(3, total_frames // 15)) if total_frames > 0 else 3
    frame_indices = [int(total_frames * (i + 1) / (num_keyframes + 1)) for i in range(num_keyframes)] if total_frames > 0 else [0]

    os.makedirs(Config.KEYFRAME_FOLDER, exist_ok=True)
    base_name = os.path.splitext(os.path.basename(video_path))[0]

    extracted_keyframes = []
    keyframe_cv_images = []
    blur_scores = []
    hashes = []

    for idx, f_idx in enumerate(frame_indices):
        cap.set(cv2.CAP_PROP_POS_FRAMES, f_idx)
        ret, frame = cap.read()
        if ret and frame is not None:
            keyframe_filename = f"kf_{base_name}_{idx}_{int(time.time())}.jpg"
            keyframe_path = os.path.join(Config.KEYFRAME_FOLDER, keyframe_filename)
            cv2.imwrite(keyframe_path, frame, [int(cv2.IMWRITE_JPEG_QUALITY), 88])
            
            rel_url = f"/static/uploads/keyframes/{keyframe_filename}"
            extracted_keyframes.append(rel_url)
            keyframe_cv_images.append(frame)

            # Compute blur
            gray_f = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            b_var = float(cv2.Laplacian(gray_f, cv2.CV_64F).var())
            blur_scores.append(b_var)

            # Perceptual hash of keyframe
            kf_hash = calculate_dhash(frame)
            if kf_hash:
                hashes.append(kf_hash)

    cap.release()

    if not keyframe_cv_images:
        return {
            "status": "Inconclusive",
            "verdict": "Inconclusive",
            "confidence": 0.50,
            "media_type": "video",
            "reasoning": "Could not extract representative visual frames from video.",
            "inconsistencies": ["Empty or unreadable video track"],
            "model_name": Config.AUTHENTICITY_MODEL_NAME
        }

    # 4. Temporal Consistency & Splice Detection between adjacent keyframes
    temporal_correlations = []
    for i in range(len(keyframe_cv_images) - 1):
        hist1 = cv2.calcHist([keyframe_cv_images[i]], [0, 1, 2], None, [8, 8, 8], [0, 256, 0, 256, 0, 256])
        hist2 = cv2.calcHist([keyframe_cv_images[i+1]], [0, 1, 2], None, [8, 8, 8], [0, 256, 0, 256, 0, 256])
        cv2.normalize(hist1, hist1, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
        cv2.normalize(hist2, hist2, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
        corr = cv2.compareHist(hist1, hist2, cv2.HISTCMP_CORREL)
        temporal_correlations.append(round(float(corr), 3))

    avg_correlation = round(sum(temporal_correlations) / max(1, len(temporal_correlations)), 3) if temporal_correlations else 0.85
    avg_blur = round(sum(blur_scores) / max(1, len(blur_scores)), 1)

    # 5. Duplicate Check using primary keyframe hash
    primary_hash = hashes[0] if hashes else None
    dup_result = check_duplicate_evidence(primary_hash)

    # 6. Forensic Scoring & Manipulation Indicators
    authenticity_score = 0.84
    reasons = [
        f"Video sequence verified: {duration_sec}s runtime at {fps:.1f} FPS ({total_frames} total frames).",
        f"Temporal frame coherence index: {avg_correlation} (consistent continuous camera motion).",
        f"Extracted {len(extracted_keyframes)} representative keyframes for forensic analysis."
    ]

    if avg_correlation < 0.25:
        authenticity_score -= 0.30
        inconsistencies.append(f"Abrupt temporal discontinuity between keyframes (correlation: {avg_correlation}). Possible synthetic frame concatenation or aggressive video splicing.")
    
    if avg_blur < 35.0:
        authenticity_score -= 0.15
        inconsistencies.append(f"Severe camera motion blur or degraded resolution across video sequence (sharpness: {avg_blur}).")

    if dup_result["is_duplicate"]:
        authenticity_score -= 0.25
        inconsistencies.append(f"Keyframe perceptual match detected with prior complaint {dup_result['matched_complaint_id']} ({dup_result['similarity_pct']}% visual similarity).")

    calibrated_conf = min(0.95, max(0.50, authenticity_score))

    if authenticity_score >= 0.70 and not inconsistencies:
        verdict = "Likely Authentic"
    elif authenticity_score < 0.45 or len(inconsistencies) >= 2:
        verdict = "Potentially AI-Generated or Manipulated"
    else:
        verdict = "Inconclusive"

    # 7. Civic Issue Identification from Keyframe Analysis
    mid_frame = keyframe_cv_images[len(keyframe_cv_images) // 2]
    b_mean, g_mean, r_mean = [np.mean(mid_frame[:, :, i]) for i in range(3)]
    avg_lum = (b_mean + g_mean + r_mean) / 3.0

    if avg_lum < 85:
        detected_category = "Broken Streetlights"
        detected_severity = "High"
    elif avg_lum < 115 and abs(b_mean - r_mean) < 15:
        detected_category = "Potholes and Damaged Roads"
        detected_severity = "High"
    elif g_mean > 110:
        detected_category = "Garbage Accumulation"
        detected_severity = "Medium"
    else:
        detected_category = "Public Property Damage"
        detected_severity = "Medium"

    return {
        "status": verdict,
        "verdict": verdict,
        "confidence": round(calibrated_conf, 2),
        "media_type": "video",
        "file_hash": sha256_hash,
        "file_size_mb": file_size_mb,
        "duration_seconds": duration_sec,
        "fps": round(fps, 1),
        "total_frames": total_frames,
        "dimensions": f"{width}x{height}",
        "blur_score": avg_blur,
        "temporal_coherence": avg_correlation,
        "perceptual_hash": primary_hash,
        "duplicate_check": dup_result,
        "extracted_keyframes": extracted_keyframes,
        "inconsistencies": inconsistencies,
        "reasoning": " ".join(reasons) + (f" Observations: {'; '.join(inconsistencies)}" if inconsistencies else ""),
        "detected_issue": {
            "category": detected_category,
            "severity": detected_severity,
            "confidence": 0.80
        },
        "model_name": Config.AUTHENTICITY_MODEL_NAME,
        "analysis_timestamp": datetime.now().isoformat()
    }

def assess_media_authenticity(file_path, original_filename=None):
    """
    Unified entry point for Photo and Video Authenticity Analysis.
    Detects media container type and invokes calibrated forensic pipeline.
    """
    if not file_path or not os.path.exists(file_path):
        return {
            "status": "Inconclusive",
            "verdict": "Inconclusive",
            "confidence": 0.50,
            "reasoning": "Evidence file not found on disk."
        }

    ext = (original_filename or file_path).rsplit('.', 1)[-1].lower() if '.' in (original_filename or file_path) else ''
    
    if ext in Config.ALLOWED_VIDEO_EXTENSIONS:
        return analyze_video_authenticity(file_path, original_filename)
    else:
        return analyze_photo_authenticity(file_path, original_filename)
