from datetime import datetime, timedelta
from database import get_db
from config import Config
from services.government_integration import dispatch_notification_with_tracking

import re

def resolve_jurisdiction_and_routing(category, latitude=17.3850, longitude=78.4867, address="", location_address="", description="", ward="Ward 12 - Central", **kwargs):
    """
    Analyzes category, address keywords, coordinates, and ward to determine:
    - Administrative Jurisdiction (Ward, Zone, or External Authority)
    - Responsible Department
    - External Authority flags
    - Initial hierarchy tier (1=Ward Field Officer, 2=Dept Officer, 3=Dept Head)
    - Recommended assigned officer
    """
    addr = location_address or address or ""
    desc = description or kwargs.get('desc', "")
    text_corpus = f"{category} {addr} {desc} {ward}".lower()
    db = get_db()
    cursor = db.cursor()
    
    # 1. Check for External Authority Boundaries using word-boundary matching
    is_external = 0
    external_name = None
    jurisdiction_code = "WARD_12"
    
    if re.search(r'\b(national\s+highway|nh-?65|nh-?44|outer\s+ring\s+road|orr|nhai)\b', text_corpus):
        is_external = 1
        external_name = "National Highways Authority of India (NHAI)"
        jurisdiction_code = "EXT_NHAI"
    elif re.search(r'\b(metro\s+pillar|metro\s+viaduct|hmrl|metro\s+rail|metro\s+track)\b', text_corpus):
        is_external = 1
        external_name = "Hyderabad Metro Rail Limited (HMRL)"
        jurisdiction_code = "EXT_HMRL"
    elif re.search(r'\b(high\s+tension|extra\s+high\s+tension|132kv|220kv|substation|transco|tsspdcl\s+transco)\b', text_corpus):
        is_external = 1
        external_name = "State Electricity Transmission Grid (TSSPDCL Transco)"
        jurisdiction_code = "EXT_TSSPDCL_TRANS"
    else:
        # Match by municipal ward
        if re.search(r'\b(ward\s*4|begumpet|secunderabad)\b', text_corpus):
            jurisdiction_code = "WARD_4"
        elif re.search(r'\b(ward\s*7|madhapur|hitec)\b', text_corpus):
            jurisdiction_code = "WARD_7"
        elif re.search(r'\b(ward\s*14|uppal|dilsukhnagar)\b', text_corpus):
            jurisdiction_code = "WARD_14"
        else:
            jurisdiction_code = "WARD_12"
            
    cursor.execute("SELECT id, name, type FROM administrative_jurisdictions WHERE code = ?", (jurisdiction_code,))
    jur_row = cursor.fetchone()
    jurisdiction_id = jur_row['id'] if jur_row else 1
    jurisdiction_name = jur_row['name'] if jur_row else ward

    # 2. Match Department using Routing Rules or Default Category Mapping
    cursor.execute('''
        SELECT recommended_dept_id, primary_handler_tier, is_external_jurisdiction, external_authority_name
        FROM hierarchical_routing_rules
        WHERE category = ?
        LIMIT 1
    ''', (category,))
    rule = cursor.fetchone()
    
    if rule and rule['recommended_dept_id']:
        dept_id = rule['recommended_dept_id']
        handler_tier = rule['primary_handler_tier'] or 1
        if rule['is_external_jurisdiction']:
            is_external = 1
            external_name = rule['external_authority_name']
    else:
        # Fallback to standard config department mapping
        dept_code = "PUBLIC_WORKS"
        for dept in Config.DEPARTMENTS:
            if category in dept["categories"]:
                dept_code = dept["code"]
                break
        cursor.execute("SELECT id FROM departments WHERE code = ?", (dept_code,))
        d_row = cursor.fetchone()
        dept_id = d_row['id'] if d_row else 1
        handler_tier = 1

    # 3. Find Responsible Officer matching Department & Hierarchy Tier
    cursor.execute('''
        SELECT u.id, u.name, u.phone, u.email, ap.hierarchy_tier, ap.designation
        FROM users u
        JOIN authority_profiles ap ON u.id = ap.user_id
        WHERE ap.department_id = ? AND ap.approval_status = 'approved' AND u.is_approved = 1
        ORDER BY CASE WHEN ap.hierarchy_tier = ? THEN 0 ELSE 1 END, u.id ASC
        LIMIT 1
    ''', (dept_id, handler_tier))
    officer_row = cursor.fetchone()
    
    assigned_officer_id = officer_row['id'] if officer_row else None
    assigned_officer_name = officer_row['name'] if officer_row else "Unassigned"
    
    db.close()
    
    return {
        "jurisdiction_id": jurisdiction_id,
        "jurisdiction_code": jurisdiction_code,
        "jurisdiction_name": jurisdiction_name,
        "department_id": dept_id,
        "is_external_authority": is_external,
        "external_authority_name": external_name,
        "initial_hierarchy_tier": handler_tier,
        "assigned_officer_id": assigned_officer_id,
        "assigned_officer_name": assigned_officer_name
    }

def acknowledge_complaint(complaint_id, officer_user_id, notes=None):
    """
    Records official acknowledgment of a complaint by assigned officer.
    Sets status from 'Submitted' to 'Under Review', logs audit, and notifies citizen.
    """
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT * FROM complaints WHERE id = ?', (complaint_id,))
    comp = cursor.fetchone()
    if not comp:
        db.close()
        return False, "Complaint not found"
        
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    cursor.execute('''
        UPDATE complaints
        SET acknowledged_at = ?,
            acknowledged_by = ?,
            status = CASE WHEN status = 'Submitted' THEN 'Under Review' ELSE status END,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    ''', (now_str, officer_user_id, complaint_id))
    
    audit_note = notes if notes else f"Officially acknowledged and accepted for inspection by Officer #{officer_user_id}"
    cursor.execute('''
        INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes)
        VALUES (?, ?, 'Under Review', ?, ?)
    ''', (complaint_id, comp['status'], officer_user_id, audit_note))
    
    db.commit()
    db.close()

    # Notify citizen after transaction closed
    try:
        dispatch_notification_with_tracking(
            comp['citizen_id'],
            f"Grievance Acknowledged: {complaint_id}",
            f"Your issue has been formally acknowledged by the municipal field engineering unit and queued for inspection.",
            f"/citizen/complaint/{complaint_id}",
            channel='in_app',
            notification_type='status_change'
        )
    except Exception:
        pass
    
    return True, "Complaint formally acknowledged."

def create_supervisory_instruction(complaint_id, supervisor_id=None, instruction_type="Directive", instruction_text="", review_deadline=None, deadline_hours=None, is_public_to_citizen=1, **kwargs):
    """
    Higher Official (Dept Head / Commissioner) issues a binding supervisory directive.
    """
    supervisor_id = supervisor_id or kwargs.get('issued_by_user_id') or 1
    if deadline_hours and not review_deadline:
        review_deadline = (datetime.now() + timedelta(hours=deadline_hours)).strftime('%Y-%m-%d %H:%M:%S')
        
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT * FROM complaints WHERE id = ?', (complaint_id,))
    comp = cursor.fetchone()
    if not comp:
        db.close()
        return False, "Complaint not found"
        
    cursor.execute('''
        INSERT INTO supervisory_instructions (complaint_id, supervisor_id, instruction_type, instruction_text, review_deadline)
        VALUES (?, ?, ?, ?, ?)
    ''', (complaint_id, supervisor_id, instruction_type, instruction_text, review_deadline))
    inst_id = cursor.lastrowid
    
    cursor.execute('''
        UPDATE complaints
        SET supervisory_flag = 1,
            current_hierarchy_level = MAX(current_hierarchy_level, 3),
            citizen_escalation_reason = COALESCE(citizen_escalation_reason, 'Supervisory directive issued by municipal leadership for accelerated field inspection and resolution.'),
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    ''', (complaint_id,))
    
    # Log in status history
    cursor.execute('''
        INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes)
        VALUES (?, ?, ?, ?, ?)
    ''', (complaint_id, comp['status'], comp['status'], supervisor_id, f"SUPERVISORY DIRECTIVE ({instruction_type}): {instruction_text}"))
    
    assigned_officer_id = comp['assigned_officer_id']
    db.commit()
    db.close()

    # Notify assigned officer after transaction committed
    if assigned_officer_id:
        try:
            dispatch_notification_with_tracking(
                assigned_officer_id,
                f"SUPERVISORY DIRECTIVE on {complaint_id}",
                f"Higher Authority issued directive ({instruction_type}): {instruction_text}",
                f"/authority/complaint/{complaint_id}",
                channel='in_app',
                notification_type='system'
            )
        except Exception:
            pass
        
    return True, f"Supervisory directive #{inst_id} ({instruction_type}) successfully issued."

def respond_to_supervisory_instruction(instruction_id, officer_id, response_text=None, compliance_notes=None, **kwargs):
    """Officer responds to higher official directive."""
    response_text = response_text or compliance_notes or kwargs.get('notes') or "Directive acknowledged and complied with."
    db = get_db()
    cursor = db.cursor()
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    cursor.execute('''
        UPDATE supervisory_instructions
        SET officer_acknowledged = 1,
            officer_response = ?,
            officer_responded_at = ?
        WHERE id = ?
    ''', (response_text, now_str, instruction_id))
    
    cursor.execute('SELECT complaint_id, supervisor_id FROM supervisory_instructions WHERE id = ?', (instruction_id,))
    inst = cursor.fetchone()
    sup_id = None
    c_id = None
    if inst:
        sup_id = inst['supervisor_id']
        c_id = inst['complaint_id']
        cursor.execute('''
            INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes)
            VALUES (?, 'Under Review', 'In Progress', ?, ?)
        ''', (c_id, officer_id, f"Officer responded to directive: '{response_text}'"))
        
    db.commit()
    db.close()

    # Notify supervisor after transaction committed
    if sup_id and c_id:
        try:
            dispatch_notification_with_tracking(
                sup_id,
                f"Officer Responded to Directive: {c_id}",
                f"Officer #{officer_id} reported: {response_text}",
                f"/authority/complaint/{c_id}",
                channel='in_app',
                notification_type='status_change'
            )
        except Exception:
            pass

    return True, "Compliance response recorded."

def initiate_complaint_transfer(complaint_id, from_dept_id, to_dept_id, transfer_reason=None, user_id=None, initiated_by_user_id=None, reason=None, **kwargs):
    """
    Initiates a department transfer request without altering the original unique ID or evidence history.
    """
    reason_text = reason or transfer_reason or "Transferred to correct department"
    uid = user_id or initiated_by_user_id or kwargs.get('transferred_by') or 1
    
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT * FROM complaints WHERE id = ?', (complaint_id,))
    comp = cursor.fetchone()
    if not comp:
        db.close()
        return False, "Complaint not found"
        
    cursor.execute('''
        INSERT INTO complaint_transfers (complaint_id, from_dept_id, to_dept_id, transferred_by, transfer_reason, status)
        VALUES (?, ?, ?, ?, ?, 'Pending')
    ''', (complaint_id, from_dept_id, to_dept_id, uid, reason_text))
    transfer_id = cursor.lastrowid
    
    # Get target department name
    cursor.execute('SELECT name FROM departments WHERE id = ?', (to_dept_id,))
    to_name = cursor.fetchone()['name']
    
    cursor.execute('''
        INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes)
        VALUES (?, ?, ?, ?, ?)
    ''', (complaint_id, comp['status'], comp['status'], uid, f"Department Transfer Initiated: Recommended transfer to {to_name}. Reason: {reason_text}"))
    
    # Notify receiving department officers
    cursor.execute('''
        SELECT u.id FROM users u
        JOIN authority_profiles ap ON u.id = ap.user_id
        WHERE ap.department_id = ? AND ap.approval_status = 'approved'
    ''', (to_dept_id,))
    target_officers = cursor.fetchall()
    officer_ids = [off['id'] for off in target_officers]
    
    db.commit()
    db.close()

    # Dispatch notifications after commit
    for off_id in officer_ids:
        try:
            dispatch_notification_with_tracking(
                off_id,
                f"Department Transfer Received: {complaint_id}",
                f"Complaint {complaint_id} was transferred to your department: '{reason_text}'. Action required: Accept or Dispute.",
                f"/authority/transfers",
                channel='in_app',
                notification_type='status_change'
            )
        except Exception:
            pass

    return True, f"Department transfer #{transfer_id} initiated successfully."

def respond_to_department_transfer(transfer_id, action_or_user=None, user_id=None, dispute_reason=None, action=None, notes=None, **kwargs):
    """
    Receiving department accepts or disputes transfer ownership.
    Disputes auto-escalate to Level 3 / Grievance Ombudsman.
    """
    if action is None:
        if isinstance(action_or_user, str) and action_or_user.lower() in ['accept', 'dispute']:
            action = action_or_user
        elif isinstance(user_id, str) and user_id.lower() in ['accept', 'dispute']:
            action = user_id
            user_id = action_or_user
        else:
            action = kwargs.get('action', 'accept')
            
    if user_id is None:
        user_id = action_or_user if isinstance(action_or_user, int) else kwargs.get('user_id', 1)
        
    dispute_reason = dispute_reason or notes or kwargs.get('notes')
    act = action.lower() if action else 'accept'
    
    db = get_db()
    cursor = db.cursor()
    cursor.execute('''
        SELECT ct.*, c.id as complaint_id, d_to.name as to_dept_name
        FROM complaint_transfers ct
        JOIN complaints c ON ct.complaint_id = c.id
        JOIN departments d_to ON ct.to_dept_id = d_to.id
        WHERE ct.id = ?
    ''', (transfer_id,))
    transfer = cursor.fetchone()
    if not transfer:
        db.close()
        return False, "Transfer record not found"
        
    complaint_id = transfer['complaint_id']
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    if act == 'accept':
        cursor.execute('''
            UPDATE complaint_transfers
            SET status = 'Accepted', resolved_by = ?, resolved_notes = 'Transfer accepted by receiving department', updated_at = ?
            WHERE id = ?
        ''', (user_id, now_str, transfer_id))
        
        cursor.execute('''
            UPDATE complaints
            SET department_id = ?,
                assigned_officer_id = ?,
                current_hierarchy_level = 2,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (transfer['to_dept_id'], user_id, complaint_id))
        
        cursor.execute('''
            INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes)
            VALUES (?, 'Under Review', 'Assigned', ?, ?)
        ''', (complaint_id, user_id, f"Department Transfer Accepted. New Department: {transfer['to_dept_name']}"))
        msg = f"Transfer accepted. Complaint {complaint_id} assigned to your department."
        
    elif act == 'dispute':
        cursor.execute('''
            UPDATE complaint_transfers
            SET status = 'Disputed', dispute_reason = ?, updated_at = ?
            WHERE id = ?
        ''', (dispute_reason or "Ownership disputed by receiving engineering department.", now_str, transfer_id))
        
        cursor.execute('''
            UPDATE complaints
            SET supervisory_flag = 1,
                current_hierarchy_level = 3, -- Escalate to Level 3 Supervisory Review
                escalation_level = MAX(escalation_level, 2),
                citizen_escalation_reason = 'Departmental jurisdiction clarification in progress by Municipal Ombudsman.',
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (complaint_id,))
        
        cursor.execute('''
            INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes)
            VALUES (?, 'Under Review', 'Under Review', ?, ?)
        ''', (complaint_id, user_id, f"JURISDICTION DISPUTE: Transfer rejected by receiving department. Auto-escalated to Municipal Ombudsman. Reason: {dispute_reason}"))
        msg = f"Department transfer disputed. Complaint {complaint_id} escalated to Municipal Ombudsman for binding determination."
        
    db.commit()
    db.close()
    return True, msg
        
    db.commit()
    db.close()
    return True, msg

def check_and_escalate_hierarchical():
    """
    Automated Hierarchical Escalation Engine:
    - Missed acknowledgement deadline -> escalates from Tier 1 (Ward) to Tier 2 (Dept Officer).
    - Missed resolution deadline -> escalates to Tier 3 (Dept Head) and Tier 4 (Commissioner).
    - Critical hazards / life safety -> immediate Tier 3 alert.
    - Repeated failed resolutions (reopened) -> escalates to Tier 3.
    """
    db = get_db()
    cursor = db.cursor()
    
    cursor.execute('''
        SELECT c.*, u.name as citizen_name, d.name as department_name,
               aj.name as jurisdiction_name
        FROM complaints c
        JOIN users u ON c.citizen_id = u.id
        LEFT JOIN departments d ON c.department_id = d.id
        LEFT JOIN administrative_jurisdictions aj ON c.jurisdiction_id = aj.id
        WHERE c.status NOT IN ('Resolved', 'Rejected')
    ''')
    complaints = cursor.fetchall()
    now = datetime.now()
    escalated_count = 0
    
    pending_notifications = []

    for comp in complaints:
        needs_escalation = False
        new_tier = comp['current_hierarchy_level'] or 1
        new_level = comp['escalation_level'] or 0
        reason = ""
        citizen_reason = ""
        target_role = ""
        
        # 1. Check Missed Acknowledgment Deadline (e.g. 2 to 6 hours after filing)
        if comp['acknowledged_at'] is None and comp['sla_ack_due']:
            try:
                ack_due = datetime.strptime(comp['sla_ack_due'], '%Y-%m-%d %H:%M:%S')
                if now > ack_due and new_tier < 2:
                    needs_escalation = True
                    new_tier = 2
                    new_level = max(new_level, 1)
                    target_role = "Municipal Department Officer / AEE"
                    reason = "Field acknowledgment deadline breached without initial inspection."
                    citizen_reason = "Escalated to Department Officer to accelerate initial field inspection."
            except Exception:
                pass

        # 2. Check Resolution SLA Overdue
        if comp['sla_resolve_due']:
            try:
                res_due = datetime.strptime(comp['sla_resolve_due'], '%Y-%m-%d %H:%M:%S')
                if now > res_due:
                    hours_over = (now - res_due).total_seconds() / 3600.0
                    if hours_over > 24 and new_tier < 4:
                        needs_escalation = True
                        new_tier = 4
                        new_level = 3
                        target_role = "Municipal Commissioner & Grievance Ombudsman (Tier 4)"
                        reason = f"Resolution breached standard SLA by {int(hours_over)} hours."
                        citizen_reason = "Priority review: Escalated to Municipal Commissioner due to extended resolution timeframe."
                    elif hours_over > 0 and new_tier < 3:
                        needs_escalation = True
                        new_tier = 3
                        new_level = max(new_level, 2)
                        target_role = "Department Head / Superintending Engineer (Tier 3)"
                        reason = f"Resolution target exceeded by {int(hours_over)} hours."
                        citizen_reason = "Escalated to Zonal Department Head to fast-track municipal engineering works."
            except Exception:
                pass

        # 3. Critical Safety Hazards Check
        if comp['priority'] == 'Critical' and new_tier < 3:
            needs_escalation = True
            new_tier = 3
            new_level = max(new_level, 2)
            target_role = "Department Head & Emergency Response Coordinator"
            reason = "Life-safety critical hazard triggered immediate higher authority review."
            citizen_reason = "High-priority life safety alert: Escalated directly for executive oversight."

        # 4. Repeated Failed Resolution (Reopened Cases)
        if comp['status'] == 'Reopened' and new_tier < 3:
            needs_escalation = True
            new_tier = 3
            new_level = max(new_level, 2)
            target_role = "Superintending Engineer & Quality Ombudsman"
            reason = "Citizen disputed repair quality. Escalated for independent executive re-inspection."
            citizen_reason = "Reopened repair: Escalated to Supervisory Engineer to verify quality of work."

        if needs_escalation:
            cursor.execute('''
                UPDATE complaints
                SET current_hierarchy_level = ?,
                    escalation_level = ?,
                    is_overdue = 1,
                    citizen_escalation_reason = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ''', (new_tier, new_level, citizen_reason, comp['id']))
            
            # Log in escalation audit
            cursor.execute('''
                INSERT INTO sla_escalation_logs (complaint_id, escalation_level, triggered_reason, escalated_to_role, notes)
                VALUES (?, ?, ?, ?, ?)
            ''', (comp['id'], new_level, reason, target_role, f"Hierarchical tier escalated to Tier {new_tier}"))
            
            # Log in status history
            cursor.execute('''
                INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes)
                VALUES (?, ?, ?, NULL, ?)
            ''', (comp['id'], comp['status'], comp['status'], f"HIERARCHICAL ESCALATION to Tier {new_tier} ({target_role}): {reason}"))
            
            pending_notifications.append((
                comp['citizen_id'],
                f"Progress Update: {comp['id']} Escalated",
                citizen_reason,
                f"/citizen/complaint/{comp['id']}"
            ))
            
            if comp['assigned_officer_id']:
                pending_notifications.append((
                    comp['assigned_officer_id'],
                    f"ESCALATION ALERT: {comp['id']}",
                    f"Complaint escalated to Tier {new_tier} ({target_role}). Immediate action required: {reason}",
                    f"/authority/complaint/{comp['id']}"
                ))
                
            escalated_count += 1

    db.commit()
    db.close()

    # Dispatch notifications after outer write transaction is closed
    for user_id, title, msg, link in pending_notifications:
        try:
            dispatch_notification_with_tracking(
                user_id,
                title,
                msg,
                link,
                channel='in_app',
                notification_type='sla_warning'
            )
        except Exception:
            pass

    return escalated_count
