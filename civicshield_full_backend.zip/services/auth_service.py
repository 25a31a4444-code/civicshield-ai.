import functools
from flask import session, redirect, url_for, flash, request, g
from werkzeug.security import generate_password_hash, check_password_hash
from database import get_db

def hash_password(password: str) -> str:
    return generate_password_hash(password)

def verify_password(hash_str: str, password: str) -> bool:
    return check_password_hash(hash_str, password)

def get_current_user():
    """Fetches user record from session if logged in."""
    user_id = session.get('user_id')
    if not user_id:
        return None
    db = get_db()
    cursor = db.cursor()
    cursor.execute('''
        SELECT u.*, ap.approval_status, ap.department_id, ap.designation, ap.hierarchy_tier, ap.jurisdiction_id, d.name as department_name
        FROM users u
        LEFT JOIN authority_profiles ap ON u.id = ap.user_id
        LEFT JOIN departments d ON ap.department_id = d.id
        WHERE u.id = ?
    ''', (user_id,))
    user = cursor.fetchone()
    db.close()
    return dict(user) if user else None

def login_required(f):
    @functools.wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('auth.login', next=request.path))
        return f(*args, **kwargs)
    return decorated_function

def role_required(allowed_roles):
    """Enforces role-based permissions (citizen, officer, admin)."""
    def decorator(f):
        @functools.wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                flash('Please log in to proceed.', 'warning')
                return redirect(url_for('auth.login', next=request.path))
            
            user = get_current_user()
            if not user or user['role'] not in allowed_roles:
                flash('Access denied: You do not have permissions for this section.', 'danger')
                return redirect(url_for('public.index'))
            
            # If officer, verify approval status
            if user['role'] == 'officer' and user['approval_status'] != 'approved':
                flash('Your municipal authority account is currently pending administrator approval.', 'info')
                return redirect(url_for('auth.pending_approval'))
                
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def log_audit(user_id, action, target_type, target_id=None, details=None):
    """Appends an event to the immutable audit log."""
    try:
        db = get_db()
        cursor = db.cursor()
        ip = request.remote_addr if request else '127.0.0.1'
        cursor.execute('''
            INSERT INTO audit_logs (user_id, action, target_type, target_id, details, ip_address)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (user_id, action, target_type, str(target_id) if target_id else None, details, ip))
        db.commit()
        db.close()
    except Exception as e:
        print(f"Audit log error: {e}")
