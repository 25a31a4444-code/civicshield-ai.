import math
from database import get_db

def haversine_distance(lat1, lon1, lat2, lon2):
    """
    Calculates the great-circle distance between two points on the Earth in meters.
    """
    R = 6371000 # Earth radius in meters
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)

    a = (math.sin(delta_phi / 2.0) ** 2 +
         math.cos(phi1) * math.cos(phi2) * (math.sin(delta_lambda / 2.0) ** 2))
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c

def text_similarity(text1, text2):
    """Calculates Jaccard token similarity between two text strings."""
    if not text1 or not text2:
        return 0.0
    words1 = set(text1.lower().split())
    words2 = set(text2.lower().split())
    intersection = len(words1.intersection(words2))
    union = len(words1.union(words2))
    return intersection / max(1, union)

def find_potential_duplicates(category, latitude, longitude, description, exclude_id=None, radius_meters=150):
    """
    Scans active / recent complaints for potential duplicates based on:
    - Geographic proximity (within radius_meters)
    - Same or related category
    - Description text similarity
    """
    db = get_db()
    cursor = db.cursor()
    
    # Query non-resolved/non-rejected complaints
    query = '''
        SELECT c.*, u.name as citizen_name,
               (SELECT COUNT(*) FROM community_supports WHERE complaint_id = c.id) as support_count
        FROM complaints c
        JOIN users u ON c.citizen_id = u.id
        WHERE c.status NOT IN ('Resolved', 'Rejected')
    '''
    params = []
    if exclude_id:
        query += " AND c.id != ?"
        params.append(exclude_id)
        
    cursor.execute(query, params)
    candidates = cursor.fetchall()
    db.close()
    
    matches = []
    for cand in candidates:
        dist = haversine_distance(latitude, longitude, cand['latitude'], cand['longitude'])
        if dist <= radius_meters:
            # Distance score (closer = higher)
            dist_score = max(0.0, 1.0 - (dist / radius_meters))
            
            # Category match score
            cat_score = 1.0 if cand['category'] == category else 0.4
            
            # Text similarity score
            txt_score = text_similarity(description, cand['description'])
            
            # Combined similarity weight
            combined_score = (dist_score * 0.50) + (cat_score * 0.30) + (txt_score * 0.20)
            
            if combined_score >= 0.45 or (dist <= 50 and cand['category'] == category):
                matches.append({
                    "id": cand['id'],
                    "category": cand['category'],
                    "title": cand['title'],
                    "description": cand['description'],
                    "status": cand['status'],
                    "priority": cand['priority'],
                    "distance_meters": round(dist, 1),
                    "created_at": cand['created_at'],
                    "support_count": cand['support_count'],
                    "similarity_score": round(combined_score, 2)
                })
                
    matches.sort(key=lambda x: x['similarity_score'], reverse=True)
    return matches
