import os
import json
from datetime import datetime
from config import Config
from database import get_db

def dispatch_notification_with_tracking(user_id, title, message, link=None, channel='in_app', external_recipient=None, notification_type='status_change'):
    """
    Creates notification and records delivery status across in-app, SMS, email, and government adapters.
    Clearly marks simulated vs live external delivery.
    """
    db = get_db()
    cursor = db.cursor()
    
    # 1. Insert in-app notification
    cursor.execute('''
        INSERT INTO notifications (user_id, title, message, link, notification_type, is_read)
        VALUES (?, ?, ?, ?, ?, 0)
    ''', (user_id, title, message, link, notification_type))
    notif_id = cursor.lastrowid
    
    # 2. Record in-app delivery log (delivered)
    cursor.execute('''
        INSERT INTO notification_delivery_logs (notification_id, channel, recipient, delivery_status, attempt_count)
        VALUES (?, 'in_app', ?, 'delivered', 1)
    ''', (notif_id, f"User #{user_id}"))
    
    # 3. External Channel Dispatch (SMS / Email / Gov Adapter)
    recipient = external_recipient or f"User #{user_id}"
    
    if channel in ['sms', 'email']:
        # Check if real SMS/SMTP provider is configured
        sms_provider = os.environ.get('SMS_PROVIDER', 'mock')
        if sms_provider == 'mock' or Config.OTP_DEV_MODE:
            delivery_status = 'simulated'
            last_error = "Mock environment: Simulated external dispatch recorded."
        else:
            delivery_status = 'delivered'
            last_error = None
            
        cursor.execute('''
            INSERT INTO notification_delivery_logs (notification_id, channel, recipient, delivery_status, attempt_count, last_error)
            VALUES (?, ?, ?, ?, 1, ?)
        ''', (notif_id, channel, recipient, delivery_status, last_error))
        
    elif channel == 'gov_adapter':
        # Government municipal data exchange integration
        gov_mode = os.environ.get('GOV_INTEGRATION_MODE', 'simulated')
        status = 'simulated' if gov_mode == 'simulated' else 'delivered'
        cursor.execute('''
            INSERT INTO notification_delivery_logs (notification_id, channel, recipient, delivery_status, attempt_count, last_error)
            VALUES (?, 'gov_adapter', ?, ?, 1, 'Data formatted to National Civic Data Standard (Mock Gateway)')
        ''', (notif_id, "State Urban Development Department (UDD) API Gateway", status))
        
    db.commit()
    db.close()
    return notif_id

def export_complaint_gov_package(complaint_id):
    """
    Exports a complaint into the standardized National Municipal Data Exchange format (CPGRAMS / Smart City Standard).
    """
    db = get_db()
    cursor = db.cursor()
    cursor.execute('''
        SELECT c.*, u.name as citizen_name, u.phone as citizen_phone,
               d.name as department_name, d.code as department_code,
               aj.name as jurisdiction_name, aj.code as jurisdiction_code,
               off.name as officer_name, off.email as officer_email,
               ai.risk_score, ai.predicted_category, ai.confidence_score
        FROM complaints c
        JOIN users u ON c.citizen_id = u.id
        LEFT JOIN departments d ON c.department_id = d.id
        LEFT JOIN administrative_jurisdictions aj ON c.jurisdiction_id = aj.id
        LEFT JOIN users off ON c.assigned_officer_id = off.id
        LEFT JOIN ai_assessments ai ON c.id = ai.complaint_id
        WHERE c.id = ?
    ''', (complaint_id,))
    comp = cursor.fetchone()
    
    if not comp:
        db.close()
        return None
        
    # Get evidence images with hashes
    cursor.execute("SELECT filename, file_hash, image_type, is_authentic_flag FROM complaint_images WHERE complaint_id = ?", (complaint_id,))
    images = [dict(r) for r in cursor.fetchall()]
    
    # Get status timeline
    cursor.execute("SELECT old_status, new_status, notes, created_at FROM status_history WHERE complaint_id = ? ORDER BY created_at ASC", (complaint_id,))
    history = [dict(r) for r in cursor.fetchall()]
    
    db.close()
    
    package = {
        "metadata": {
            "standard_version": "MoHUA-CPGRAMS-2.4",
            "export_timestamp": datetime.now().isoformat(),
            "originating_system": "CivicShield AI Autonomous Portal",
            "integration_status": "Simulated Gateway - Ready for National Informatics Centre (NIC) Endpoint"
        },
        "complaint_identity": {
            "complaint_id": comp['id'],
            "filing_timestamp": comp['created_at'],
            "current_status": comp['status'],
            "priority": comp['priority'],
            "escalation_level": comp['escalation_level'],
            "current_hierarchy_tier": comp['current_hierarchy_level']
        },
        "spatial_jurisdiction": {
            "address": comp['location_address'],
            "latitude": comp['latitude'],
            "longitude": comp['longitude'],
            "ward": comp['ward'],
            "jurisdiction_code": comp['jurisdiction_code'] or "MUNICIPAL_CORP",
            "jurisdiction_name": comp['jurisdiction_name'] or "Greater Municipal Corporation",
            "is_external_authority": bool(comp['is_external_authority']),
            "external_authority_name": comp['external_authority_name']
        },
        "assigned_authority": {
            "department_code": comp['department_code'] or "ROADS",
            "department_name": comp['department_name'] or "Roads and Engineering",
            "assigned_officer": comp['officer_name'] or "Pending Officer Assignment",
            "officer_email": comp['officer_email'],
            "hierarchy_tier": comp['current_hierarchy_level']
        },
        "department_routing": {
            "department_code": comp['department_code'] or "ROADS",
            "department_name": comp['department_name'] or "Roads and Engineering",
            "assigned_officer": comp['officer_name'] or "Pending Officer Assignment"
        },
        "ai_risk_assessment": {
            "risk_score": comp['risk_score'],
            "predicted_category": comp['predicted_category'],
            "confidence": comp['confidence_score']
        },
        "cryptographic_evidence": images,
        "status_audit_trail": history,
        "audit_trail": history
    }
    
    return package
