import os
import sys
import hashlib
from datetime import datetime, timedelta
from PIL import Image, ImageDraw, ImageFont

# Add parent directory to path
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, BASE_DIR)

from config import Config
from database import get_db, init_db
from services.auth_service import hash_password
from services.sla_service import calculate_sla_deadlines

def create_demo_image(filename, text, bg_color=(80, 80, 80), subtext="Civic Evidence"):
    """Creates a realistic colored demo image with text label using PIL."""
    os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
    img_path = os.path.join(Config.UPLOAD_FOLDER, filename)
    
    img = Image.new('RGB', (800, 600), color=bg_color)
    draw = ImageDraw.Draw(img)
    
    # Add aesthetic grid / gradient effect
    for y in range(0, 600, 40):
        draw.line([(0, y), (800, y)], fill=(bg_color[0]+15, bg_color[1]+15, bg_color[2]+15), width=1)
    for x in range(0, 800, 40):
        draw.line([(x, 0), (x, 600)], fill=(bg_color[0]+15, bg_color[1]+15, bg_color[2]+15), width=1)
        
    # Draw central banner
    draw.rectangle([60, 220, 740, 380], fill=(40, 20, 30), outline=(231, 201, 169), width=3)
    
    # Text
    draw.text((80, 250), text, fill=(255, 255, 255))
    draw.text((80, 310), f"Status: {subtext} | SHA-256 Verified", fill=(231, 201, 169))
    draw.text((80, 340), "CivicShield AI &bull; Autonomous Verification", fill=(200, 200, 200))
    
    img.save(img_path, 'JPEG', quality=85)
    
    with open(img_path, 'rb') as f:
        file_hash = hashlib.sha256(f.read()).hexdigest()
        
    return filename, img_path, file_hash

def seed():
    print("Initializing database...")
    init_db()
    db = get_db()
    cursor = db.cursor()

    # Clear previous seed records for clean state
    cursor.execute("PRAGMA foreign_keys = OFF;")
    cursor.executescript('''
        DELETE FROM status_history;
        DELETE FROM complaint_images;
        DELETE FROM ai_assessments;
        DELETE FROM duplicate_relations;
        DELETE FROM community_supports;
        DELETE FROM appeals;
        DELETE FROM work_order_complaints;
        DELETE FROM work_order_tasks;
        DELETE FROM work_orders;
        DELETE FROM supervisory_instructions;
        DELETE FROM complaint_transfers;
        DELETE FROM notification_delivery_logs;
        DELETE FROM complaints;
        DELETE FROM sla_escalation_logs;
        DELETE FROM notifications;
        DELETE FROM audit_logs;
        DELETE FROM authority_profiles;
        DELETE FROM users;
    ''')
    cursor.execute("PRAGMA foreign_keys = ON;")
    
    print("Seeding Users...")
    # 1. Citizen 1 (Rahul)
    cursor.execute('''
        INSERT INTO users (id, name, phone, email, password_hash, role, preferred_lang, is_approved)
        VALUES (1, 'Rahul Sharma', '9876543210', 'rahul.citizen@example.com', ?, 'citizen', 'en', 1)
    ''', (hash_password('demo123'),))
    
    # 2. Citizen 2 (Priya - Telugu preferred)
    cursor.execute('''
        INSERT INTO users (id, name, phone, email, password_hash, role, preferred_lang, is_approved)
        VALUES (2, 'Priya Reddy', '9876543211', 'priya.reddy@example.com', ?, 'citizen', 'te', 1)
    ''', (hash_password('demo123'),))
    
    # 3. Officer (Roads & Engineering - Suresh Varma - Tier 3 SE / Dept Head)
    cursor.execute('''
        INSERT INTO users (id, name, phone, email, password_hash, role, preferred_lang, is_approved)
        VALUES (3, 'Suresh Varma', '9849012345', 'suresh.eng@civicshield.gov.in', ?, 'officer', 'en', 1)
    ''', (hash_password('officer123'),))
    
    cursor.execute('''
        INSERT INTO authority_profiles (user_id, department_id, employee_id, designation, hierarchy_tier, jurisdiction_id, approval_status, approved_by, approved_at)
        VALUES (3, 1, 'GHMC-ENG-2024', 'Superintending Engineer (Roads)', 3, 'ZONE_CENTRAL', 'approved', 6, CURRENT_TIMESTAMP)
    ''')
    
    # 4. Officer (Sanitation - Ananya Rao - Tier 2 AEE)
    cursor.execute('''
        INSERT INTO users (id, name, phone, email, password_hash, role, preferred_lang, is_approved)
        VALUES (4, 'Ananya Rao', '9849054321', 'ananya.sanitation@civicshield.gov.in', ?, 'officer', 'en', 1)
    ''', (hash_password('officer123'),))
    
    cursor.execute('''
        INSERT INTO authority_profiles (user_id, department_id, employee_id, designation, hierarchy_tier, jurisdiction_id, approval_status, approved_by, approved_at)
        VALUES (4, 2, 'GHMC-SAN-1102', 'Zonal Sanitation Inspector', 2, 'WARD_04', 'approved', 6, CURRENT_TIMESTAMP)
    ''')

    # 5. Officer Pending Approval (Vikram Patel)
    cursor.execute('''
        INSERT INTO users (id, name, phone, email, password_hash, role, preferred_lang, is_approved)
        VALUES (5, 'Vikram Patel', '9849099999', 'vikram.electrical@civicshield.gov.in', ?, 'officer', 'en', 0)
    ''', (hash_password('officer123'),))
    
    cursor.execute('''
        INSERT INTO authority_profiles (user_id, department_id, employee_id, designation, hierarchy_tier, approval_status)
        VALUES (5, 5, 'TSSPDCL-AE-889', 'Assistant Electrical Engineer', 2, 'pending')
    ''')
    
    # 6. Administrator (Commissioner Radhakrishna - Tier 4 Senior Authority)
    cursor.execute('''
        INSERT INTO users (id, name, phone, email, password_hash, role, preferred_lang, is_approved)
        VALUES (6, 'Dr. K. Radhakrishna, IAS', '9999999999', 'commissioner@civicshield.gov.in', ?, 'admin', 'en', 1)
    ''', (hash_password('admin123'),))
    
    cursor.execute('''
        INSERT INTO authority_profiles (user_id, department_id, employee_id, designation, hierarchy_tier, jurisdiction_id, approval_status, approved_by, approved_at)
        VALUES (6, 1, 'IAS-TS-0442', 'Municipal Commissioner & Ombudsman', 4, 'ZONE_CENTRAL', 'approved', 6, CURRENT_TIMESTAMP)
    ''')

    # 7. Field Officer (Ramesh Kumar - Tier 1 Ward JE)
    cursor.execute('''
        INSERT INTO users (id, name, phone, email, password_hash, role, preferred_lang, is_approved)
        VALUES (7, 'Ramesh Kumar', '9849077777', 'ramesh.field@civicshield.gov.in', ?, 'officer', 'en', 1)
    ''', (hash_password('officer123'),))
    
    cursor.execute('''
        INSERT INTO authority_profiles (user_id, department_id, employee_id, designation, hierarchy_tier, jurisdiction_id, approval_status, approved_by, approved_at)
        VALUES (7, 1, 'GHMC-JE-7701', 'Junior Engineer (Ward 7 Field Wing)', 1, 'WARD_07', 'approved', 6, CURRENT_TIMESTAMP)
    ''')

    # 8. Department Officer (Kavita Sharma - Tier 2 Drainage AEE)
    cursor.execute('''
        INSERT INTO users (id, name, phone, email, password_hash, role, preferred_lang, is_approved)
        VALUES (8, 'Kavita Sharma', '9849088888', 'kavita.drainage@civicshield.gov.in', ?, 'officer', 'en', 1)
    ''', (hash_password('officer123'),))
    
    cursor.execute('''
        INSERT INTO authority_profiles (user_id, department_id, employee_id, designation, hierarchy_tier, jurisdiction_id, approval_status, approved_by, approved_at)
        VALUES (8, 4, 'GHMC-DRN-4001', 'Assistant Executive Engineer (Drainage)', 2, 'WARD_07', 'approved', 6, CURRENT_TIMESTAMP)
    ''')
    
    print("Generating demo evidence photos...")
    # Create realistic before and after photos
    f_pothole_bef, p_pothole_bef, h_pothole_bef = create_demo_image('demo_pothole_before.jpg', 'DANGEROUS 15CM ROAD CRATER', (60, 55, 50), 'Damage Identified')
    f_pothole_aft, p_pothole_aft, h_pothole_aft = create_demo_image('demo_pothole_after.jpg', 'COMPACTED HOT-MIX ASPHALT REPAIR', (35, 70, 45), 'Repaired & Resurfaced')
    
    f_garbage_bef, p_garbage_bef, h_garbage_bef = create_demo_image('demo_garbage_before.jpg', 'OVERFLOWING PUBLIC WASTE ACCUMULATION', (70, 60, 40), 'Sanitation Violation')
    f_garbage_aft, p_garbage_aft, h_garbage_aft = create_demo_image('demo_garbage_after.jpg', 'CLEARED & DISINFECTED WASTE ZONE', (30, 75, 40), 'Debris Removed')
    
    f_light_bef, p_light_bef, h_light_bef = create_demo_image('demo_light_before.jpg', 'BROKEN HIGH-MAST FEEDER LIGHT', (40, 40, 50), 'Dark Vulnerability Zone')
    f_light_aft, p_light_aft, h_light_aft = create_demo_image('demo_light_after.jpg', '70W LED FIXTURE ILLUMINATING STREET', (75, 70, 30), 'Restored')
    
    f_wire_bef, p_wire_bef, h_wire_bef = create_demo_image('demo_wire_before.jpg', 'DANGLING 440V EXPOSED ELECTRICAL CONDUCTOR', (85, 30, 30), 'Critical Shock Hazard')
    f_drain_bef, p_drain_bef, h_drain_bef = create_demo_image('demo_drain_before.jpg', 'CHOKED STORM SEWER FLOODING FOOTPATH', (40, 55, 60), 'Stagnant Contamination')

    print("Seeding Work Orders...")
    cursor.execute('''
        INSERT INTO work_orders (id, department_id, title, description, assigned_team, planned_date, status, estimated_cost, estimated_manpower, materials_required, created_by)
        VALUES ('WO-2026-0001', 1, 'Jubilee Hills Road 36 Surface Rehabilitation', 'Pavement milling and hot-mix patching for multiple road craters', 'Quick Response Road Squad A', '2026-10-18', 'In Progress', 8500.0, 4, '3 Metric Tons Bituminous mix, Tack Coat Emulsion, Vibratory Roller', 3)
    ''')
    cursor.execute('''
        INSERT INTO work_order_tasks (work_order_id, task_description, is_completed)
        VALUES 
        ('WO-2026-0001', 'Set up high-visibility safety cones and traffic diversion', 1),
        ('WO-2026-0001', 'Excavate loose gravel to 15cm foundation depth', 1),
        ('WO-2026-0001', 'Apply hot-mix bitumen emulsion and roll compaction', 0),
        ('WO-2026-0001', 'Clean street debris and record post-repair photograph', 0)
    ''')

    cursor.execute('''
        INSERT INTO work_orders (id, department_id, title, description, assigned_team, planned_date, status, estimated_cost, estimated_manpower, materials_required, created_by)
        VALUES ('WO-2026-0002', 2, 'Begumpet Station Solid Waste Decongestion', 'Clear accumulated waste bins and sanitize ground surface', 'Sanitation Ward Team 4', '2026-10-17', 'Scheduled', 4200.0, 3, 'Compactor Truck, 2x 1100L Wheelie Bins, Disinfectant spray', 4)
    ''')
    cursor.execute('''
        INSERT INTO work_order_tasks (work_order_id, task_description, is_completed)
        VALUES 
        ('WO-2026-0002', 'Deploy mechanical tipper and clear bin perimeter', 1),
        ('WO-2026-0002', 'Wash concrete pad with sodium hypochlorite disinfectant', 0),
        ('WO-2026-0002', 'Install anti-littering public advisory signage', 0)
    ''')

    print("Seeding Complaints...")
    now = datetime.now()
    
    # 1. Pothole on Road 36 (In Progress - linked to WO-2026-0001)
    c1_id = "CIVIC-2026-00101"
    c1_ack, c1_res = calculate_sla_deadlines("High")
    cursor.execute('''
        INSERT INTO complaints (
            id, citizen_id, category, title, description, location_address, latitude, longitude,
            ward, status, priority, department_id, assigned_officer_id, work_order_id,
            sla_ack_due, sla_resolve_due, is_overdue, escalation_level, created_at
        ) VALUES (?, 1, 'Potholes and Damaged Roads', 'Hazardous 15cm Road Crater near Metro Pillar 1420',
            'Severe asphalt crater across the two-wheeler lane causing sudden vehicle skids at night.',
            'Road No. 36, Near Jubilee Hills Checkpost Metro Pillar 1420', 17.4312, 78.4072,
            'Ward 12 - Central', 'In Progress', 'High', 1, 3, 'WO-2026-0001', ?, ?, 0, 0, ?)
    ''', (c1_id, c1_ack, c1_res, (now - timedelta(hours=8)).strftime('%Y-%m-%d %H:%M:%S')))
    
    cursor.execute('''
        INSERT INTO complaint_images (complaint_id, filename, file_path, file_hash, image_type, is_authentic_flag, authenticity_confidence, uploaded_by)
        VALUES (?, ?, ?, ?, 'evidence', 'Likely Authentic', 0.94, 1)
    ''', (c1_id, f_pothole_bef, p_pothole_bef, h_pothole_bef))
    
    cursor.execute('''
        INSERT INTO ai_assessments (complaint_id, predicted_category, confidence_score, risk_score, severity_level, recommended_dept_id, hazard_flags, reasoning)
        VALUES (?, 'Potholes and Damaged Roads', 0.92, 78, 'High', 1, 'Two-Wheeler Skid & Collision Hazard, Crater Depth > 12cm',
            'AI Vision detected high-risk asphalt cavity in arterial carriageway. High hazard multiplier applied due to high-speed nighttime transit.')
    ''', (c1_id,))
    
    cursor.execute('''
        INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes)
        VALUES 
        (?, NULL, 'Submitted', 1, 'Report filed with photo evidence.'),
        (?, 'Submitted', 'Assigned', 3, 'Assigned to Superintending Engineer Suresh Varma.'),
        (?, 'Assigned', 'In Progress', 3, 'Bundled into Smart Work Order WO-2026-0001.')
    ''', (c1_id, c1_id, c1_id))
    
    cursor.execute('INSERT INTO work_order_complaints (work_order_id, complaint_id) VALUES ("WO-2026-0001", ?)', (c1_id,))

    # 2. Overdue Drainage Blockage in Begumpet (SLA Escalated Level 2!)
    c2_id = "CIVIC-2026-00102"
    c2_past_due = (now - timedelta(hours=18)).strftime('%Y-%m-%d %H:%M:%S')
    cursor.execute('''
        INSERT INTO complaints (
            id, citizen_id, category, title, description, raw_description_te, location_address, latitude, longitude,
            ward, status, priority, department_id, assigned_officer_id,
            sla_ack_due, sla_resolve_due, is_overdue, escalation_level, created_at
        ) VALUES (?, 2, 'Drainage Blockage', 'Clogged Stormwater Culvert Flooding Footpath',
            'మురుగు కాలువ బ్లాకేజీ (Clogged drain) causing sewage backflow across pedestrian walkway.',
            'మురుగు కాలువ బ్లాకేజీ వల్ల పాదచారుల దారి పూర్తిగా మునిగిపోయింది.',
            'Station Road, Near Begumpet Railway Underpass', 17.4435, 78.4682,
            'Ward 4 - North', 'Under Review', 'High', 4, 3,
            ?, ?, 1, 2, ?)
    ''', (c2_id, (now - timedelta(hours=36)).strftime('%Y-%m-%d %H:%M:%S'), c2_past_due, (now - timedelta(hours=48)).strftime('%Y-%m-%d %H:%M:%S')))
    
    cursor.execute('''
        INSERT INTO complaint_images (complaint_id, filename, file_path, file_hash, image_type, is_authentic_flag, authenticity_confidence, uploaded_by)
        VALUES (?, ?, ?, ?, 'evidence', 'Likely Authentic', 0.91, 2)
    ''', (c2_id, f_drain_bef, p_drain_bef, h_drain_bef))
    
    cursor.execute('''
        INSERT INTO ai_assessments (complaint_id, predicted_category, confidence_score, risk_score, severity_level, recommended_dept_id, hazard_flags, reasoning)
        VALUES (?, 'Drainage Blockage', 0.89, 74, 'High', 4, 'Vector-borne Disease / Sewage Contamination, Pedestrian Submersion',
            'AI text and visual analysis detected blackwater overflow obstructing public right of way.')
    ''', (c2_id,))
    
    cursor.execute('''
        INSERT INTO sla_escalation_logs (complaint_id, escalation_level, triggered_reason, escalated_to_role, notes)
        VALUES (?, 2, 'Resolution deadline breached by 18 hours.', 'Department Head & Zonal Officer', 'Auto-escalated by CivicShield daemon.')
    ''', (c2_id,))

    # 3. Critical Dangling Live Wire (Critical Priority)
    c3_id = "CIVIC-2026-00103"
    c3_ack, c3_res = calculate_sla_deadlines("Critical")
    cursor.execute('''
        INSERT INTO complaints (
            id, citizen_id, category, title, description, location_address, latitude, longitude,
            ward, status, priority, department_id, sla_ack_due, sla_resolve_due, is_overdue, created_at
        ) VALUES (?, 1, 'Exposed Electrical Wires', 'Snapped High-Voltage Wire Dangling Over Public Bus Shelter',
            'Live dangling wire sparking periodically near bus stop bench. Imminent electrocution danger to passengers.',
            'Koti Bus Terminal Main Entrance, Hyderabad', 17.3871, 78.4834,
            'Ward 12 - Central', 'Submitted', 'Critical', 5, ?, ?, 0, ?)
    ''', (c3_id, c3_ack, c3_res, (now - timedelta(hours=1)).strftime('%Y-%m-%d %H:%M:%S')))
    
    cursor.execute('''
        INSERT INTO complaint_images (complaint_id, filename, file_path, file_hash, image_type, is_authentic_flag, authenticity_confidence, uploaded_by)
        VALUES (?, ?, ?, ?, 'evidence', 'Likely Authentic', 0.96, 1)
    ''', (c3_id, f_wire_bef, p_wire_bef, h_wire_bef))
    
    cursor.execute('''
        INSERT INTO ai_assessments (complaint_id, predicted_category, confidence_score, risk_score, severity_level, recommended_dept_id, hazard_flags, reasoning)
        VALUES (?, 'Exposed Electrical Wires', 0.95, 96, 'Critical', 5, 'High Voltage Shock / Electrocution Risk',
            'Emergency critical priority: Life-threatening electrical risk adjacent to crowded passenger transit area.')
    ''', (c3_id,))

    # 4. Resolved Complaint with Before-and-After Verification (Garbage Cleared)
    c4_id = "CIVIC-2026-00104"
    cursor.execute('''
        INSERT INTO complaints (
            id, citizen_id, category, title, description, location_address, latitude, longitude,
            ward, status, priority, department_id, assigned_officer_id, work_order_id,
            resolution_notes, resolution_photo_hash, citizen_confirmed, citizen_rating, citizen_feedback, created_at, updated_at
        ) VALUES (?, 1, 'Garbage Accumulation', 'Massive Uncollected Waste Mound along Commercial Hub',
            'Solid waste dumped along market perimeter emitting foul odor and breeding flies.',
            'Madhapur Main Road, Near Image Hospitals', 17.4485, 78.3908,
            'Ward 7 - West', 'Resolved', 'Medium', 2, 4, 'WO-2026-0002',
            'Entire 2.5 ton garbage backlog cleared with hydraulic tipper. Concrete pad washed and sprayed with disinfectant.',
            ?, 1, 5, 'Excellent swift response! Area is completely clean and smell is gone.',
            ?, ?)
    ''', (c4_id, h_garbage_aft, (now - timedelta(days=2)).strftime('%Y-%m-%d %H:%M:%S'), (now - timedelta(hours=5)).strftime('%Y-%m-%d %H:%M:%S')))
    
    cursor.execute('''
        INSERT INTO complaint_images (complaint_id, filename, file_path, file_hash, image_type, uploaded_by)
        VALUES (?, ?, ?, ?, 'evidence', 1)
    ''', (c4_id, f_garbage_bef, p_garbage_bef, h_garbage_bef))
    
    cursor.execute('''
        INSERT INTO complaint_images (complaint_id, filename, file_path, file_hash, image_type, uploaded_by)
        VALUES (?, ?, ?, ?, 'resolution', 4)
    ''', (c4_id, f_garbage_aft, p_garbage_aft, h_garbage_aft))

    # 5. Resolved Complaint with Before-and-After Verification (Streetlight Restored)
    c5_id = "CIVIC-2026-00105"
    cursor.execute('''
        INSERT INTO complaints (
            id, citizen_id, category, title, description, location_address, latitude, longitude,
            ward, status, priority, department_id, assigned_officer_id,
            resolution_notes, resolution_photo_hash, citizen_confirmed, citizen_rating, citizen_feedback, created_at, updated_at
        ) VALUES (?, 2, 'Broken Streetlights', 'High-Mast Feeder Pole Dark for Past 4 Days',
            'Entire residential street is plunged in darkness causing security worries for women and evening commuters.',
            'Banjara Hills Road No. 10, Near Community Hall', 17.4156, 78.4354,
            'Ward 12 - Central', 'Resolved', 'Medium', 5, 3,
            'Replaced blown 40A miniature circuit breaker in feeder pillar and installed new 70W warm-white LED lamp luminaire.',
            ?, 1, 5, 'Prompt resolution by the engineering crew. Well illuminated now.',
            ?, ?)
    ''', (c5_id, h_light_aft, (now - timedelta(days=3)).strftime('%Y-%m-%d %H:%M:%S'), (now - timedelta(hours=12)).strftime('%Y-%m-%d %H:%M:%S')))
    
    cursor.execute('''
        INSERT INTO complaint_images (complaint_id, filename, file_path, file_hash, image_type, uploaded_by)
        VALUES (?, ?, ?, ?, 'evidence', 2)
    ''', (c5_id, f_light_bef, p_light_bef, h_light_bef))
    
    cursor.execute('''
        INSERT INTO complaint_images (complaint_id, filename, file_path, file_hash, image_type, uploaded_by)
        VALUES (?, ?, ?, ?, 'resolution', 3)
    ''', (c5_id, f_light_aft, p_light_aft, h_light_aft))

    # 6. Reopened Complaint (Citizen Disputed Spot Patch)
    c6_id = "CIVIC-2026-00106"
    cursor.execute('''
        INSERT INTO complaints (
            id, citizen_id, category, title, description, location_address, latitude, longitude,
            ward, status, priority, department_id, assigned_officer_id, is_overdue, escalation_level, created_at
        ) VALUES (?, 1, 'Potholes and Damaged Roads', 'Subsidence and Potholes along Uppal Ring Road',
            'Road sinking around telecom manhole cover creating harsh bump for vehicles.',
            'Uppal Cross Roads, Near Metro Station Pillar 812', 17.4018, 78.5602,
            'Ward 14 - East', 'Reopened', 'Medium', 1, 3, 0, 1, ?)
    ''', (c6_id, (now - timedelta(days=4)).strftime('%Y-%m-%d %H:%M:%S')))
    
    cursor.execute('''
        INSERT INTO status_history (complaint_id, old_status, new_status, changed_by, notes)
        VALUES 
        (?, NULL, 'Submitted', 1, 'Initial report submitted.'),
        (?, 'Submitted', 'Resolved', 3, 'Temporary cold-patch applied.'),
        (?, 'Resolved', 'Reopened', 1, 'Citizen disputed repair: Cold-patch washed away in overnight rain. Manhole rim exposed again.')
    ''', (c6_id, c6_id, c6_id))

    # 7. Rejected Complaint with Citizen Appeal Lodged
    c7_id = "CIVIC-2026-00107"
    cursor.execute('''
        INSERT INTO complaints (
            id, citizen_id, category, title, description, location_address, latitude, longitude,
            ward, status, priority, department_id, rejection_reason, created_at
        ) VALUES (?, 2, 'Water Leakage', 'Water gushing from private apartment compound pipe',
            'Water flooding pavement from damaged pipeline near entry gate.',
            'Gachibowli Outer Ring Road Lane', 17.4401, 78.3489,
            'Ward 7 - West', 'Rejected', 'Low', 3,
            'Leakage originates on private residential association property behind the meter, outside municipal right of way.', ?)
    ''', (c7_id, (now - timedelta(days=5)).strftime('%Y-%m-%d %H:%M:%S')))
    
    cursor.execute('''
        INSERT INTO appeals (complaint_id, citizen_id, appeal_reason, status)
        VALUES (?, 2, 'The leakage is actually emerging from the public water board transmission line before the meter manifold. Municipal water is being wasted on the main roadway.', 'Pending Review')
    ''', (c7_id,))

    # 8. External Authority Complaint (National Highway NH-65 - NHAI Jurisdiction)
    c8_id = "CIVIC-2026-00108"
    cursor.execute('''
        INSERT INTO complaints (
            id, citizen_id, category, title, description, location_address, latitude, longitude,
            ward, status, priority, department_id, jurisdiction_id, is_external_authority,
            external_authority_name, current_hierarchy_level, created_at
        ) VALUES (?, 1, 'Potholes and Damaged Roads', 'Massive Crater along National Highway 65 (NH-65) Corridor',
            'Multiple deep craters causing heavy vehicle swerving near NH-65 interchange.',
            'National Highway 65 (NH-65), Miyapur Outer Ring Road Interchange', 17.4932, 78.3582,
            'Ward 7 - West', 'Assigned', 'High', 1, 'EXT_NHAI', 1,
            'National Highways Authority of India (NHAI)', 2, ?)
    ''', (c8_id, (now - timedelta(days=1)).strftime('%Y-%m-%d %H:%M:%S')))

    # 9. Inter-Department Transfer Dispute (Roads vs Drainage)
    c9_id = "CIVIC-2026-00109"
    cursor.execute('''
        INSERT INTO complaints (
            id, citizen_id, category, title, description, location_address, latitude, longitude,
            ward, status, priority, department_id, jurisdiction_id, current_hierarchy_level,
            supervisory_flag, citizen_escalation_reason, created_at
        ) VALUES (?, 2, 'Drainage Blockage', 'Collapsing Stormwater Culvert Crossing Under Arterial Road',
            'Subsurface stormwater box culvert collapsed under road pavement causing subsidence.',
            'Road No. 12, Jubilee Hills Crossing', 17.4290, 78.4110,
            'Ward 7 - West', 'Assigned', 'Critical', 1, 'WARD_07', 3,
            1, 'Escalated to Superintending Engineer to arbitrate inter-department boundary dispute.', ?)
    ''', (c9_id, (now - timedelta(hours=36)).strftime('%Y-%m-%d %H:%M:%S')))

    # Complaint Transfer record (Disputed)
    cursor.execute('''
        INSERT INTO complaint_transfers (complaint_id, from_dept_id, to_dept_id, transferred_by, transfer_reason, status, dispute_reason)
        VALUES (?, 1, 4, 7,
            'Field inspection revealed failure is within the underground drainage sewer network, not road asphalt.',
            'Disputed',
            'Drainage engineering wing disputes jurisdiction: Box culvert is an integrated structural road bridge asset owned by Roads and Engineering.')
    ''', (c9_id,))

    # Supervisory Instruction issued by Superintending Engineer
    cursor.execute('''
        INSERT INTO supervisory_instructions (complaint_id, supervisor_id, instruction_type, instruction_text, review_deadline)
        VALUES (?, 3, 'Show-Cause',
            'Joint Inspection Mandate: Both Roads (AEE) and Drainage (AEE) must conduct on-ground joint acoustic inspection within 24 hours and submit unified remediation schedule.',
            ?)
    ''', (c9_id, (now + timedelta(hours=24)).strftime('%Y-%m-%d %H:%M:%S')))

    # Seed Notification Delivery Audit Logs (Section 33.H)
    cursor.execute('''
        INSERT INTO notification_delivery_logs (complaint_id, recipient_id, recipient, channel, subject, message_preview, status, retry_count)
        VALUES 
        (?, 7, 'ramesh.field@civicshield.gov.in', 'in_app', 'New Grievance Assignment: CIVIC-2026-00101', 'Assigned as field officer for Road 36 inspection.', 'delivered', 0),
        (?, 7, '+91-9849077777', 'sms', 'CivicShield Alert: Urgent Grievance #CIVIC-2026-00101', 'SMS alert dispatched to field officer phone.', 'simulated', 0),
        (?, 3, 'suresh.eng@civicshield.gov.in', 'email', 'Supervisory Escalation: CIVIC-2026-00102', 'Notice: Overdue grievance escalated to Superintending Engineer.', 'sent', 0),
        (?, 6, 'nhai-gateway@nic.in', 'gov_adapter', 'CPGRAMS Sync: CIVIC-2026-00108', 'Standardized grievance payload transmitted to NHAI external gateway.', 'simulated', 0)
    ''', (c1_id, c1_id, c2_id, c8_id))

    # Seed Community Supports / Upvotes
    cursor.execute('INSERT OR IGNORE INTO community_supports (complaint_id, user_id) VALUES (?, ?)', (c1_id, 2))
    cursor.execute('INSERT OR IGNORE INTO community_supports (complaint_id, user_id) VALUES (?, ?)', (c2_id, 1))

    # Seed Predictive Maintenance Hotspot
    cursor.execute('''
        INSERT INTO predictive_alerts (title, category, location_cluster, ward, recurrence_count, risk_level, recommended_action, status)
        VALUES 
        ('Recurrent Pavement Subsidence along Road 36 Corridor', 'Potholes and Damaged Roads', 'Road No. 36 Transit Corridor', 'Ward 12 - Central', 4, 'High',
         'Full asphalt pavement milling and structural re-sheeting recommended rather than isolated spot patches.', 'Pending'),
        ('Recurring Monsoon Inundation at Begumpet Railway Underpass', 'Waterlogging and Flooding', 'Begumpet Underpass Drainage Basin', 'Ward 4 - North', 5, 'Critical',
         'Deploy permanent 120 HP submersible de-watering pump and increase storm drain intake cross-section.', 'Approved')
    ''')

    # Seed Notifications
    cursor.execute('''
        INSERT INTO notifications (user_id, title, message, link, notification_type, is_read)
        VALUES 
        (1, 'Complaint Registered: CIVIC-2026-00101', 'Your report for Road No. 36 was verified with High priority.', '/citizen/complaint/CIVIC-2026-00101', 'status_change', 0),
        (1, 'Work Order Dispatched: CIVIC-2026-00101', 'Maintenance crew Quick Response Squad A is en route.', '/citizen/complaint/CIVIC-2026-00101', 'status_change', 0),
        (3, 'URGENT SLA Escalation: CIVIC-2026-00102', 'Complaint CIVIC-2026-00102 has breached resolution SLA by 18 hours.', '/authority/complaint/CIVIC-2026-00102', 'sla_warning', 0)
    ''')

    db.commit()
    db.close()
    print("Seed data successfully populated!")

if __name__ == '__main__':
    seed()
